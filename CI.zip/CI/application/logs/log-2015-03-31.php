<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2015-03-31 08:24:42 --> Config Class Initialized
INFO - 2015-03-31 08:24:42 --> Hooks Class Initialized
DEBUG - 2015-03-31 08:24:43 --> UTF-8 Support Enabled
INFO - 2015-03-31 08:24:43 --> Utf8 Class Initialized
INFO - 2015-03-31 08:24:43 --> URI Class Initialized
DEBUG - 2015-03-31 08:24:43 --> No URI present. Default controller set.
INFO - 2015-03-31 08:24:43 --> Router Class Initialized
INFO - 2015-03-31 08:24:43 --> Output Class Initialized
INFO - 2015-03-31 08:24:43 --> Security Class Initialized
DEBUG - 2015-03-31 08:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-03-31 08:24:43 --> Input Class Initialized
INFO - 2015-03-31 08:24:43 --> Language Class Initialized
INFO - 2015-03-31 08:24:43 --> Language Class Initialized
INFO - 2015-03-31 08:24:43 --> Config Class Initialized
INFO - 2015-03-31 08:24:43 --> Loader Class Initialized
INFO - 2015-03-31 08:24:43 --> Controller Class Initialized
DEBUG - 2015-03-31 08:24:43 --> Welcome MX_Controller Initialized
DEBUG - 2015-03-31 08:24:43 --> File loaded: /Volumes/Dados/Projetos Web/CLIENTES/JLAMIM/CI3-HMVC/application/modules/Welcome/views/welcome_message.php
INFO - 2015-03-31 08:24:43 --> Final output sent to browser
DEBUG - 2015-03-31 08:24:43 --> Total execution time: 0.8957
INFO - 2015-03-31 08:24:43 --> Config Class Initialized
INFO - 2015-03-31 08:24:43 --> Hooks Class Initialized
DEBUG - 2015-03-31 08:24:43 --> UTF-8 Support Enabled
INFO - 2015-03-31 08:24:43 --> Utf8 Class Initialized
INFO - 2015-03-31 08:24:43 --> URI Class Initialized
INFO - 2015-03-31 08:24:43 --> Router Class Initialized
INFO - 2015-03-31 08:24:43 --> Output Class Initialized
INFO - 2015-03-31 08:24:43 --> Security Class Initialized
DEBUG - 2015-03-31 08:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-03-31 08:24:43 --> Input Class Initialized
INFO - 2015-03-31 08:24:43 --> Language Class Initialized
ERROR - 2015-03-31 08:24:43 --> 404 Page Not Found: /index
INFO - 2015-03-31 08:24:44 --> Config Class Initialized
INFO - 2015-03-31 08:24:44 --> Hooks Class Initialized
DEBUG - 2015-03-31 08:24:44 --> UTF-8 Support Enabled
INFO - 2015-03-31 08:24:44 --> Utf8 Class Initialized
INFO - 2015-03-31 08:24:44 --> URI Class Initialized
INFO - 2015-03-31 08:24:44 --> Router Class Initialized
INFO - 2015-03-31 08:24:44 --> Output Class Initialized
INFO - 2015-03-31 08:24:44 --> Security Class Initialized
DEBUG - 2015-03-31 08:24:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2015-03-31 08:24:44 --> Input Class Initialized
INFO - 2015-03-31 08:24:44 --> Language Class Initialized
ERROR - 2015-03-31 08:24:44 --> 404 Page Not Found: /index
