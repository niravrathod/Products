<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2018-10-21 16:53:25 --> Config Class Initialized
INFO - 2018-10-21 16:53:25 --> Hooks Class Initialized
DEBUG - 2018-10-21 16:53:26 --> UTF-8 Support Enabled
INFO - 2018-10-21 16:53:26 --> Utf8 Class Initialized
INFO - 2018-10-21 16:53:26 --> URI Class Initialized
DEBUG - 2018-10-21 16:53:27 --> No URI present. Default controller set.
INFO - 2018-10-21 16:53:27 --> Router Class Initialized
INFO - 2018-10-21 16:53:27 --> Output Class Initialized
INFO - 2018-10-21 16:53:27 --> Security Class Initialized
DEBUG - 2018-10-21 16:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 16:53:27 --> Input Class Initialized
INFO - 2018-10-21 16:53:27 --> Language Class Initialized
INFO - 2018-10-21 16:53:28 --> Language Class Initialized
INFO - 2018-10-21 16:53:28 --> Config Class Initialized
INFO - 2018-10-21 16:53:29 --> Loader Class Initialized
INFO - 2018-10-21 16:53:29 --> Helper loaded: url_helper
INFO - 2018-10-21 16:53:29 --> Helper loaded: form_helper
INFO - 2018-10-21 16:53:29 --> Helper loaded: html_helper
INFO - 2018-10-21 16:53:29 --> Controller Class Initialized
DEBUG - 2018-10-21 16:53:29 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 16:53:30 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 16:53:30 --> Final output sent to browser
DEBUG - 2018-10-21 16:53:30 --> Total execution time: 4.7166
INFO - 2018-10-21 16:56:42 --> Config Class Initialized
INFO - 2018-10-21 16:56:42 --> Hooks Class Initialized
DEBUG - 2018-10-21 16:56:42 --> UTF-8 Support Enabled
INFO - 2018-10-21 16:56:42 --> Utf8 Class Initialized
INFO - 2018-10-21 16:56:42 --> URI Class Initialized
DEBUG - 2018-10-21 16:56:42 --> No URI present. Default controller set.
INFO - 2018-10-21 16:56:42 --> Router Class Initialized
INFO - 2018-10-21 16:56:42 --> Output Class Initialized
INFO - 2018-10-21 16:56:42 --> Security Class Initialized
DEBUG - 2018-10-21 16:56:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 16:56:42 --> Input Class Initialized
INFO - 2018-10-21 16:56:42 --> Language Class Initialized
INFO - 2018-10-21 16:56:42 --> Language Class Initialized
INFO - 2018-10-21 16:56:42 --> Config Class Initialized
INFO - 2018-10-21 16:56:42 --> Loader Class Initialized
INFO - 2018-10-21 16:56:42 --> Helper loaded: url_helper
INFO - 2018-10-21 16:56:42 --> Helper loaded: form_helper
INFO - 2018-10-21 16:56:42 --> Helper loaded: html_helper
INFO - 2018-10-21 16:56:42 --> Controller Class Initialized
DEBUG - 2018-10-21 16:56:42 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 16:56:42 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 16:56:42 --> Final output sent to browser
DEBUG - 2018-10-21 16:56:42 --> Total execution time: 0.6664
INFO - 2018-10-21 16:56:51 --> Config Class Initialized
INFO - 2018-10-21 16:56:51 --> Hooks Class Initialized
DEBUG - 2018-10-21 16:56:51 --> UTF-8 Support Enabled
INFO - 2018-10-21 16:56:51 --> Utf8 Class Initialized
INFO - 2018-10-21 16:56:51 --> URI Class Initialized
INFO - 2018-10-21 16:56:51 --> Router Class Initialized
INFO - 2018-10-21 16:56:51 --> Output Class Initialized
INFO - 2018-10-21 16:56:51 --> Security Class Initialized
DEBUG - 2018-10-21 16:56:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 16:56:51 --> Input Class Initialized
INFO - 2018-10-21 16:56:51 --> Language Class Initialized
INFO - 2018-10-21 16:56:51 --> Language Class Initialized
INFO - 2018-10-21 16:56:51 --> Config Class Initialized
INFO - 2018-10-21 16:56:51 --> Loader Class Initialized
INFO - 2018-10-21 16:56:51 --> Helper loaded: url_helper
INFO - 2018-10-21 16:56:51 --> Helper loaded: form_helper
INFO - 2018-10-21 16:56:51 --> Helper loaded: html_helper
INFO - 2018-10-21 16:56:51 --> Controller Class Initialized
ERROR - 2018-10-21 16:56:51 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 16:56:56 --> Config Class Initialized
INFO - 2018-10-21 16:56:56 --> Hooks Class Initialized
DEBUG - 2018-10-21 16:56:56 --> UTF-8 Support Enabled
INFO - 2018-10-21 16:56:56 --> Utf8 Class Initialized
INFO - 2018-10-21 16:56:56 --> URI Class Initialized
DEBUG - 2018-10-21 16:56:56 --> No URI present. Default controller set.
INFO - 2018-10-21 16:56:56 --> Router Class Initialized
INFO - 2018-10-21 16:56:56 --> Output Class Initialized
INFO - 2018-10-21 16:56:56 --> Security Class Initialized
DEBUG - 2018-10-21 16:56:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 16:56:56 --> Input Class Initialized
INFO - 2018-10-21 16:56:56 --> Language Class Initialized
INFO - 2018-10-21 16:56:56 --> Language Class Initialized
INFO - 2018-10-21 16:56:56 --> Config Class Initialized
INFO - 2018-10-21 16:56:56 --> Loader Class Initialized
INFO - 2018-10-21 16:56:56 --> Helper loaded: url_helper
INFO - 2018-10-21 16:56:56 --> Helper loaded: form_helper
INFO - 2018-10-21 16:56:56 --> Helper loaded: html_helper
INFO - 2018-10-21 16:56:56 --> Controller Class Initialized
DEBUG - 2018-10-21 16:56:56 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 16:56:56 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 16:56:56 --> Final output sent to browser
DEBUG - 2018-10-21 16:56:56 --> Total execution time: 0.2920
INFO - 2018-10-21 16:57:37 --> Config Class Initialized
INFO - 2018-10-21 16:57:37 --> Hooks Class Initialized
DEBUG - 2018-10-21 16:57:37 --> UTF-8 Support Enabled
INFO - 2018-10-21 16:57:37 --> Utf8 Class Initialized
INFO - 2018-10-21 16:57:37 --> URI Class Initialized
DEBUG - 2018-10-21 16:57:37 --> No URI present. Default controller set.
INFO - 2018-10-21 16:57:37 --> Router Class Initialized
INFO - 2018-10-21 16:57:37 --> Output Class Initialized
INFO - 2018-10-21 16:57:37 --> Security Class Initialized
DEBUG - 2018-10-21 16:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 16:57:37 --> Input Class Initialized
INFO - 2018-10-21 16:57:37 --> Language Class Initialized
INFO - 2018-10-21 16:57:37 --> Language Class Initialized
INFO - 2018-10-21 16:57:37 --> Config Class Initialized
INFO - 2018-10-21 16:57:37 --> Loader Class Initialized
INFO - 2018-10-21 16:57:37 --> Helper loaded: url_helper
INFO - 2018-10-21 16:57:37 --> Helper loaded: form_helper
INFO - 2018-10-21 16:57:37 --> Helper loaded: html_helper
INFO - 2018-10-21 16:57:37 --> Controller Class Initialized
DEBUG - 2018-10-21 16:57:37 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 16:57:37 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 16:57:37 --> Final output sent to browser
DEBUG - 2018-10-21 16:57:37 --> Total execution time: 0.2372
INFO - 2018-10-21 16:58:49 --> Config Class Initialized
INFO - 2018-10-21 16:58:49 --> Hooks Class Initialized
DEBUG - 2018-10-21 16:58:49 --> UTF-8 Support Enabled
INFO - 2018-10-21 16:58:49 --> Utf8 Class Initialized
INFO - 2018-10-21 16:58:49 --> URI Class Initialized
DEBUG - 2018-10-21 16:58:49 --> No URI present. Default controller set.
INFO - 2018-10-21 16:58:49 --> Router Class Initialized
INFO - 2018-10-21 16:58:49 --> Output Class Initialized
INFO - 2018-10-21 16:58:49 --> Security Class Initialized
DEBUG - 2018-10-21 16:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 16:58:49 --> Input Class Initialized
INFO - 2018-10-21 16:58:49 --> Language Class Initialized
INFO - 2018-10-21 16:58:49 --> Language Class Initialized
INFO - 2018-10-21 16:58:49 --> Config Class Initialized
INFO - 2018-10-21 16:58:50 --> Loader Class Initialized
INFO - 2018-10-21 16:58:50 --> Helper loaded: url_helper
INFO - 2018-10-21 16:58:50 --> Helper loaded: form_helper
INFO - 2018-10-21 16:58:50 --> Helper loaded: html_helper
INFO - 2018-10-21 16:58:50 --> Controller Class Initialized
DEBUG - 2018-10-21 16:58:50 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 16:58:50 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 16:58:50 --> Final output sent to browser
DEBUG - 2018-10-21 16:58:50 --> Total execution time: 0.4495
INFO - 2018-10-21 16:59:11 --> Config Class Initialized
INFO - 2018-10-21 16:59:11 --> Hooks Class Initialized
DEBUG - 2018-10-21 16:59:11 --> UTF-8 Support Enabled
INFO - 2018-10-21 16:59:11 --> Utf8 Class Initialized
INFO - 2018-10-21 16:59:11 --> URI Class Initialized
DEBUG - 2018-10-21 16:59:11 --> No URI present. Default controller set.
INFO - 2018-10-21 16:59:11 --> Router Class Initialized
INFO - 2018-10-21 16:59:11 --> Output Class Initialized
INFO - 2018-10-21 16:59:11 --> Security Class Initialized
DEBUG - 2018-10-21 16:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 16:59:11 --> Input Class Initialized
INFO - 2018-10-21 16:59:11 --> Language Class Initialized
INFO - 2018-10-21 16:59:11 --> Language Class Initialized
INFO - 2018-10-21 16:59:11 --> Config Class Initialized
INFO - 2018-10-21 16:59:11 --> Loader Class Initialized
INFO - 2018-10-21 16:59:11 --> Helper loaded: url_helper
INFO - 2018-10-21 16:59:11 --> Helper loaded: form_helper
INFO - 2018-10-21 16:59:11 --> Helper loaded: html_helper
INFO - 2018-10-21 16:59:11 --> Controller Class Initialized
DEBUG - 2018-10-21 16:59:12 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 16:59:12 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 16:59:12 --> Final output sent to browser
DEBUG - 2018-10-21 16:59:12 --> Total execution time: 0.3057
INFO - 2018-10-21 17:03:05 --> Config Class Initialized
INFO - 2018-10-21 17:03:05 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:03:05 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:03:05 --> Utf8 Class Initialized
INFO - 2018-10-21 17:03:05 --> URI Class Initialized
DEBUG - 2018-10-21 17:03:05 --> No URI present. Default controller set.
INFO - 2018-10-21 17:03:05 --> Router Class Initialized
INFO - 2018-10-21 17:03:05 --> Output Class Initialized
INFO - 2018-10-21 17:03:05 --> Security Class Initialized
DEBUG - 2018-10-21 17:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:03:05 --> Input Class Initialized
INFO - 2018-10-21 17:03:05 --> Language Class Initialized
INFO - 2018-10-21 17:03:05 --> Language Class Initialized
INFO - 2018-10-21 17:03:05 --> Config Class Initialized
INFO - 2018-10-21 17:03:05 --> Loader Class Initialized
INFO - 2018-10-21 17:03:05 --> Helper loaded: url_helper
INFO - 2018-10-21 17:03:05 --> Helper loaded: form_helper
INFO - 2018-10-21 17:03:05 --> Helper loaded: html_helper
INFO - 2018-10-21 17:03:05 --> Controller Class Initialized
DEBUG - 2018-10-21 17:03:05 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:03:05 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:03:05 --> Final output sent to browser
DEBUG - 2018-10-21 17:03:05 --> Total execution time: 0.3174
INFO - 2018-10-21 17:03:30 --> Config Class Initialized
INFO - 2018-10-21 17:03:30 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:03:30 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:03:30 --> Utf8 Class Initialized
INFO - 2018-10-21 17:03:30 --> URI Class Initialized
DEBUG - 2018-10-21 17:03:30 --> No URI present. Default controller set.
INFO - 2018-10-21 17:03:30 --> Router Class Initialized
INFO - 2018-10-21 17:03:30 --> Output Class Initialized
INFO - 2018-10-21 17:03:30 --> Security Class Initialized
DEBUG - 2018-10-21 17:03:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:03:30 --> Input Class Initialized
INFO - 2018-10-21 17:03:30 --> Language Class Initialized
INFO - 2018-10-21 17:03:30 --> Language Class Initialized
INFO - 2018-10-21 17:03:30 --> Config Class Initialized
INFO - 2018-10-21 17:03:30 --> Loader Class Initialized
INFO - 2018-10-21 17:03:30 --> Helper loaded: url_helper
INFO - 2018-10-21 17:03:30 --> Helper loaded: form_helper
INFO - 2018-10-21 17:03:30 --> Helper loaded: html_helper
INFO - 2018-10-21 17:03:30 --> Controller Class Initialized
DEBUG - 2018-10-21 17:03:30 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:03:30 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:03:30 --> Final output sent to browser
DEBUG - 2018-10-21 17:03:30 --> Total execution time: 0.3203
INFO - 2018-10-21 17:04:06 --> Config Class Initialized
INFO - 2018-10-21 17:04:06 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:04:06 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:04:06 --> Utf8 Class Initialized
INFO - 2018-10-21 17:04:06 --> URI Class Initialized
DEBUG - 2018-10-21 17:04:06 --> No URI present. Default controller set.
INFO - 2018-10-21 17:04:07 --> Router Class Initialized
INFO - 2018-10-21 17:04:07 --> Output Class Initialized
INFO - 2018-10-21 17:04:07 --> Security Class Initialized
DEBUG - 2018-10-21 17:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:04:07 --> Input Class Initialized
INFO - 2018-10-21 17:04:07 --> Language Class Initialized
INFO - 2018-10-21 17:04:07 --> Language Class Initialized
INFO - 2018-10-21 17:04:07 --> Config Class Initialized
INFO - 2018-10-21 17:04:07 --> Loader Class Initialized
INFO - 2018-10-21 17:04:07 --> Helper loaded: url_helper
INFO - 2018-10-21 17:04:07 --> Helper loaded: form_helper
INFO - 2018-10-21 17:04:07 --> Helper loaded: html_helper
INFO - 2018-10-21 17:04:07 --> Controller Class Initialized
DEBUG - 2018-10-21 17:04:07 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:04:07 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:04:07 --> Final output sent to browser
DEBUG - 2018-10-21 17:04:07 --> Total execution time: 0.3775
INFO - 2018-10-21 17:04:07 --> Config Class Initialized
INFO - 2018-10-21 17:04:07 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:04:07 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:04:07 --> Utf8 Class Initialized
INFO - 2018-10-21 17:04:07 --> URI Class Initialized
DEBUG - 2018-10-21 17:04:07 --> No URI present. Default controller set.
INFO - 2018-10-21 17:04:07 --> Router Class Initialized
INFO - 2018-10-21 17:04:07 --> Output Class Initialized
INFO - 2018-10-21 17:04:07 --> Security Class Initialized
DEBUG - 2018-10-21 17:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:04:07 --> Input Class Initialized
INFO - 2018-10-21 17:04:07 --> Language Class Initialized
INFO - 2018-10-21 17:04:07 --> Language Class Initialized
INFO - 2018-10-21 17:04:07 --> Config Class Initialized
INFO - 2018-10-21 17:04:07 --> Config Class Initialized
INFO - 2018-10-21 17:04:07 --> Loader Class Initialized
INFO - 2018-10-21 17:04:07 --> Hooks Class Initialized
INFO - 2018-10-21 17:04:07 --> Helper loaded: url_helper
DEBUG - 2018-10-21 17:04:07 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:04:07 --> Utf8 Class Initialized
INFO - 2018-10-21 17:04:07 --> Helper loaded: form_helper
INFO - 2018-10-21 17:04:07 --> URI Class Initialized
INFO - 2018-10-21 17:04:07 --> Helper loaded: html_helper
DEBUG - 2018-10-21 17:04:07 --> No URI present. Default controller set.
INFO - 2018-10-21 17:04:07 --> Controller Class Initialized
INFO - 2018-10-21 17:04:07 --> Router Class Initialized
INFO - 2018-10-21 17:04:07 --> Config Class Initialized
INFO - 2018-10-21 17:04:07 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:04:07 --> Products MX_Controller Initialized
INFO - 2018-10-21 17:04:07 --> Output Class Initialized
DEBUG - 2018-10-21 17:04:07 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
DEBUG - 2018-10-21 17:04:07 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:04:07 --> Security Class Initialized
INFO - 2018-10-21 17:04:07 --> Utf8 Class Initialized
INFO - 2018-10-21 17:04:07 --> Final output sent to browser
DEBUG - 2018-10-21 17:04:07 --> Total execution time: 0.3669
DEBUG - 2018-10-21 17:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:04:07 --> URI Class Initialized
INFO - 2018-10-21 17:04:07 --> Input Class Initialized
DEBUG - 2018-10-21 17:04:07 --> No URI present. Default controller set.
INFO - 2018-10-21 17:04:07 --> Language Class Initialized
INFO - 2018-10-21 17:04:07 --> Router Class Initialized
INFO - 2018-10-21 17:04:07 --> Output Class Initialized
INFO - 2018-10-21 17:04:07 --> Language Class Initialized
INFO - 2018-10-21 17:04:07 --> Config Class Initialized
INFO - 2018-10-21 17:04:07 --> Security Class Initialized
INFO - 2018-10-21 17:04:07 --> Loader Class Initialized
DEBUG - 2018-10-21 17:04:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:04:07 --> Helper loaded: url_helper
INFO - 2018-10-21 17:04:07 --> Input Class Initialized
INFO - 2018-10-21 17:04:07 --> Language Class Initialized
INFO - 2018-10-21 17:04:07 --> Helper loaded: form_helper
INFO - 2018-10-21 17:04:07 --> Language Class Initialized
INFO - 2018-10-21 17:04:07 --> Helper loaded: html_helper
INFO - 2018-10-21 17:04:07 --> Config Class Initialized
INFO - 2018-10-21 17:04:07 --> Controller Class Initialized
INFO - 2018-10-21 17:04:07 --> Loader Class Initialized
DEBUG - 2018-10-21 17:04:07 --> Products MX_Controller Initialized
INFO - 2018-10-21 17:04:07 --> Helper loaded: url_helper
DEBUG - 2018-10-21 17:04:08 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:04:08 --> Helper loaded: form_helper
INFO - 2018-10-21 17:04:08 --> Final output sent to browser
DEBUG - 2018-10-21 17:04:08 --> Total execution time: 0.4818
INFO - 2018-10-21 17:04:08 --> Helper loaded: html_helper
INFO - 2018-10-21 17:04:08 --> Controller Class Initialized
DEBUG - 2018-10-21 17:04:08 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:04:08 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:04:08 --> Final output sent to browser
DEBUG - 2018-10-21 17:04:08 --> Total execution time: 0.4457
INFO - 2018-10-21 17:04:18 --> Config Class Initialized
INFO - 2018-10-21 17:04:18 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:04:18 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:04:18 --> Utf8 Class Initialized
INFO - 2018-10-21 17:04:18 --> URI Class Initialized
DEBUG - 2018-10-21 17:04:18 --> No URI present. Default controller set.
INFO - 2018-10-21 17:04:18 --> Router Class Initialized
INFO - 2018-10-21 17:04:18 --> Output Class Initialized
INFO - 2018-10-21 17:04:18 --> Security Class Initialized
DEBUG - 2018-10-21 17:04:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:04:18 --> Input Class Initialized
INFO - 2018-10-21 17:04:18 --> Language Class Initialized
INFO - 2018-10-21 17:04:18 --> Language Class Initialized
INFO - 2018-10-21 17:04:18 --> Config Class Initialized
INFO - 2018-10-21 17:04:18 --> Loader Class Initialized
INFO - 2018-10-21 17:04:18 --> Helper loaded: url_helper
INFO - 2018-10-21 17:04:18 --> Helper loaded: form_helper
INFO - 2018-10-21 17:04:18 --> Helper loaded: html_helper
INFO - 2018-10-21 17:04:18 --> Controller Class Initialized
DEBUG - 2018-10-21 17:04:18 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:04:18 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:04:18 --> Final output sent to browser
DEBUG - 2018-10-21 17:04:19 --> Total execution time: 0.4375
INFO - 2018-10-21 17:04:22 --> Config Class Initialized
INFO - 2018-10-21 17:04:22 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:04:22 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:04:22 --> Utf8 Class Initialized
INFO - 2018-10-21 17:04:22 --> URI Class Initialized
DEBUG - 2018-10-21 17:04:22 --> No URI present. Default controller set.
INFO - 2018-10-21 17:04:22 --> Router Class Initialized
INFO - 2018-10-21 17:04:23 --> Output Class Initialized
INFO - 2018-10-21 17:04:23 --> Security Class Initialized
DEBUG - 2018-10-21 17:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:04:23 --> Input Class Initialized
INFO - 2018-10-21 17:04:23 --> Language Class Initialized
INFO - 2018-10-21 17:04:23 --> Language Class Initialized
INFO - 2018-10-21 17:04:23 --> Config Class Initialized
INFO - 2018-10-21 17:04:23 --> Loader Class Initialized
INFO - 2018-10-21 17:04:23 --> Helper loaded: url_helper
INFO - 2018-10-21 17:04:23 --> Helper loaded: form_helper
INFO - 2018-10-21 17:04:23 --> Helper loaded: html_helper
INFO - 2018-10-21 17:04:23 --> Controller Class Initialized
DEBUG - 2018-10-21 17:04:23 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:04:23 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:04:23 --> Final output sent to browser
DEBUG - 2018-10-21 17:04:23 --> Total execution time: 0.3572
INFO - 2018-10-21 17:04:23 --> Config Class Initialized
INFO - 2018-10-21 17:04:23 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:04:23 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:04:23 --> Utf8 Class Initialized
INFO - 2018-10-21 17:04:23 --> URI Class Initialized
DEBUG - 2018-10-21 17:04:23 --> No URI present. Default controller set.
INFO - 2018-10-21 17:04:23 --> Router Class Initialized
INFO - 2018-10-21 17:04:23 --> Output Class Initialized
INFO - 2018-10-21 17:04:23 --> Security Class Initialized
DEBUG - 2018-10-21 17:04:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:04:23 --> Input Class Initialized
INFO - 2018-10-21 17:04:23 --> Language Class Initialized
INFO - 2018-10-21 17:04:24 --> Language Class Initialized
INFO - 2018-10-21 17:04:24 --> Config Class Initialized
INFO - 2018-10-21 17:04:24 --> Loader Class Initialized
INFO - 2018-10-21 17:04:24 --> Helper loaded: url_helper
INFO - 2018-10-21 17:04:24 --> Helper loaded: form_helper
INFO - 2018-10-21 17:04:24 --> Helper loaded: html_helper
INFO - 2018-10-21 17:04:24 --> Controller Class Initialized
DEBUG - 2018-10-21 17:04:24 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:04:24 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:04:24 --> Final output sent to browser
DEBUG - 2018-10-21 17:04:24 --> Total execution time: 0.5474
INFO - 2018-10-21 17:04:24 --> Config Class Initialized
INFO - 2018-10-21 17:04:24 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:04:24 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:04:24 --> Utf8 Class Initialized
INFO - 2018-10-21 17:04:24 --> URI Class Initialized
DEBUG - 2018-10-21 17:04:24 --> No URI present. Default controller set.
INFO - 2018-10-21 17:04:24 --> Router Class Initialized
INFO - 2018-10-21 17:04:24 --> Output Class Initialized
INFO - 2018-10-21 17:04:24 --> Security Class Initialized
DEBUG - 2018-10-21 17:04:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:04:24 --> Input Class Initialized
INFO - 2018-10-21 17:04:24 --> Language Class Initialized
INFO - 2018-10-21 17:04:24 --> Language Class Initialized
INFO - 2018-10-21 17:04:24 --> Config Class Initialized
INFO - 2018-10-21 17:04:24 --> Loader Class Initialized
INFO - 2018-10-21 17:04:24 --> Helper loaded: url_helper
INFO - 2018-10-21 17:04:24 --> Helper loaded: form_helper
INFO - 2018-10-21 17:04:24 --> Helper loaded: html_helper
INFO - 2018-10-21 17:04:24 --> Controller Class Initialized
DEBUG - 2018-10-21 17:04:25 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:04:25 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:04:25 --> Final output sent to browser
DEBUG - 2018-10-21 17:04:25 --> Total execution time: 0.5984
INFO - 2018-10-21 17:04:25 --> Config Class Initialized
INFO - 2018-10-21 17:04:25 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:04:25 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:04:25 --> Utf8 Class Initialized
INFO - 2018-10-21 17:04:25 --> URI Class Initialized
DEBUG - 2018-10-21 17:04:25 --> No URI present. Default controller set.
INFO - 2018-10-21 17:04:25 --> Router Class Initialized
INFO - 2018-10-21 17:04:25 --> Output Class Initialized
INFO - 2018-10-21 17:04:25 --> Security Class Initialized
DEBUG - 2018-10-21 17:04:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:04:25 --> Input Class Initialized
INFO - 2018-10-21 17:04:25 --> Language Class Initialized
INFO - 2018-10-21 17:04:25 --> Language Class Initialized
INFO - 2018-10-21 17:04:25 --> Config Class Initialized
INFO - 2018-10-21 17:04:25 --> Loader Class Initialized
INFO - 2018-10-21 17:04:25 --> Helper loaded: url_helper
INFO - 2018-10-21 17:04:25 --> Helper loaded: form_helper
INFO - 2018-10-21 17:04:25 --> Helper loaded: html_helper
INFO - 2018-10-21 17:04:25 --> Controller Class Initialized
DEBUG - 2018-10-21 17:04:25 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:04:25 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:04:25 --> Final output sent to browser
DEBUG - 2018-10-21 17:04:25 --> Total execution time: 0.5506
INFO - 2018-10-21 17:04:27 --> Config Class Initialized
INFO - 2018-10-21 17:04:27 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:04:27 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:04:27 --> Utf8 Class Initialized
INFO - 2018-10-21 17:04:27 --> URI Class Initialized
DEBUG - 2018-10-21 17:04:27 --> No URI present. Default controller set.
INFO - 2018-10-21 17:04:28 --> Router Class Initialized
INFO - 2018-10-21 17:04:28 --> Output Class Initialized
INFO - 2018-10-21 17:04:28 --> Security Class Initialized
DEBUG - 2018-10-21 17:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:04:28 --> Input Class Initialized
INFO - 2018-10-21 17:04:28 --> Language Class Initialized
INFO - 2018-10-21 17:04:28 --> Language Class Initialized
INFO - 2018-10-21 17:04:28 --> Config Class Initialized
INFO - 2018-10-21 17:04:28 --> Loader Class Initialized
INFO - 2018-10-21 17:04:28 --> Helper loaded: url_helper
INFO - 2018-10-21 17:04:28 --> Helper loaded: form_helper
INFO - 2018-10-21 17:04:28 --> Helper loaded: html_helper
INFO - 2018-10-21 17:04:28 --> Controller Class Initialized
DEBUG - 2018-10-21 17:04:28 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:04:28 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:04:28 --> Final output sent to browser
DEBUG - 2018-10-21 17:04:28 --> Total execution time: 0.6659
INFO - 2018-10-21 17:05:04 --> Config Class Initialized
INFO - 2018-10-21 17:05:04 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:05:04 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:05:04 --> Utf8 Class Initialized
INFO - 2018-10-21 17:05:04 --> URI Class Initialized
DEBUG - 2018-10-21 17:05:04 --> No URI present. Default controller set.
INFO - 2018-10-21 17:05:04 --> Router Class Initialized
INFO - 2018-10-21 17:05:04 --> Output Class Initialized
INFO - 2018-10-21 17:05:04 --> Security Class Initialized
DEBUG - 2018-10-21 17:05:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:05:05 --> Input Class Initialized
INFO - 2018-10-21 17:05:05 --> Language Class Initialized
INFO - 2018-10-21 17:05:05 --> Language Class Initialized
INFO - 2018-10-21 17:05:05 --> Config Class Initialized
INFO - 2018-10-21 17:05:05 --> Loader Class Initialized
INFO - 2018-10-21 17:05:05 --> Helper loaded: url_helper
INFO - 2018-10-21 17:05:05 --> Helper loaded: form_helper
INFO - 2018-10-21 17:05:05 --> Helper loaded: html_helper
INFO - 2018-10-21 17:05:05 --> Controller Class Initialized
DEBUG - 2018-10-21 17:05:05 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:05:05 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:05:05 --> Final output sent to browser
DEBUG - 2018-10-21 17:05:05 --> Total execution time: 0.5795
INFO - 2018-10-21 17:05:22 --> Config Class Initialized
INFO - 2018-10-21 17:05:22 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:05:22 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:05:22 --> Utf8 Class Initialized
INFO - 2018-10-21 17:05:22 --> URI Class Initialized
DEBUG - 2018-10-21 17:05:22 --> No URI present. Default controller set.
INFO - 2018-10-21 17:05:22 --> Router Class Initialized
INFO - 2018-10-21 17:05:22 --> Output Class Initialized
INFO - 2018-10-21 17:05:22 --> Security Class Initialized
DEBUG - 2018-10-21 17:05:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:05:22 --> Input Class Initialized
INFO - 2018-10-21 17:05:22 --> Language Class Initialized
INFO - 2018-10-21 17:05:22 --> Language Class Initialized
INFO - 2018-10-21 17:05:22 --> Config Class Initialized
INFO - 2018-10-21 17:05:22 --> Loader Class Initialized
INFO - 2018-10-21 17:05:22 --> Helper loaded: url_helper
INFO - 2018-10-21 17:05:22 --> Helper loaded: form_helper
INFO - 2018-10-21 17:05:22 --> Helper loaded: html_helper
INFO - 2018-10-21 17:05:22 --> Controller Class Initialized
DEBUG - 2018-10-21 17:05:22 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:05:22 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:05:22 --> Final output sent to browser
DEBUG - 2018-10-21 17:05:22 --> Total execution time: 0.2602
INFO - 2018-10-21 17:05:23 --> Config Class Initialized
INFO - 2018-10-21 17:05:23 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:05:23 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:05:23 --> Utf8 Class Initialized
INFO - 2018-10-21 17:05:23 --> URI Class Initialized
DEBUG - 2018-10-21 17:05:23 --> No URI present. Default controller set.
INFO - 2018-10-21 17:05:23 --> Router Class Initialized
INFO - 2018-10-21 17:05:23 --> Output Class Initialized
INFO - 2018-10-21 17:05:23 --> Security Class Initialized
DEBUG - 2018-10-21 17:05:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:05:23 --> Input Class Initialized
INFO - 2018-10-21 17:05:23 --> Language Class Initialized
INFO - 2018-10-21 17:05:23 --> Language Class Initialized
INFO - 2018-10-21 17:05:23 --> Config Class Initialized
INFO - 2018-10-21 17:05:23 --> Loader Class Initialized
INFO - 2018-10-21 17:05:23 --> Helper loaded: url_helper
INFO - 2018-10-21 17:05:23 --> Helper loaded: form_helper
INFO - 2018-10-21 17:05:23 --> Helper loaded: html_helper
INFO - 2018-10-21 17:05:23 --> Controller Class Initialized
DEBUG - 2018-10-21 17:05:23 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:05:23 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:05:23 --> Final output sent to browser
DEBUG - 2018-10-21 17:05:23 --> Total execution time: 0.6673
INFO - 2018-10-21 17:05:46 --> Config Class Initialized
INFO - 2018-10-21 17:05:46 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:05:46 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:05:46 --> Utf8 Class Initialized
INFO - 2018-10-21 17:05:46 --> URI Class Initialized
DEBUG - 2018-10-21 17:05:46 --> No URI present. Default controller set.
INFO - 2018-10-21 17:05:46 --> Router Class Initialized
INFO - 2018-10-21 17:05:46 --> Config Class Initialized
INFO - 2018-10-21 17:05:46 --> Output Class Initialized
INFO - 2018-10-21 17:05:46 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:05:46 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:05:46 --> Security Class Initialized
INFO - 2018-10-21 17:05:46 --> Utf8 Class Initialized
DEBUG - 2018-10-21 17:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:05:46 --> URI Class Initialized
INFO - 2018-10-21 17:05:46 --> Input Class Initialized
INFO - 2018-10-21 17:05:47 --> Language Class Initialized
INFO - 2018-10-21 17:05:47 --> Config Class Initialized
DEBUG - 2018-10-21 17:05:47 --> No URI present. Default controller set.
INFO - 2018-10-21 17:05:47 --> Hooks Class Initialized
INFO - 2018-10-21 17:05:47 --> Language Class Initialized
INFO - 2018-10-21 17:05:47 --> Router Class Initialized
DEBUG - 2018-10-21 17:05:47 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:05:47 --> Config Class Initialized
INFO - 2018-10-21 17:05:47 --> Output Class Initialized
INFO - 2018-10-21 17:05:47 --> Utf8 Class Initialized
INFO - 2018-10-21 17:05:47 --> Loader Class Initialized
INFO - 2018-10-21 17:05:47 --> Security Class Initialized
INFO - 2018-10-21 17:05:47 --> URI Class Initialized
INFO - 2018-10-21 17:05:47 --> Helper loaded: url_helper
DEBUG - 2018-10-21 17:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:05:47 --> Config Class Initialized
INFO - 2018-10-21 17:05:47 --> Input Class Initialized
DEBUG - 2018-10-21 17:05:47 --> No URI present. Default controller set.
INFO - 2018-10-21 17:05:47 --> Router Class Initialized
INFO - 2018-10-21 17:05:47 --> Hooks Class Initialized
INFO - 2018-10-21 17:05:47 --> Language Class Initialized
INFO - 2018-10-21 17:05:47 --> Helper loaded: form_helper
INFO - 2018-10-21 17:05:47 --> Output Class Initialized
INFO - 2018-10-21 17:05:47 --> Language Class Initialized
DEBUG - 2018-10-21 17:05:47 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:05:47 --> Utf8 Class Initialized
INFO - 2018-10-21 17:05:47 --> Config Class Initialized
INFO - 2018-10-21 17:05:47 --> Helper loaded: html_helper
INFO - 2018-10-21 17:05:47 --> Security Class Initialized
INFO - 2018-10-21 17:05:47 --> URI Class Initialized
INFO - 2018-10-21 17:05:47 --> Loader Class Initialized
INFO - 2018-10-21 17:05:47 --> Controller Class Initialized
DEBUG - 2018-10-21 17:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:05:47 --> Helper loaded: url_helper
DEBUG - 2018-10-21 17:05:47 --> No URI present. Default controller set.
INFO - 2018-10-21 17:05:47 --> Input Class Initialized
DEBUG - 2018-10-21 17:05:47 --> Products MX_Controller Initialized
INFO - 2018-10-21 17:05:47 --> Router Class Initialized
INFO - 2018-10-21 17:05:47 --> Language Class Initialized
INFO - 2018-10-21 17:05:47 --> Helper loaded: form_helper
DEBUG - 2018-10-21 17:05:47 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:05:47 --> Output Class Initialized
INFO - 2018-10-21 17:05:47 --> Language Class Initialized
INFO - 2018-10-21 17:05:47 --> Final output sent to browser
INFO - 2018-10-21 17:05:47 --> Helper loaded: html_helper
INFO - 2018-10-21 17:05:47 --> Config Class Initialized
DEBUG - 2018-10-21 17:05:47 --> Total execution time: 0.5757
INFO - 2018-10-21 17:05:47 --> Security Class Initialized
INFO - 2018-10-21 17:05:47 --> Controller Class Initialized
INFO - 2018-10-21 17:05:47 --> Loader Class Initialized
DEBUG - 2018-10-21 17:05:47 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:05:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:05:47 --> Helper loaded: url_helper
INFO - 2018-10-21 17:05:47 --> Input Class Initialized
DEBUG - 2018-10-21 17:05:47 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:05:47 --> Final output sent to browser
INFO - 2018-10-21 17:05:47 --> Helper loaded: form_helper
INFO - 2018-10-21 17:05:47 --> Language Class Initialized
DEBUG - 2018-10-21 17:05:47 --> Total execution time: 0.4810
INFO - 2018-10-21 17:05:47 --> Language Class Initialized
INFO - 2018-10-21 17:05:47 --> Helper loaded: html_helper
INFO - 2018-10-21 17:05:47 --> Config Class Initialized
INFO - 2018-10-21 17:05:47 --> Controller Class Initialized
DEBUG - 2018-10-21 17:05:47 --> Products MX_Controller Initialized
INFO - 2018-10-21 17:05:47 --> Loader Class Initialized
DEBUG - 2018-10-21 17:05:47 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:05:47 --> Helper loaded: url_helper
INFO - 2018-10-21 17:05:47 --> Final output sent to browser
DEBUG - 2018-10-21 17:05:47 --> Total execution time: 0.4662
INFO - 2018-10-21 17:05:47 --> Helper loaded: form_helper
INFO - 2018-10-21 17:05:47 --> Helper loaded: html_helper
INFO - 2018-10-21 17:05:47 --> Controller Class Initialized
DEBUG - 2018-10-21 17:05:47 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:05:47 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:05:47 --> Final output sent to browser
DEBUG - 2018-10-21 17:05:47 --> Total execution time: 0.4521
INFO - 2018-10-21 17:05:52 --> Config Class Initialized
INFO - 2018-10-21 17:05:52 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:05:52 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:05:52 --> Utf8 Class Initialized
INFO - 2018-10-21 17:05:52 --> URI Class Initialized
INFO - 2018-10-21 17:05:52 --> Router Class Initialized
INFO - 2018-10-21 17:05:52 --> Output Class Initialized
INFO - 2018-10-21 17:05:52 --> Security Class Initialized
DEBUG - 2018-10-21 17:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:05:52 --> Input Class Initialized
INFO - 2018-10-21 17:05:52 --> Language Class Initialized
INFO - 2018-10-21 17:05:52 --> Language Class Initialized
INFO - 2018-10-21 17:05:52 --> Config Class Initialized
INFO - 2018-10-21 17:05:52 --> Loader Class Initialized
INFO - 2018-10-21 17:05:52 --> Helper loaded: url_helper
INFO - 2018-10-21 17:05:52 --> Helper loaded: form_helper
INFO - 2018-10-21 17:05:52 --> Helper loaded: html_helper
INFO - 2018-10-21 17:05:52 --> Controller Class Initialized
ERROR - 2018-10-21 17:05:52 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:06:20 --> Config Class Initialized
INFO - 2018-10-21 17:06:20 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:06:20 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:06:20 --> Utf8 Class Initialized
INFO - 2018-10-21 17:06:20 --> URI Class Initialized
DEBUG - 2018-10-21 17:06:20 --> No URI present. Default controller set.
INFO - 2018-10-21 17:06:20 --> Router Class Initialized
INFO - 2018-10-21 17:06:20 --> Output Class Initialized
INFO - 2018-10-21 17:06:20 --> Security Class Initialized
DEBUG - 2018-10-21 17:06:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:06:20 --> Input Class Initialized
INFO - 2018-10-21 17:06:20 --> Language Class Initialized
INFO - 2018-10-21 17:06:20 --> Language Class Initialized
INFO - 2018-10-21 17:06:20 --> Config Class Initialized
INFO - 2018-10-21 17:06:20 --> Loader Class Initialized
INFO - 2018-10-21 17:06:20 --> Helper loaded: url_helper
INFO - 2018-10-21 17:06:20 --> Helper loaded: form_helper
INFO - 2018-10-21 17:06:20 --> Helper loaded: html_helper
INFO - 2018-10-21 17:06:21 --> Controller Class Initialized
DEBUG - 2018-10-21 17:06:21 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:06:21 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:06:21 --> Final output sent to browser
DEBUG - 2018-10-21 17:06:21 --> Total execution time: 0.2889
INFO - 2018-10-21 17:06:30 --> Config Class Initialized
INFO - 2018-10-21 17:06:30 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:06:30 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:06:30 --> Utf8 Class Initialized
INFO - 2018-10-21 17:06:30 --> URI Class Initialized
INFO - 2018-10-21 17:06:31 --> Router Class Initialized
INFO - 2018-10-21 17:06:31 --> Output Class Initialized
INFO - 2018-10-21 17:06:31 --> Security Class Initialized
DEBUG - 2018-10-21 17:06:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:06:31 --> Input Class Initialized
INFO - 2018-10-21 17:06:31 --> Language Class Initialized
INFO - 2018-10-21 17:06:31 --> Language Class Initialized
INFO - 2018-10-21 17:06:31 --> Config Class Initialized
INFO - 2018-10-21 17:06:31 --> Loader Class Initialized
INFO - 2018-10-21 17:06:31 --> Helper loaded: url_helper
INFO - 2018-10-21 17:06:31 --> Helper loaded: form_helper
INFO - 2018-10-21 17:06:31 --> Helper loaded: html_helper
INFO - 2018-10-21 17:06:31 --> Controller Class Initialized
ERROR - 2018-10-21 17:06:31 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:08:15 --> Config Class Initialized
INFO - 2018-10-21 17:08:15 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:08:15 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:08:15 --> Utf8 Class Initialized
INFO - 2018-10-21 17:08:15 --> URI Class Initialized
DEBUG - 2018-10-21 17:08:15 --> No URI present. Default controller set.
INFO - 2018-10-21 17:08:15 --> Router Class Initialized
INFO - 2018-10-21 17:08:15 --> Output Class Initialized
INFO - 2018-10-21 17:08:15 --> Security Class Initialized
DEBUG - 2018-10-21 17:08:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:08:15 --> Input Class Initialized
INFO - 2018-10-21 17:08:15 --> Language Class Initialized
INFO - 2018-10-21 17:08:15 --> Language Class Initialized
INFO - 2018-10-21 17:08:15 --> Config Class Initialized
INFO - 2018-10-21 17:08:15 --> Loader Class Initialized
INFO - 2018-10-21 17:08:15 --> Helper loaded: url_helper
INFO - 2018-10-21 17:08:15 --> Helper loaded: form_helper
INFO - 2018-10-21 17:08:15 --> Helper loaded: html_helper
INFO - 2018-10-21 17:08:15 --> Controller Class Initialized
DEBUG - 2018-10-21 17:08:15 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:08:15 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:08:15 --> Final output sent to browser
DEBUG - 2018-10-21 17:08:15 --> Total execution time: 0.5489
INFO - 2018-10-21 17:08:25 --> Config Class Initialized
INFO - 2018-10-21 17:08:25 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:08:25 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:08:25 --> Utf8 Class Initialized
INFO - 2018-10-21 17:08:25 --> URI Class Initialized
DEBUG - 2018-10-21 17:08:25 --> No URI present. Default controller set.
INFO - 2018-10-21 17:08:25 --> Router Class Initialized
INFO - 2018-10-21 17:08:25 --> Output Class Initialized
INFO - 2018-10-21 17:08:25 --> Security Class Initialized
DEBUG - 2018-10-21 17:08:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:08:25 --> Input Class Initialized
INFO - 2018-10-21 17:08:25 --> Language Class Initialized
INFO - 2018-10-21 17:08:25 --> Language Class Initialized
INFO - 2018-10-21 17:08:25 --> Config Class Initialized
INFO - 2018-10-21 17:08:25 --> Loader Class Initialized
INFO - 2018-10-21 17:08:25 --> Helper loaded: url_helper
INFO - 2018-10-21 17:08:25 --> Helper loaded: form_helper
INFO - 2018-10-21 17:08:25 --> Helper loaded: html_helper
INFO - 2018-10-21 17:08:25 --> Controller Class Initialized
DEBUG - 2018-10-21 17:08:25 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:08:25 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:08:26 --> Final output sent to browser
DEBUG - 2018-10-21 17:08:26 --> Total execution time: 0.7491
INFO - 2018-10-21 17:08:27 --> Config Class Initialized
INFO - 2018-10-21 17:08:27 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:08:27 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:08:27 --> Utf8 Class Initialized
INFO - 2018-10-21 17:08:27 --> URI Class Initialized
DEBUG - 2018-10-21 17:08:27 --> No URI present. Default controller set.
INFO - 2018-10-21 17:08:27 --> Router Class Initialized
INFO - 2018-10-21 17:08:27 --> Output Class Initialized
INFO - 2018-10-21 17:08:27 --> Security Class Initialized
DEBUG - 2018-10-21 17:08:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:08:27 --> Input Class Initialized
INFO - 2018-10-21 17:08:28 --> Language Class Initialized
INFO - 2018-10-21 17:08:28 --> Language Class Initialized
INFO - 2018-10-21 17:08:28 --> Config Class Initialized
INFO - 2018-10-21 17:08:28 --> Loader Class Initialized
INFO - 2018-10-21 17:08:28 --> Helper loaded: url_helper
INFO - 2018-10-21 17:08:28 --> Helper loaded: form_helper
INFO - 2018-10-21 17:08:28 --> Helper loaded: html_helper
INFO - 2018-10-21 17:08:28 --> Controller Class Initialized
DEBUG - 2018-10-21 17:08:28 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:08:28 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:08:28 --> Final output sent to browser
DEBUG - 2018-10-21 17:08:28 --> Total execution time: 0.7284
INFO - 2018-10-21 17:08:35 --> Config Class Initialized
INFO - 2018-10-21 17:08:35 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:08:35 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:08:35 --> Utf8 Class Initialized
INFO - 2018-10-21 17:08:35 --> URI Class Initialized
INFO - 2018-10-21 17:08:35 --> Router Class Initialized
INFO - 2018-10-21 17:08:35 --> Output Class Initialized
INFO - 2018-10-21 17:08:35 --> Security Class Initialized
DEBUG - 2018-10-21 17:08:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:08:35 --> Input Class Initialized
INFO - 2018-10-21 17:08:35 --> Language Class Initialized
INFO - 2018-10-21 17:08:35 --> Language Class Initialized
INFO - 2018-10-21 17:08:35 --> Config Class Initialized
INFO - 2018-10-21 17:08:35 --> Loader Class Initialized
INFO - 2018-10-21 17:08:36 --> Helper loaded: url_helper
INFO - 2018-10-21 17:08:36 --> Helper loaded: form_helper
INFO - 2018-10-21 17:08:36 --> Helper loaded: html_helper
INFO - 2018-10-21 17:08:36 --> Controller Class Initialized
ERROR - 2018-10-21 17:08:36 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:09:22 --> Config Class Initialized
INFO - 2018-10-21 17:09:22 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:09:22 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:09:22 --> Utf8 Class Initialized
INFO - 2018-10-21 17:09:22 --> URI Class Initialized
DEBUG - 2018-10-21 17:09:22 --> No URI present. Default controller set.
INFO - 2018-10-21 17:09:22 --> Router Class Initialized
INFO - 2018-10-21 17:09:22 --> Output Class Initialized
INFO - 2018-10-21 17:09:22 --> Security Class Initialized
DEBUG - 2018-10-21 17:09:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:09:22 --> Input Class Initialized
INFO - 2018-10-21 17:09:22 --> Language Class Initialized
INFO - 2018-10-21 17:09:22 --> Language Class Initialized
INFO - 2018-10-21 17:09:22 --> Config Class Initialized
INFO - 2018-10-21 17:09:22 --> Loader Class Initialized
INFO - 2018-10-21 17:09:22 --> Helper loaded: url_helper
INFO - 2018-10-21 17:09:23 --> Helper loaded: form_helper
INFO - 2018-10-21 17:09:23 --> Helper loaded: html_helper
INFO - 2018-10-21 17:09:23 --> Controller Class Initialized
DEBUG - 2018-10-21 17:09:23 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:09:23 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:09:23 --> Final output sent to browser
DEBUG - 2018-10-21 17:09:23 --> Total execution time: 0.3859
INFO - 2018-10-21 17:09:24 --> Config Class Initialized
INFO - 2018-10-21 17:09:24 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:09:24 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:09:24 --> Utf8 Class Initialized
INFO - 2018-10-21 17:09:24 --> URI Class Initialized
DEBUG - 2018-10-21 17:09:24 --> No URI present. Default controller set.
INFO - 2018-10-21 17:09:24 --> Router Class Initialized
INFO - 2018-10-21 17:09:24 --> Output Class Initialized
INFO - 2018-10-21 17:09:24 --> Security Class Initialized
DEBUG - 2018-10-21 17:09:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:09:24 --> Input Class Initialized
INFO - 2018-10-21 17:09:25 --> Language Class Initialized
INFO - 2018-10-21 17:09:25 --> Language Class Initialized
INFO - 2018-10-21 17:09:25 --> Config Class Initialized
INFO - 2018-10-21 17:09:25 --> Loader Class Initialized
INFO - 2018-10-21 17:09:25 --> Helper loaded: url_helper
INFO - 2018-10-21 17:09:25 --> Helper loaded: form_helper
INFO - 2018-10-21 17:09:25 --> Helper loaded: html_helper
INFO - 2018-10-21 17:09:25 --> Controller Class Initialized
DEBUG - 2018-10-21 17:09:25 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:09:25 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:09:25 --> Final output sent to browser
DEBUG - 2018-10-21 17:09:25 --> Total execution time: 0.3889
INFO - 2018-10-21 17:09:25 --> Config Class Initialized
INFO - 2018-10-21 17:09:25 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:09:25 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:09:25 --> Utf8 Class Initialized
INFO - 2018-10-21 17:09:25 --> URI Class Initialized
DEBUG - 2018-10-21 17:09:25 --> No URI present. Default controller set.
INFO - 2018-10-21 17:09:25 --> Router Class Initialized
INFO - 2018-10-21 17:09:25 --> Output Class Initialized
INFO - 2018-10-21 17:09:25 --> Security Class Initialized
DEBUG - 2018-10-21 17:09:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:09:26 --> Input Class Initialized
INFO - 2018-10-21 17:09:26 --> Language Class Initialized
INFO - 2018-10-21 17:09:26 --> Language Class Initialized
INFO - 2018-10-21 17:09:26 --> Config Class Initialized
INFO - 2018-10-21 17:09:26 --> Loader Class Initialized
INFO - 2018-10-21 17:09:26 --> Helper loaded: url_helper
INFO - 2018-10-21 17:09:26 --> Helper loaded: form_helper
INFO - 2018-10-21 17:09:26 --> Helper loaded: html_helper
INFO - 2018-10-21 17:09:26 --> Controller Class Initialized
DEBUG - 2018-10-21 17:09:26 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:09:26 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:09:26 --> Final output sent to browser
DEBUG - 2018-10-21 17:09:26 --> Total execution time: 0.7418
INFO - 2018-10-21 17:09:27 --> Config Class Initialized
INFO - 2018-10-21 17:09:27 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:09:27 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:09:27 --> Utf8 Class Initialized
INFO - 2018-10-21 17:09:27 --> URI Class Initialized
DEBUG - 2018-10-21 17:09:27 --> No URI present. Default controller set.
INFO - 2018-10-21 17:09:28 --> Router Class Initialized
INFO - 2018-10-21 17:09:28 --> Output Class Initialized
INFO - 2018-10-21 17:09:28 --> Security Class Initialized
DEBUG - 2018-10-21 17:09:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:09:28 --> Input Class Initialized
INFO - 2018-10-21 17:09:28 --> Language Class Initialized
INFO - 2018-10-21 17:09:28 --> Language Class Initialized
INFO - 2018-10-21 17:09:28 --> Config Class Initialized
INFO - 2018-10-21 17:09:28 --> Loader Class Initialized
INFO - 2018-10-21 17:09:28 --> Helper loaded: url_helper
INFO - 2018-10-21 17:09:28 --> Helper loaded: form_helper
INFO - 2018-10-21 17:09:28 --> Helper loaded: html_helper
INFO - 2018-10-21 17:09:28 --> Controller Class Initialized
DEBUG - 2018-10-21 17:09:28 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:09:28 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:09:28 --> Final output sent to browser
DEBUG - 2018-10-21 17:09:28 --> Total execution time: 0.5596
INFO - 2018-10-21 17:09:33 --> Config Class Initialized
INFO - 2018-10-21 17:09:33 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:09:33 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:09:33 --> Utf8 Class Initialized
INFO - 2018-10-21 17:09:33 --> URI Class Initialized
INFO - 2018-10-21 17:09:33 --> Router Class Initialized
INFO - 2018-10-21 17:09:33 --> Output Class Initialized
INFO - 2018-10-21 17:09:33 --> Security Class Initialized
DEBUG - 2018-10-21 17:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:09:33 --> Input Class Initialized
INFO - 2018-10-21 17:09:33 --> Language Class Initialized
INFO - 2018-10-21 17:09:33 --> Language Class Initialized
INFO - 2018-10-21 17:09:33 --> Config Class Initialized
INFO - 2018-10-21 17:09:33 --> Loader Class Initialized
INFO - 2018-10-21 17:09:33 --> Helper loaded: url_helper
INFO - 2018-10-21 17:09:33 --> Helper loaded: form_helper
INFO - 2018-10-21 17:09:33 --> Helper loaded: html_helper
INFO - 2018-10-21 17:09:33 --> Controller Class Initialized
ERROR - 2018-10-21 17:09:33 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:10:19 --> Config Class Initialized
INFO - 2018-10-21 17:10:19 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:10:19 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:10:19 --> Utf8 Class Initialized
INFO - 2018-10-21 17:10:19 --> URI Class Initialized
DEBUG - 2018-10-21 17:10:19 --> No URI present. Default controller set.
INFO - 2018-10-21 17:10:19 --> Router Class Initialized
INFO - 2018-10-21 17:10:19 --> Output Class Initialized
INFO - 2018-10-21 17:10:19 --> Security Class Initialized
DEBUG - 2018-10-21 17:10:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:10:19 --> Input Class Initialized
INFO - 2018-10-21 17:10:19 --> Language Class Initialized
INFO - 2018-10-21 17:10:19 --> Language Class Initialized
INFO - 2018-10-21 17:10:19 --> Config Class Initialized
INFO - 2018-10-21 17:10:19 --> Loader Class Initialized
INFO - 2018-10-21 17:10:19 --> Helper loaded: url_helper
INFO - 2018-10-21 17:10:19 --> Helper loaded: form_helper
INFO - 2018-10-21 17:10:19 --> Helper loaded: html_helper
INFO - 2018-10-21 17:10:19 --> Controller Class Initialized
DEBUG - 2018-10-21 17:10:19 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:10:19 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:10:19 --> Final output sent to browser
DEBUG - 2018-10-21 17:10:19 --> Total execution time: 0.3572
INFO - 2018-10-21 17:10:20 --> Config Class Initialized
INFO - 2018-10-21 17:10:20 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:10:20 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:10:20 --> Utf8 Class Initialized
INFO - 2018-10-21 17:10:20 --> URI Class Initialized
DEBUG - 2018-10-21 17:10:20 --> No URI present. Default controller set.
INFO - 2018-10-21 17:10:20 --> Router Class Initialized
INFO - 2018-10-21 17:10:20 --> Output Class Initialized
INFO - 2018-10-21 17:10:20 --> Security Class Initialized
DEBUG - 2018-10-21 17:10:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:10:20 --> Input Class Initialized
INFO - 2018-10-21 17:10:20 --> Language Class Initialized
INFO - 2018-10-21 17:10:20 --> Language Class Initialized
INFO - 2018-10-21 17:10:20 --> Config Class Initialized
INFO - 2018-10-21 17:10:20 --> Loader Class Initialized
INFO - 2018-10-21 17:10:20 --> Helper loaded: url_helper
INFO - 2018-10-21 17:10:20 --> Helper loaded: form_helper
INFO - 2018-10-21 17:10:20 --> Helper loaded: html_helper
INFO - 2018-10-21 17:10:20 --> Controller Class Initialized
DEBUG - 2018-10-21 17:10:20 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:10:20 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:10:20 --> Final output sent to browser
DEBUG - 2018-10-21 17:10:20 --> Total execution time: 0.6694
INFO - 2018-10-21 17:10:21 --> Config Class Initialized
INFO - 2018-10-21 17:10:21 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:10:21 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:10:21 --> Utf8 Class Initialized
INFO - 2018-10-21 17:10:21 --> URI Class Initialized
DEBUG - 2018-10-21 17:10:21 --> No URI present. Default controller set.
INFO - 2018-10-21 17:10:21 --> Router Class Initialized
INFO - 2018-10-21 17:10:21 --> Output Class Initialized
INFO - 2018-10-21 17:10:21 --> Security Class Initialized
DEBUG - 2018-10-21 17:10:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:10:21 --> Input Class Initialized
INFO - 2018-10-21 17:10:21 --> Language Class Initialized
INFO - 2018-10-21 17:10:21 --> Language Class Initialized
INFO - 2018-10-21 17:10:21 --> Config Class Initialized
INFO - 2018-10-21 17:10:21 --> Loader Class Initialized
INFO - 2018-10-21 17:10:21 --> Helper loaded: url_helper
INFO - 2018-10-21 17:10:21 --> Helper loaded: form_helper
INFO - 2018-10-21 17:10:21 --> Helper loaded: html_helper
INFO - 2018-10-21 17:10:21 --> Controller Class Initialized
DEBUG - 2018-10-21 17:10:22 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:10:22 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:10:22 --> Final output sent to browser
DEBUG - 2018-10-21 17:10:22 --> Total execution time: 0.7516
INFO - 2018-10-21 17:10:51 --> Config Class Initialized
INFO - 2018-10-21 17:10:51 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:10:51 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:10:51 --> Utf8 Class Initialized
INFO - 2018-10-21 17:10:51 --> URI Class Initialized
DEBUG - 2018-10-21 17:10:51 --> No URI present. Default controller set.
INFO - 2018-10-21 17:10:51 --> Router Class Initialized
INFO - 2018-10-21 17:10:51 --> Output Class Initialized
INFO - 2018-10-21 17:10:51 --> Security Class Initialized
DEBUG - 2018-10-21 17:10:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:10:51 --> Input Class Initialized
INFO - 2018-10-21 17:10:51 --> Language Class Initialized
INFO - 2018-10-21 17:10:51 --> Language Class Initialized
INFO - 2018-10-21 17:10:51 --> Config Class Initialized
INFO - 2018-10-21 17:10:51 --> Loader Class Initialized
INFO - 2018-10-21 17:10:51 --> Helper loaded: url_helper
INFO - 2018-10-21 17:10:51 --> Helper loaded: form_helper
INFO - 2018-10-21 17:10:51 --> Helper loaded: html_helper
INFO - 2018-10-21 17:10:51 --> Controller Class Initialized
DEBUG - 2018-10-21 17:10:51 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:10:51 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:10:51 --> Final output sent to browser
DEBUG - 2018-10-21 17:10:51 --> Total execution time: 0.3588
INFO - 2018-10-21 17:11:34 --> Config Class Initialized
INFO - 2018-10-21 17:11:34 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:11:34 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:11:34 --> Utf8 Class Initialized
INFO - 2018-10-21 17:11:34 --> URI Class Initialized
DEBUG - 2018-10-21 17:11:34 --> No URI present. Default controller set.
INFO - 2018-10-21 17:11:34 --> Router Class Initialized
INFO - 2018-10-21 17:11:34 --> Output Class Initialized
INFO - 2018-10-21 17:11:34 --> Security Class Initialized
DEBUG - 2018-10-21 17:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:11:34 --> Input Class Initialized
INFO - 2018-10-21 17:11:34 --> Language Class Initialized
INFO - 2018-10-21 17:11:34 --> Language Class Initialized
INFO - 2018-10-21 17:11:34 --> Config Class Initialized
INFO - 2018-10-21 17:11:34 --> Loader Class Initialized
INFO - 2018-10-21 17:11:34 --> Helper loaded: url_helper
INFO - 2018-10-21 17:11:34 --> Helper loaded: form_helper
INFO - 2018-10-21 17:11:34 --> Helper loaded: html_helper
INFO - 2018-10-21 17:11:34 --> Controller Class Initialized
DEBUG - 2018-10-21 17:11:34 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:11:34 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:11:34 --> Final output sent to browser
DEBUG - 2018-10-21 17:11:34 --> Total execution time: 0.3550
INFO - 2018-10-21 17:13:15 --> Config Class Initialized
INFO - 2018-10-21 17:13:15 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:13:15 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:13:15 --> Utf8 Class Initialized
INFO - 2018-10-21 17:13:15 --> URI Class Initialized
DEBUG - 2018-10-21 17:13:15 --> No URI present. Default controller set.
INFO - 2018-10-21 17:13:15 --> Router Class Initialized
INFO - 2018-10-21 17:13:15 --> Output Class Initialized
INFO - 2018-10-21 17:13:15 --> Security Class Initialized
DEBUG - 2018-10-21 17:13:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:13:15 --> Input Class Initialized
INFO - 2018-10-21 17:13:15 --> Language Class Initialized
INFO - 2018-10-21 17:13:15 --> Language Class Initialized
INFO - 2018-10-21 17:13:15 --> Config Class Initialized
INFO - 2018-10-21 17:13:15 --> Loader Class Initialized
INFO - 2018-10-21 17:13:15 --> Helper loaded: url_helper
INFO - 2018-10-21 17:13:15 --> Helper loaded: form_helper
INFO - 2018-10-21 17:13:15 --> Helper loaded: html_helper
INFO - 2018-10-21 17:13:15 --> Controller Class Initialized
DEBUG - 2018-10-21 17:13:15 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:13:15 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:13:15 --> Final output sent to browser
DEBUG - 2018-10-21 17:13:15 --> Total execution time: 0.9160
INFO - 2018-10-21 17:13:29 --> Config Class Initialized
INFO - 2018-10-21 17:13:29 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:13:29 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:13:29 --> Utf8 Class Initialized
INFO - 2018-10-21 17:13:29 --> URI Class Initialized
INFO - 2018-10-21 17:13:29 --> Router Class Initialized
INFO - 2018-10-21 17:13:29 --> Output Class Initialized
INFO - 2018-10-21 17:13:29 --> Security Class Initialized
DEBUG - 2018-10-21 17:13:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:13:29 --> Input Class Initialized
INFO - 2018-10-21 17:13:29 --> Language Class Initialized
INFO - 2018-10-21 17:13:29 --> Language Class Initialized
INFO - 2018-10-21 17:13:29 --> Config Class Initialized
INFO - 2018-10-21 17:13:29 --> Loader Class Initialized
INFO - 2018-10-21 17:13:29 --> Helper loaded: url_helper
INFO - 2018-10-21 17:13:29 --> Helper loaded: form_helper
INFO - 2018-10-21 17:13:29 --> Helper loaded: html_helper
INFO - 2018-10-21 17:13:29 --> Controller Class Initialized
ERROR - 2018-10-21 17:13:29 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:13:34 --> Config Class Initialized
INFO - 2018-10-21 17:13:34 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:13:34 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:13:34 --> Utf8 Class Initialized
INFO - 2018-10-21 17:13:34 --> URI Class Initialized
DEBUG - 2018-10-21 17:13:34 --> No URI present. Default controller set.
INFO - 2018-10-21 17:13:34 --> Router Class Initialized
INFO - 2018-10-21 17:13:34 --> Output Class Initialized
INFO - 2018-10-21 17:13:34 --> Security Class Initialized
DEBUG - 2018-10-21 17:13:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:13:34 --> Input Class Initialized
INFO - 2018-10-21 17:13:34 --> Language Class Initialized
INFO - 2018-10-21 17:13:34 --> Language Class Initialized
INFO - 2018-10-21 17:13:34 --> Config Class Initialized
INFO - 2018-10-21 17:13:34 --> Loader Class Initialized
INFO - 2018-10-21 17:13:34 --> Helper loaded: url_helper
INFO - 2018-10-21 17:13:34 --> Helper loaded: form_helper
INFO - 2018-10-21 17:13:34 --> Helper loaded: html_helper
INFO - 2018-10-21 17:13:34 --> Controller Class Initialized
DEBUG - 2018-10-21 17:13:34 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:13:35 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:13:35 --> Final output sent to browser
DEBUG - 2018-10-21 17:13:35 --> Total execution time: 0.6256
INFO - 2018-10-21 17:17:14 --> Config Class Initialized
INFO - 2018-10-21 17:17:14 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:17:14 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:17:14 --> Utf8 Class Initialized
INFO - 2018-10-21 17:17:14 --> URI Class Initialized
DEBUG - 2018-10-21 17:17:14 --> No URI present. Default controller set.
INFO - 2018-10-21 17:17:14 --> Router Class Initialized
INFO - 2018-10-21 17:17:14 --> Output Class Initialized
INFO - 2018-10-21 17:17:14 --> Security Class Initialized
DEBUG - 2018-10-21 17:17:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:17:14 --> Input Class Initialized
INFO - 2018-10-21 17:17:14 --> Language Class Initialized
INFO - 2018-10-21 17:17:14 --> Language Class Initialized
INFO - 2018-10-21 17:17:14 --> Config Class Initialized
INFO - 2018-10-21 17:17:14 --> Loader Class Initialized
INFO - 2018-10-21 17:17:14 --> Helper loaded: url_helper
INFO - 2018-10-21 17:17:14 --> Helper loaded: form_helper
INFO - 2018-10-21 17:17:14 --> Helper loaded: html_helper
INFO - 2018-10-21 17:17:14 --> Controller Class Initialized
DEBUG - 2018-10-21 17:17:14 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:17:14 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:17:14 --> Final output sent to browser
DEBUG - 2018-10-21 17:17:14 --> Total execution time: 0.7475
INFO - 2018-10-21 17:17:16 --> Config Class Initialized
INFO - 2018-10-21 17:17:16 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:17:16 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:17:16 --> Utf8 Class Initialized
INFO - 2018-10-21 17:17:16 --> URI Class Initialized
DEBUG - 2018-10-21 17:17:16 --> No URI present. Default controller set.
INFO - 2018-10-21 17:17:16 --> Router Class Initialized
INFO - 2018-10-21 17:17:16 --> Output Class Initialized
INFO - 2018-10-21 17:17:16 --> Security Class Initialized
DEBUG - 2018-10-21 17:17:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:17:16 --> Input Class Initialized
INFO - 2018-10-21 17:17:16 --> Language Class Initialized
INFO - 2018-10-21 17:17:16 --> Language Class Initialized
INFO - 2018-10-21 17:17:16 --> Config Class Initialized
INFO - 2018-10-21 17:17:16 --> Loader Class Initialized
INFO - 2018-10-21 17:17:16 --> Helper loaded: url_helper
INFO - 2018-10-21 17:17:16 --> Helper loaded: form_helper
INFO - 2018-10-21 17:17:16 --> Helper loaded: html_helper
INFO - 2018-10-21 17:17:16 --> Controller Class Initialized
DEBUG - 2018-10-21 17:17:16 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:17:16 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:17:16 --> Final output sent to browser
DEBUG - 2018-10-21 17:17:16 --> Total execution time: 0.4562
INFO - 2018-10-21 17:17:26 --> Config Class Initialized
INFO - 2018-10-21 17:17:26 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:17:26 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:17:27 --> Utf8 Class Initialized
INFO - 2018-10-21 17:17:27 --> URI Class Initialized
INFO - 2018-10-21 17:17:27 --> Router Class Initialized
INFO - 2018-10-21 17:17:27 --> Output Class Initialized
INFO - 2018-10-21 17:17:27 --> Security Class Initialized
DEBUG - 2018-10-21 17:17:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:17:27 --> Input Class Initialized
INFO - 2018-10-21 17:17:27 --> Language Class Initialized
INFO - 2018-10-21 17:17:27 --> Language Class Initialized
INFO - 2018-10-21 17:17:27 --> Config Class Initialized
INFO - 2018-10-21 17:17:27 --> Loader Class Initialized
INFO - 2018-10-21 17:17:27 --> Helper loaded: url_helper
INFO - 2018-10-21 17:17:27 --> Helper loaded: form_helper
INFO - 2018-10-21 17:17:27 --> Helper loaded: html_helper
INFO - 2018-10-21 17:17:27 --> Controller Class Initialized
ERROR - 2018-10-21 17:17:27 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:17:51 --> Config Class Initialized
INFO - 2018-10-21 17:17:51 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:17:51 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:17:51 --> Utf8 Class Initialized
INFO - 2018-10-21 17:17:51 --> URI Class Initialized
DEBUG - 2018-10-21 17:17:51 --> No URI present. Default controller set.
INFO - 2018-10-21 17:17:51 --> Router Class Initialized
INFO - 2018-10-21 17:17:51 --> Output Class Initialized
INFO - 2018-10-21 17:17:51 --> Security Class Initialized
DEBUG - 2018-10-21 17:17:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:17:52 --> Input Class Initialized
INFO - 2018-10-21 17:17:52 --> Language Class Initialized
INFO - 2018-10-21 17:17:52 --> Language Class Initialized
INFO - 2018-10-21 17:17:52 --> Config Class Initialized
INFO - 2018-10-21 17:17:52 --> Loader Class Initialized
INFO - 2018-10-21 17:17:52 --> Helper loaded: url_helper
INFO - 2018-10-21 17:17:52 --> Helper loaded: form_helper
INFO - 2018-10-21 17:17:52 --> Helper loaded: html_helper
INFO - 2018-10-21 17:17:52 --> Controller Class Initialized
DEBUG - 2018-10-21 17:17:52 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:17:52 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:17:52 --> Final output sent to browser
DEBUG - 2018-10-21 17:17:52 --> Total execution time: 0.4089
INFO - 2018-10-21 17:18:00 --> Config Class Initialized
INFO - 2018-10-21 17:18:00 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:18:00 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:18:00 --> Utf8 Class Initialized
INFO - 2018-10-21 17:18:00 --> URI Class Initialized
INFO - 2018-10-21 17:18:00 --> Router Class Initialized
INFO - 2018-10-21 17:18:00 --> Output Class Initialized
INFO - 2018-10-21 17:18:00 --> Security Class Initialized
DEBUG - 2018-10-21 17:18:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:18:00 --> Input Class Initialized
INFO - 2018-10-21 17:18:00 --> Language Class Initialized
INFO - 2018-10-21 17:18:00 --> Language Class Initialized
INFO - 2018-10-21 17:18:00 --> Config Class Initialized
INFO - 2018-10-21 17:18:00 --> Loader Class Initialized
INFO - 2018-10-21 17:18:01 --> Helper loaded: url_helper
INFO - 2018-10-21 17:18:01 --> Helper loaded: form_helper
INFO - 2018-10-21 17:18:01 --> Helper loaded: html_helper
INFO - 2018-10-21 17:18:01 --> Controller Class Initialized
ERROR - 2018-10-21 17:18:01 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:18:27 --> Config Class Initialized
INFO - 2018-10-21 17:18:27 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:18:27 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:18:27 --> Utf8 Class Initialized
INFO - 2018-10-21 17:18:27 --> URI Class Initialized
INFO - 2018-10-21 17:18:27 --> Router Class Initialized
INFO - 2018-10-21 17:18:27 --> Output Class Initialized
INFO - 2018-10-21 17:18:27 --> Security Class Initialized
DEBUG - 2018-10-21 17:18:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:18:27 --> Input Class Initialized
INFO - 2018-10-21 17:18:28 --> Language Class Initialized
INFO - 2018-10-21 17:18:28 --> Language Class Initialized
INFO - 2018-10-21 17:18:28 --> Config Class Initialized
INFO - 2018-10-21 17:18:28 --> Loader Class Initialized
INFO - 2018-10-21 17:18:28 --> Helper loaded: url_helper
INFO - 2018-10-21 17:18:28 --> Helper loaded: form_helper
INFO - 2018-10-21 17:18:28 --> Helper loaded: html_helper
INFO - 2018-10-21 17:18:28 --> Controller Class Initialized
ERROR - 2018-10-21 17:18:28 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:18:32 --> Config Class Initialized
INFO - 2018-10-21 17:18:32 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:18:32 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:18:32 --> Utf8 Class Initialized
INFO - 2018-10-21 17:18:32 --> URI Class Initialized
DEBUG - 2018-10-21 17:18:32 --> No URI present. Default controller set.
INFO - 2018-10-21 17:18:32 --> Router Class Initialized
INFO - 2018-10-21 17:18:32 --> Output Class Initialized
INFO - 2018-10-21 17:18:32 --> Security Class Initialized
DEBUG - 2018-10-21 17:18:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:18:32 --> Input Class Initialized
INFO - 2018-10-21 17:18:32 --> Language Class Initialized
INFO - 2018-10-21 17:18:32 --> Language Class Initialized
INFO - 2018-10-21 17:18:32 --> Config Class Initialized
INFO - 2018-10-21 17:18:32 --> Loader Class Initialized
INFO - 2018-10-21 17:18:32 --> Helper loaded: url_helper
INFO - 2018-10-21 17:18:32 --> Helper loaded: form_helper
INFO - 2018-10-21 17:18:32 --> Helper loaded: html_helper
INFO - 2018-10-21 17:18:32 --> Controller Class Initialized
DEBUG - 2018-10-21 17:18:32 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:18:33 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:18:33 --> Final output sent to browser
DEBUG - 2018-10-21 17:18:33 --> Total execution time: 0.4776
INFO - 2018-10-21 17:18:38 --> Config Class Initialized
INFO - 2018-10-21 17:18:38 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:18:38 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:18:38 --> Utf8 Class Initialized
INFO - 2018-10-21 17:18:38 --> URI Class Initialized
INFO - 2018-10-21 17:18:38 --> Router Class Initialized
INFO - 2018-10-21 17:18:38 --> Output Class Initialized
INFO - 2018-10-21 17:18:38 --> Security Class Initialized
DEBUG - 2018-10-21 17:18:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:18:38 --> Input Class Initialized
INFO - 2018-10-21 17:18:38 --> Language Class Initialized
INFO - 2018-10-21 17:18:38 --> Language Class Initialized
INFO - 2018-10-21 17:18:38 --> Config Class Initialized
INFO - 2018-10-21 17:18:38 --> Loader Class Initialized
INFO - 2018-10-21 17:18:38 --> Helper loaded: url_helper
INFO - 2018-10-21 17:18:38 --> Helper loaded: form_helper
INFO - 2018-10-21 17:18:38 --> Helper loaded: html_helper
INFO - 2018-10-21 17:18:38 --> Controller Class Initialized
ERROR - 2018-10-21 17:18:38 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:18:53 --> Config Class Initialized
INFO - 2018-10-21 17:18:53 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:18:53 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:18:53 --> Utf8 Class Initialized
INFO - 2018-10-21 17:18:53 --> URI Class Initialized
DEBUG - 2018-10-21 17:18:53 --> No URI present. Default controller set.
INFO - 2018-10-21 17:18:53 --> Router Class Initialized
INFO - 2018-10-21 17:18:53 --> Output Class Initialized
INFO - 2018-10-21 17:18:54 --> Security Class Initialized
DEBUG - 2018-10-21 17:18:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:18:54 --> Input Class Initialized
INFO - 2018-10-21 17:18:54 --> Language Class Initialized
INFO - 2018-10-21 17:18:54 --> Language Class Initialized
INFO - 2018-10-21 17:18:54 --> Config Class Initialized
INFO - 2018-10-21 17:18:54 --> Loader Class Initialized
INFO - 2018-10-21 17:18:54 --> Helper loaded: url_helper
INFO - 2018-10-21 17:18:54 --> Helper loaded: form_helper
INFO - 2018-10-21 17:18:54 --> Helper loaded: html_helper
INFO - 2018-10-21 17:18:54 --> Controller Class Initialized
DEBUG - 2018-10-21 17:18:54 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:18:54 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:18:54 --> Final output sent to browser
DEBUG - 2018-10-21 17:18:54 --> Total execution time: 0.8140
INFO - 2018-10-21 17:19:07 --> Config Class Initialized
INFO - 2018-10-21 17:19:07 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:19:07 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:19:07 --> Utf8 Class Initialized
INFO - 2018-10-21 17:19:07 --> URI Class Initialized
INFO - 2018-10-21 17:19:07 --> Router Class Initialized
INFO - 2018-10-21 17:19:07 --> Output Class Initialized
INFO - 2018-10-21 17:19:07 --> Security Class Initialized
DEBUG - 2018-10-21 17:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:19:07 --> Input Class Initialized
INFO - 2018-10-21 17:19:07 --> Language Class Initialized
INFO - 2018-10-21 17:19:07 --> Language Class Initialized
INFO - 2018-10-21 17:19:07 --> Config Class Initialized
INFO - 2018-10-21 17:19:07 --> Loader Class Initialized
INFO - 2018-10-21 17:19:07 --> Helper loaded: url_helper
INFO - 2018-10-21 17:19:07 --> Helper loaded: form_helper
INFO - 2018-10-21 17:19:07 --> Helper loaded: html_helper
INFO - 2018-10-21 17:19:07 --> Controller Class Initialized
ERROR - 2018-10-21 17:19:07 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:20:21 --> Config Class Initialized
INFO - 2018-10-21 17:20:21 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:20:21 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:20:21 --> Utf8 Class Initialized
INFO - 2018-10-21 17:20:21 --> URI Class Initialized
INFO - 2018-10-21 17:20:21 --> Router Class Initialized
INFO - 2018-10-21 17:20:21 --> Output Class Initialized
INFO - 2018-10-21 17:20:21 --> Security Class Initialized
DEBUG - 2018-10-21 17:20:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:20:21 --> Input Class Initialized
INFO - 2018-10-21 17:20:22 --> Language Class Initialized
INFO - 2018-10-21 17:20:22 --> Language Class Initialized
INFO - 2018-10-21 17:20:22 --> Config Class Initialized
INFO - 2018-10-21 17:20:22 --> Loader Class Initialized
INFO - 2018-10-21 17:20:22 --> Helper loaded: url_helper
INFO - 2018-10-21 17:20:22 --> Helper loaded: form_helper
INFO - 2018-10-21 17:20:22 --> Helper loaded: html_helper
INFO - 2018-10-21 17:20:22 --> Controller Class Initialized
DEBUG - 2018-10-21 17:20:22 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:20:22 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 17:20:22 --> Final output sent to browser
DEBUG - 2018-10-21 17:20:22 --> Total execution time: 0.4829
INFO - 2018-10-21 17:21:40 --> Config Class Initialized
INFO - 2018-10-21 17:21:40 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:21:40 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:21:40 --> Utf8 Class Initialized
INFO - 2018-10-21 17:21:40 --> URI Class Initialized
INFO - 2018-10-21 17:21:40 --> Router Class Initialized
INFO - 2018-10-21 17:21:40 --> Output Class Initialized
INFO - 2018-10-21 17:21:40 --> Security Class Initialized
DEBUG - 2018-10-21 17:21:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:21:40 --> Input Class Initialized
INFO - 2018-10-21 17:21:40 --> Language Class Initialized
INFO - 2018-10-21 17:21:40 --> Language Class Initialized
INFO - 2018-10-21 17:21:40 --> Config Class Initialized
INFO - 2018-10-21 17:21:41 --> Loader Class Initialized
INFO - 2018-10-21 17:21:41 --> Helper loaded: url_helper
INFO - 2018-10-21 17:21:41 --> Helper loaded: form_helper
INFO - 2018-10-21 17:21:41 --> Helper loaded: html_helper
INFO - 2018-10-21 17:21:41 --> Controller Class Initialized
DEBUG - 2018-10-21 17:21:41 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:21:41 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 17:21:41 --> Final output sent to browser
DEBUG - 2018-10-21 17:21:41 --> Total execution time: 0.3264
INFO - 2018-10-21 17:24:11 --> Config Class Initialized
INFO - 2018-10-21 17:24:11 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:24:11 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:24:11 --> Utf8 Class Initialized
INFO - 2018-10-21 17:24:11 --> URI Class Initialized
INFO - 2018-10-21 17:24:11 --> Router Class Initialized
INFO - 2018-10-21 17:24:11 --> Output Class Initialized
INFO - 2018-10-21 17:24:11 --> Security Class Initialized
DEBUG - 2018-10-21 17:24:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:24:11 --> Input Class Initialized
INFO - 2018-10-21 17:24:11 --> Language Class Initialized
INFO - 2018-10-21 17:24:11 --> Language Class Initialized
INFO - 2018-10-21 17:24:11 --> Config Class Initialized
INFO - 2018-10-21 17:24:11 --> Loader Class Initialized
INFO - 2018-10-21 17:24:11 --> Helper loaded: url_helper
INFO - 2018-10-21 17:24:11 --> Helper loaded: form_helper
INFO - 2018-10-21 17:24:11 --> Helper loaded: html_helper
INFO - 2018-10-21 17:24:11 --> Controller Class Initialized
DEBUG - 2018-10-21 17:24:11 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:24:11 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 17:24:11 --> Final output sent to browser
DEBUG - 2018-10-21 17:24:11 --> Total execution time: 0.3590
INFO - 2018-10-21 17:25:37 --> Config Class Initialized
INFO - 2018-10-21 17:25:37 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:25:37 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:25:37 --> Utf8 Class Initialized
INFO - 2018-10-21 17:25:37 --> URI Class Initialized
INFO - 2018-10-21 17:25:37 --> Router Class Initialized
INFO - 2018-10-21 17:25:37 --> Output Class Initialized
INFO - 2018-10-21 17:25:37 --> Security Class Initialized
DEBUG - 2018-10-21 17:25:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:25:37 --> Input Class Initialized
INFO - 2018-10-21 17:25:37 --> Language Class Initialized
INFO - 2018-10-21 17:25:37 --> Language Class Initialized
INFO - 2018-10-21 17:25:37 --> Config Class Initialized
INFO - 2018-10-21 17:25:37 --> Loader Class Initialized
INFO - 2018-10-21 17:25:37 --> Helper loaded: url_helper
INFO - 2018-10-21 17:25:37 --> Helper loaded: form_helper
INFO - 2018-10-21 17:25:37 --> Helper loaded: html_helper
INFO - 2018-10-21 17:25:37 --> Controller Class Initialized
DEBUG - 2018-10-21 17:25:37 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:25:37 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 17:25:37 --> Final output sent to browser
DEBUG - 2018-10-21 17:25:37 --> Total execution time: 0.3579
INFO - 2018-10-21 17:25:41 --> Config Class Initialized
INFO - 2018-10-21 17:25:41 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:25:41 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:25:41 --> Utf8 Class Initialized
INFO - 2018-10-21 17:25:41 --> URI Class Initialized
INFO - 2018-10-21 17:25:41 --> Router Class Initialized
INFO - 2018-10-21 17:25:41 --> Output Class Initialized
INFO - 2018-10-21 17:25:41 --> Security Class Initialized
DEBUG - 2018-10-21 17:25:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:25:41 --> Input Class Initialized
INFO - 2018-10-21 17:25:41 --> Language Class Initialized
INFO - 2018-10-21 17:25:41 --> Language Class Initialized
INFO - 2018-10-21 17:25:41 --> Config Class Initialized
INFO - 2018-10-21 17:25:41 --> Loader Class Initialized
INFO - 2018-10-21 17:25:41 --> Helper loaded: url_helper
INFO - 2018-10-21 17:25:41 --> Helper loaded: form_helper
INFO - 2018-10-21 17:25:41 --> Helper loaded: html_helper
INFO - 2018-10-21 17:25:41 --> Controller Class Initialized
ERROR - 2018-10-21 17:25:41 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:26:33 --> Config Class Initialized
INFO - 2018-10-21 17:26:33 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:26:33 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:26:33 --> Utf8 Class Initialized
INFO - 2018-10-21 17:26:33 --> URI Class Initialized
INFO - 2018-10-21 17:26:33 --> Router Class Initialized
INFO - 2018-10-21 17:26:33 --> Output Class Initialized
INFO - 2018-10-21 17:26:33 --> Security Class Initialized
DEBUG - 2018-10-21 17:26:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:26:33 --> Input Class Initialized
INFO - 2018-10-21 17:26:33 --> Language Class Initialized
INFO - 2018-10-21 17:26:33 --> Language Class Initialized
INFO - 2018-10-21 17:26:33 --> Config Class Initialized
INFO - 2018-10-21 17:26:33 --> Loader Class Initialized
INFO - 2018-10-21 17:26:33 --> Helper loaded: url_helper
INFO - 2018-10-21 17:26:33 --> Helper loaded: form_helper
INFO - 2018-10-21 17:26:34 --> Helper loaded: html_helper
INFO - 2018-10-21 17:26:34 --> Controller Class Initialized
DEBUG - 2018-10-21 17:26:34 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:26:34 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 17:26:34 --> Final output sent to browser
DEBUG - 2018-10-21 17:26:34 --> Total execution time: 0.7273
INFO - 2018-10-21 17:26:38 --> Config Class Initialized
INFO - 2018-10-21 17:26:38 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:26:38 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:26:39 --> Utf8 Class Initialized
INFO - 2018-10-21 17:26:39 --> URI Class Initialized
INFO - 2018-10-21 17:26:39 --> Router Class Initialized
INFO - 2018-10-21 17:26:39 --> Output Class Initialized
INFO - 2018-10-21 17:26:39 --> Security Class Initialized
DEBUG - 2018-10-21 17:26:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:26:39 --> Input Class Initialized
INFO - 2018-10-21 17:26:39 --> Language Class Initialized
INFO - 2018-10-21 17:26:39 --> Language Class Initialized
INFO - 2018-10-21 17:26:39 --> Config Class Initialized
INFO - 2018-10-21 17:26:39 --> Loader Class Initialized
INFO - 2018-10-21 17:26:39 --> Helper loaded: url_helper
INFO - 2018-10-21 17:26:39 --> Helper loaded: form_helper
INFO - 2018-10-21 17:26:39 --> Helper loaded: html_helper
INFO - 2018-10-21 17:26:39 --> Controller Class Initialized
ERROR - 2018-10-21 17:26:39 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:27:36 --> Config Class Initialized
INFO - 2018-10-21 17:27:36 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:27:36 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:27:37 --> Utf8 Class Initialized
INFO - 2018-10-21 17:27:37 --> URI Class Initialized
INFO - 2018-10-21 17:27:37 --> Router Class Initialized
INFO - 2018-10-21 17:27:37 --> Output Class Initialized
INFO - 2018-10-21 17:27:37 --> Security Class Initialized
DEBUG - 2018-10-21 17:27:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:27:37 --> Input Class Initialized
INFO - 2018-10-21 17:27:37 --> Language Class Initialized
INFO - 2018-10-21 17:27:37 --> Language Class Initialized
INFO - 2018-10-21 17:27:37 --> Config Class Initialized
INFO - 2018-10-21 17:27:37 --> Loader Class Initialized
INFO - 2018-10-21 17:27:37 --> Helper loaded: url_helper
INFO - 2018-10-21 17:27:37 --> Helper loaded: form_helper
INFO - 2018-10-21 17:27:37 --> Helper loaded: html_helper
INFO - 2018-10-21 17:27:37 --> Controller Class Initialized
DEBUG - 2018-10-21 17:27:37 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:27:37 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 17:27:37 --> Final output sent to browser
DEBUG - 2018-10-21 17:27:37 --> Total execution time: 0.4249
INFO - 2018-10-21 17:27:38 --> Config Class Initialized
INFO - 2018-10-21 17:27:38 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:27:38 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:27:38 --> Utf8 Class Initialized
INFO - 2018-10-21 17:27:38 --> URI Class Initialized
INFO - 2018-10-21 17:27:38 --> Router Class Initialized
INFO - 2018-10-21 17:27:38 --> Output Class Initialized
INFO - 2018-10-21 17:27:38 --> Security Class Initialized
DEBUG - 2018-10-21 17:27:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:27:38 --> Input Class Initialized
INFO - 2018-10-21 17:27:38 --> Language Class Initialized
INFO - 2018-10-21 17:27:38 --> Language Class Initialized
INFO - 2018-10-21 17:27:38 --> Config Class Initialized
INFO - 2018-10-21 17:27:39 --> Loader Class Initialized
INFO - 2018-10-21 17:27:39 --> Helper loaded: url_helper
INFO - 2018-10-21 17:27:39 --> Helper loaded: form_helper
INFO - 2018-10-21 17:27:39 --> Helper loaded: html_helper
INFO - 2018-10-21 17:27:39 --> Controller Class Initialized
ERROR - 2018-10-21 17:27:39 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:27:41 --> Config Class Initialized
INFO - 2018-10-21 17:27:41 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:27:41 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:27:41 --> Utf8 Class Initialized
INFO - 2018-10-21 17:27:41 --> URI Class Initialized
INFO - 2018-10-21 17:27:41 --> Router Class Initialized
INFO - 2018-10-21 17:27:41 --> Output Class Initialized
INFO - 2018-10-21 17:27:41 --> Security Class Initialized
DEBUG - 2018-10-21 17:27:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:27:41 --> Input Class Initialized
INFO - 2018-10-21 17:27:41 --> Language Class Initialized
INFO - 2018-10-21 17:27:41 --> Language Class Initialized
INFO - 2018-10-21 17:27:41 --> Config Class Initialized
INFO - 2018-10-21 17:27:41 --> Loader Class Initialized
INFO - 2018-10-21 17:27:41 --> Helper loaded: url_helper
INFO - 2018-10-21 17:27:41 --> Helper loaded: form_helper
INFO - 2018-10-21 17:27:41 --> Helper loaded: html_helper
INFO - 2018-10-21 17:27:41 --> Controller Class Initialized
DEBUG - 2018-10-21 17:27:41 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:27:41 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 17:27:41 --> Final output sent to browser
DEBUG - 2018-10-21 17:27:41 --> Total execution time: 0.4285
INFO - 2018-10-21 17:27:43 --> Config Class Initialized
INFO - 2018-10-21 17:27:43 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:27:43 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:27:43 --> Utf8 Class Initialized
INFO - 2018-10-21 17:27:43 --> URI Class Initialized
INFO - 2018-10-21 17:27:43 --> Router Class Initialized
INFO - 2018-10-21 17:27:43 --> Output Class Initialized
INFO - 2018-10-21 17:27:43 --> Security Class Initialized
DEBUG - 2018-10-21 17:27:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:27:43 --> Input Class Initialized
INFO - 2018-10-21 17:27:43 --> Language Class Initialized
INFO - 2018-10-21 17:27:43 --> Language Class Initialized
INFO - 2018-10-21 17:27:43 --> Config Class Initialized
INFO - 2018-10-21 17:27:43 --> Loader Class Initialized
INFO - 2018-10-21 17:27:43 --> Helper loaded: url_helper
INFO - 2018-10-21 17:27:43 --> Helper loaded: form_helper
INFO - 2018-10-21 17:27:43 --> Helper loaded: html_helper
INFO - 2018-10-21 17:27:43 --> Controller Class Initialized
ERROR - 2018-10-21 17:27:43 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:28:32 --> Config Class Initialized
INFO - 2018-10-21 17:28:32 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:28:32 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:28:32 --> Utf8 Class Initialized
INFO - 2018-10-21 17:28:32 --> URI Class Initialized
DEBUG - 2018-10-21 17:28:32 --> No URI present. Default controller set.
INFO - 2018-10-21 17:28:32 --> Router Class Initialized
INFO - 2018-10-21 17:28:32 --> Output Class Initialized
INFO - 2018-10-21 17:28:32 --> Security Class Initialized
DEBUG - 2018-10-21 17:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:28:33 --> Input Class Initialized
INFO - 2018-10-21 17:28:33 --> Language Class Initialized
INFO - 2018-10-21 17:28:33 --> Language Class Initialized
INFO - 2018-10-21 17:28:33 --> Config Class Initialized
INFO - 2018-10-21 17:28:33 --> Loader Class Initialized
INFO - 2018-10-21 17:28:33 --> Helper loaded: url_helper
INFO - 2018-10-21 17:28:33 --> Helper loaded: form_helper
INFO - 2018-10-21 17:28:33 --> Helper loaded: html_helper
INFO - 2018-10-21 17:28:33 --> Controller Class Initialized
DEBUG - 2018-10-21 17:28:33 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:28:33 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:28:33 --> Final output sent to browser
DEBUG - 2018-10-21 17:28:33 --> Total execution time: 0.5259
INFO - 2018-10-21 17:28:34 --> Config Class Initialized
INFO - 2018-10-21 17:28:34 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:28:34 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:28:34 --> Utf8 Class Initialized
INFO - 2018-10-21 17:28:34 --> URI Class Initialized
DEBUG - 2018-10-21 17:28:34 --> No URI present. Default controller set.
INFO - 2018-10-21 17:28:34 --> Router Class Initialized
INFO - 2018-10-21 17:28:34 --> Output Class Initialized
INFO - 2018-10-21 17:28:34 --> Security Class Initialized
DEBUG - 2018-10-21 17:28:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:28:34 --> Input Class Initialized
INFO - 2018-10-21 17:28:34 --> Language Class Initialized
INFO - 2018-10-21 17:28:34 --> Language Class Initialized
INFO - 2018-10-21 17:28:34 --> Config Class Initialized
INFO - 2018-10-21 17:28:34 --> Loader Class Initialized
INFO - 2018-10-21 17:28:34 --> Helper loaded: url_helper
INFO - 2018-10-21 17:28:34 --> Helper loaded: form_helper
INFO - 2018-10-21 17:28:35 --> Helper loaded: html_helper
INFO - 2018-10-21 17:28:35 --> Controller Class Initialized
DEBUG - 2018-10-21 17:28:35 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:28:35 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:28:35 --> Final output sent to browser
DEBUG - 2018-10-21 17:28:35 --> Total execution time: 0.8860
INFO - 2018-10-21 17:28:36 --> Config Class Initialized
INFO - 2018-10-21 17:28:36 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:28:36 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:28:36 --> Utf8 Class Initialized
INFO - 2018-10-21 17:28:36 --> URI Class Initialized
INFO - 2018-10-21 17:28:36 --> Router Class Initialized
INFO - 2018-10-21 17:28:36 --> Output Class Initialized
INFO - 2018-10-21 17:28:36 --> Security Class Initialized
DEBUG - 2018-10-21 17:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:28:36 --> Input Class Initialized
INFO - 2018-10-21 17:28:36 --> Language Class Initialized
INFO - 2018-10-21 17:28:36 --> Language Class Initialized
INFO - 2018-10-21 17:28:36 --> Config Class Initialized
INFO - 2018-10-21 17:28:36 --> Loader Class Initialized
INFO - 2018-10-21 17:28:36 --> Helper loaded: url_helper
INFO - 2018-10-21 17:28:36 --> Helper loaded: form_helper
INFO - 2018-10-21 17:28:36 --> Helper loaded: html_helper
INFO - 2018-10-21 17:28:36 --> Controller Class Initialized
ERROR - 2018-10-21 17:28:36 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:28:49 --> Config Class Initialized
INFO - 2018-10-21 17:28:49 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:28:49 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:28:49 --> Utf8 Class Initialized
INFO - 2018-10-21 17:28:49 --> URI Class Initialized
DEBUG - 2018-10-21 17:28:49 --> No URI present. Default controller set.
INFO - 2018-10-21 17:28:49 --> Router Class Initialized
INFO - 2018-10-21 17:28:49 --> Output Class Initialized
INFO - 2018-10-21 17:28:49 --> Security Class Initialized
DEBUG - 2018-10-21 17:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:28:49 --> Input Class Initialized
INFO - 2018-10-21 17:28:50 --> Language Class Initialized
INFO - 2018-10-21 17:28:50 --> Language Class Initialized
INFO - 2018-10-21 17:28:50 --> Config Class Initialized
INFO - 2018-10-21 17:28:50 --> Loader Class Initialized
INFO - 2018-10-21 17:28:50 --> Helper loaded: url_helper
INFO - 2018-10-21 17:28:50 --> Helper loaded: form_helper
INFO - 2018-10-21 17:28:50 --> Helper loaded: html_helper
INFO - 2018-10-21 17:28:50 --> Controller Class Initialized
DEBUG - 2018-10-21 17:28:50 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:28:50 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:28:50 --> Final output sent to browser
DEBUG - 2018-10-21 17:28:50 --> Total execution time: 0.7491
INFO - 2018-10-21 17:28:51 --> Config Class Initialized
INFO - 2018-10-21 17:28:51 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:28:51 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:28:51 --> Utf8 Class Initialized
INFO - 2018-10-21 17:28:51 --> URI Class Initialized
DEBUG - 2018-10-21 17:28:51 --> No URI present. Default controller set.
INFO - 2018-10-21 17:28:51 --> Router Class Initialized
INFO - 2018-10-21 17:28:51 --> Output Class Initialized
INFO - 2018-10-21 17:28:51 --> Security Class Initialized
DEBUG - 2018-10-21 17:28:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:28:52 --> Input Class Initialized
INFO - 2018-10-21 17:28:52 --> Language Class Initialized
INFO - 2018-10-21 17:28:52 --> Language Class Initialized
INFO - 2018-10-21 17:28:52 --> Config Class Initialized
INFO - 2018-10-21 17:28:52 --> Loader Class Initialized
INFO - 2018-10-21 17:28:52 --> Helper loaded: url_helper
INFO - 2018-10-21 17:28:52 --> Helper loaded: form_helper
INFO - 2018-10-21 17:28:52 --> Helper loaded: html_helper
INFO - 2018-10-21 17:28:52 --> Controller Class Initialized
DEBUG - 2018-10-21 17:28:52 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:28:52 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:28:52 --> Final output sent to browser
DEBUG - 2018-10-21 17:28:52 --> Total execution time: 0.3897
INFO - 2018-10-21 17:32:57 --> Config Class Initialized
INFO - 2018-10-21 17:32:58 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:32:58 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:32:58 --> Utf8 Class Initialized
INFO - 2018-10-21 17:32:58 --> URI Class Initialized
DEBUG - 2018-10-21 17:32:58 --> No URI present. Default controller set.
INFO - 2018-10-21 17:32:58 --> Router Class Initialized
INFO - 2018-10-21 17:32:58 --> Output Class Initialized
INFO - 2018-10-21 17:32:58 --> Security Class Initialized
DEBUG - 2018-10-21 17:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:32:58 --> Input Class Initialized
INFO - 2018-10-21 17:32:58 --> Language Class Initialized
INFO - 2018-10-21 17:32:58 --> Language Class Initialized
INFO - 2018-10-21 17:32:58 --> Config Class Initialized
INFO - 2018-10-21 17:32:58 --> Loader Class Initialized
INFO - 2018-10-21 17:32:58 --> Helper loaded: url_helper
INFO - 2018-10-21 17:32:58 --> Helper loaded: form_helper
INFO - 2018-10-21 17:32:58 --> Helper loaded: html_helper
INFO - 2018-10-21 17:32:58 --> Controller Class Initialized
DEBUG - 2018-10-21 17:32:58 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:32:58 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:32:58 --> Final output sent to browser
DEBUG - 2018-10-21 17:32:58 --> Total execution time: 0.7469
INFO - 2018-10-21 17:33:25 --> Config Class Initialized
INFO - 2018-10-21 17:33:26 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:33:26 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:33:26 --> Utf8 Class Initialized
INFO - 2018-10-21 17:33:26 --> URI Class Initialized
DEBUG - 2018-10-21 17:33:26 --> No URI present. Default controller set.
INFO - 2018-10-21 17:33:26 --> Router Class Initialized
INFO - 2018-10-21 17:33:26 --> Output Class Initialized
INFO - 2018-10-21 17:33:26 --> Security Class Initialized
DEBUG - 2018-10-21 17:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:33:26 --> Input Class Initialized
INFO - 2018-10-21 17:33:26 --> Language Class Initialized
INFO - 2018-10-21 17:33:26 --> Language Class Initialized
INFO - 2018-10-21 17:33:26 --> Config Class Initialized
INFO - 2018-10-21 17:33:26 --> Loader Class Initialized
INFO - 2018-10-21 17:33:26 --> Helper loaded: url_helper
INFO - 2018-10-21 17:33:26 --> Helper loaded: form_helper
INFO - 2018-10-21 17:33:26 --> Helper loaded: html_helper
INFO - 2018-10-21 17:33:26 --> Controller Class Initialized
DEBUG - 2018-10-21 17:33:26 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:33:26 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:33:26 --> Final output sent to browser
DEBUG - 2018-10-21 17:33:26 --> Total execution time: 0.3510
INFO - 2018-10-21 17:33:35 --> Config Class Initialized
INFO - 2018-10-21 17:33:35 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:33:35 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:33:35 --> Utf8 Class Initialized
INFO - 2018-10-21 17:33:35 --> URI Class Initialized
INFO - 2018-10-21 17:33:35 --> Router Class Initialized
INFO - 2018-10-21 17:33:35 --> Output Class Initialized
INFO - 2018-10-21 17:33:35 --> Security Class Initialized
DEBUG - 2018-10-21 17:33:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:33:35 --> Input Class Initialized
INFO - 2018-10-21 17:33:35 --> Language Class Initialized
INFO - 2018-10-21 17:33:35 --> Language Class Initialized
INFO - 2018-10-21 17:33:35 --> Config Class Initialized
INFO - 2018-10-21 17:33:35 --> Loader Class Initialized
INFO - 2018-10-21 17:33:35 --> Helper loaded: url_helper
INFO - 2018-10-21 17:33:35 --> Helper loaded: form_helper
INFO - 2018-10-21 17:33:35 --> Helper loaded: html_helper
INFO - 2018-10-21 17:33:35 --> Controller Class Initialized
ERROR - 2018-10-21 17:33:35 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:35:13 --> Config Class Initialized
INFO - 2018-10-21 17:35:13 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:35:13 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:35:13 --> Utf8 Class Initialized
INFO - 2018-10-21 17:35:13 --> URI Class Initialized
DEBUG - 2018-10-21 17:35:13 --> No URI present. Default controller set.
INFO - 2018-10-21 17:35:13 --> Router Class Initialized
INFO - 2018-10-21 17:35:14 --> Output Class Initialized
INFO - 2018-10-21 17:35:14 --> Security Class Initialized
DEBUG - 2018-10-21 17:35:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:35:14 --> Input Class Initialized
INFO - 2018-10-21 17:35:14 --> Language Class Initialized
INFO - 2018-10-21 17:35:14 --> Language Class Initialized
INFO - 2018-10-21 17:35:14 --> Config Class Initialized
INFO - 2018-10-21 17:35:14 --> Loader Class Initialized
INFO - 2018-10-21 17:35:14 --> Helper loaded: url_helper
INFO - 2018-10-21 17:35:14 --> Helper loaded: form_helper
INFO - 2018-10-21 17:35:14 --> Helper loaded: html_helper
INFO - 2018-10-21 17:35:14 --> Controller Class Initialized
DEBUG - 2018-10-21 17:35:14 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:35:14 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:35:14 --> Final output sent to browser
DEBUG - 2018-10-21 17:35:14 --> Total execution time: 0.7631
INFO - 2018-10-21 17:35:45 --> Config Class Initialized
INFO - 2018-10-21 17:35:45 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:35:45 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:35:45 --> Utf8 Class Initialized
INFO - 2018-10-21 17:35:45 --> URI Class Initialized
DEBUG - 2018-10-21 17:35:45 --> No URI present. Default controller set.
INFO - 2018-10-21 17:35:45 --> Router Class Initialized
INFO - 2018-10-21 17:35:45 --> Output Class Initialized
INFO - 2018-10-21 17:35:45 --> Security Class Initialized
DEBUG - 2018-10-21 17:35:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:35:45 --> Input Class Initialized
INFO - 2018-10-21 17:35:45 --> Language Class Initialized
INFO - 2018-10-21 17:35:45 --> Language Class Initialized
INFO - 2018-10-21 17:35:46 --> Config Class Initialized
INFO - 2018-10-21 17:35:46 --> Loader Class Initialized
INFO - 2018-10-21 17:35:46 --> Helper loaded: url_helper
INFO - 2018-10-21 17:35:46 --> Helper loaded: form_helper
INFO - 2018-10-21 17:35:46 --> Helper loaded: html_helper
INFO - 2018-10-21 17:35:46 --> Controller Class Initialized
DEBUG - 2018-10-21 17:35:46 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:35:46 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:35:46 --> Final output sent to browser
DEBUG - 2018-10-21 17:35:46 --> Total execution time: 0.3825
INFO - 2018-10-21 17:36:39 --> Config Class Initialized
INFO - 2018-10-21 17:36:39 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:36:39 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:36:39 --> Utf8 Class Initialized
INFO - 2018-10-21 17:36:39 --> URI Class Initialized
DEBUG - 2018-10-21 17:36:39 --> No URI present. Default controller set.
INFO - 2018-10-21 17:36:39 --> Router Class Initialized
INFO - 2018-10-21 17:36:39 --> Output Class Initialized
INFO - 2018-10-21 17:36:39 --> Security Class Initialized
DEBUG - 2018-10-21 17:36:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:36:39 --> Input Class Initialized
INFO - 2018-10-21 17:36:39 --> Language Class Initialized
INFO - 2018-10-21 17:36:39 --> Language Class Initialized
INFO - 2018-10-21 17:36:39 --> Config Class Initialized
INFO - 2018-10-21 17:36:39 --> Loader Class Initialized
INFO - 2018-10-21 17:36:39 --> Helper loaded: url_helper
INFO - 2018-10-21 17:36:39 --> Helper loaded: form_helper
INFO - 2018-10-21 17:36:39 --> Helper loaded: html_helper
INFO - 2018-10-21 17:36:39 --> Controller Class Initialized
DEBUG - 2018-10-21 17:36:40 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:36:40 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:36:40 --> Final output sent to browser
DEBUG - 2018-10-21 17:36:40 --> Total execution time: 0.3717
INFO - 2018-10-21 17:37:05 --> Config Class Initialized
INFO - 2018-10-21 17:37:05 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:37:05 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:37:05 --> Utf8 Class Initialized
INFO - 2018-10-21 17:37:05 --> URI Class Initialized
DEBUG - 2018-10-21 17:37:05 --> No URI present. Default controller set.
INFO - 2018-10-21 17:37:05 --> Router Class Initialized
INFO - 2018-10-21 17:37:05 --> Output Class Initialized
INFO - 2018-10-21 17:37:05 --> Security Class Initialized
DEBUG - 2018-10-21 17:37:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:37:05 --> Input Class Initialized
INFO - 2018-10-21 17:37:05 --> Language Class Initialized
INFO - 2018-10-21 17:37:05 --> Language Class Initialized
INFO - 2018-10-21 17:37:05 --> Config Class Initialized
INFO - 2018-10-21 17:37:05 --> Loader Class Initialized
INFO - 2018-10-21 17:37:05 --> Helper loaded: url_helper
INFO - 2018-10-21 17:37:05 --> Helper loaded: form_helper
INFO - 2018-10-21 17:37:06 --> Helper loaded: html_helper
INFO - 2018-10-21 17:37:06 --> Controller Class Initialized
DEBUG - 2018-10-21 17:37:06 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:37:06 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:37:06 --> Final output sent to browser
DEBUG - 2018-10-21 17:37:06 --> Total execution time: 0.4239
INFO - 2018-10-21 17:37:52 --> Config Class Initialized
INFO - 2018-10-21 17:37:52 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:37:52 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:37:52 --> Utf8 Class Initialized
INFO - 2018-10-21 17:37:52 --> URI Class Initialized
DEBUG - 2018-10-21 17:37:52 --> No URI present. Default controller set.
INFO - 2018-10-21 17:37:52 --> Router Class Initialized
INFO - 2018-10-21 17:37:52 --> Output Class Initialized
INFO - 2018-10-21 17:37:52 --> Security Class Initialized
DEBUG - 2018-10-21 17:37:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:37:52 --> Input Class Initialized
INFO - 2018-10-21 17:37:52 --> Language Class Initialized
INFO - 2018-10-21 17:37:52 --> Language Class Initialized
INFO - 2018-10-21 17:37:52 --> Config Class Initialized
INFO - 2018-10-21 17:37:52 --> Loader Class Initialized
INFO - 2018-10-21 17:37:52 --> Helper loaded: url_helper
INFO - 2018-10-21 17:37:52 --> Helper loaded: form_helper
INFO - 2018-10-21 17:37:52 --> Helper loaded: html_helper
INFO - 2018-10-21 17:37:52 --> Controller Class Initialized
DEBUG - 2018-10-21 17:37:52 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:37:52 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:37:52 --> Final output sent to browser
DEBUG - 2018-10-21 17:37:52 --> Total execution time: 0.4294
INFO - 2018-10-21 17:38:36 --> Config Class Initialized
INFO - 2018-10-21 17:38:36 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:38:36 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:38:36 --> Utf8 Class Initialized
INFO - 2018-10-21 17:38:36 --> URI Class Initialized
DEBUG - 2018-10-21 17:38:36 --> No URI present. Default controller set.
INFO - 2018-10-21 17:38:36 --> Router Class Initialized
INFO - 2018-10-21 17:38:36 --> Output Class Initialized
INFO - 2018-10-21 17:38:36 --> Security Class Initialized
DEBUG - 2018-10-21 17:38:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:38:36 --> Input Class Initialized
INFO - 2018-10-21 17:38:36 --> Language Class Initialized
INFO - 2018-10-21 17:38:36 --> Language Class Initialized
INFO - 2018-10-21 17:38:36 --> Config Class Initialized
INFO - 2018-10-21 17:38:36 --> Loader Class Initialized
INFO - 2018-10-21 17:38:36 --> Helper loaded: url_helper
INFO - 2018-10-21 17:38:36 --> Helper loaded: form_helper
INFO - 2018-10-21 17:38:36 --> Helper loaded: html_helper
INFO - 2018-10-21 17:38:36 --> Controller Class Initialized
DEBUG - 2018-10-21 17:38:36 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:38:36 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:38:36 --> Final output sent to browser
DEBUG - 2018-10-21 17:38:36 --> Total execution time: 0.3968
INFO - 2018-10-21 17:39:07 --> Config Class Initialized
INFO - 2018-10-21 17:39:07 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:39:07 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:39:07 --> Utf8 Class Initialized
INFO - 2018-10-21 17:39:07 --> URI Class Initialized
DEBUG - 2018-10-21 17:39:07 --> No URI present. Default controller set.
INFO - 2018-10-21 17:39:07 --> Router Class Initialized
INFO - 2018-10-21 17:39:07 --> Output Class Initialized
INFO - 2018-10-21 17:39:07 --> Security Class Initialized
DEBUG - 2018-10-21 17:39:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:39:07 --> Input Class Initialized
INFO - 2018-10-21 17:39:07 --> Language Class Initialized
INFO - 2018-10-21 17:39:07 --> Language Class Initialized
INFO - 2018-10-21 17:39:07 --> Config Class Initialized
INFO - 2018-10-21 17:39:07 --> Loader Class Initialized
INFO - 2018-10-21 17:39:07 --> Helper loaded: url_helper
INFO - 2018-10-21 17:39:07 --> Helper loaded: form_helper
INFO - 2018-10-21 17:39:07 --> Helper loaded: html_helper
INFO - 2018-10-21 17:39:07 --> Controller Class Initialized
DEBUG - 2018-10-21 17:39:07 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:39:07 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:39:07 --> Final output sent to browser
DEBUG - 2018-10-21 17:39:07 --> Total execution time: 0.3726
INFO - 2018-10-21 17:41:58 --> Config Class Initialized
INFO - 2018-10-21 17:41:58 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:41:58 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:41:58 --> Utf8 Class Initialized
INFO - 2018-10-21 17:41:58 --> URI Class Initialized
DEBUG - 2018-10-21 17:41:58 --> No URI present. Default controller set.
INFO - 2018-10-21 17:41:58 --> Router Class Initialized
INFO - 2018-10-21 17:41:58 --> Output Class Initialized
INFO - 2018-10-21 17:41:58 --> Security Class Initialized
DEBUG - 2018-10-21 17:41:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:41:58 --> Input Class Initialized
INFO - 2018-10-21 17:41:58 --> Language Class Initialized
INFO - 2018-10-21 17:41:58 --> Language Class Initialized
INFO - 2018-10-21 17:41:58 --> Config Class Initialized
INFO - 2018-10-21 17:41:58 --> Loader Class Initialized
INFO - 2018-10-21 17:41:58 --> Helper loaded: url_helper
INFO - 2018-10-21 17:41:58 --> Helper loaded: form_helper
INFO - 2018-10-21 17:41:58 --> Helper loaded: html_helper
INFO - 2018-10-21 17:41:58 --> Controller Class Initialized
DEBUG - 2018-10-21 17:41:58 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:41:58 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:41:58 --> Final output sent to browser
DEBUG - 2018-10-21 17:41:58 --> Total execution time: 0.3952
INFO - 2018-10-21 17:42:01 --> Config Class Initialized
INFO - 2018-10-21 17:42:01 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:42:01 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:42:01 --> Utf8 Class Initialized
INFO - 2018-10-21 17:42:01 --> URI Class Initialized
INFO - 2018-10-21 17:42:01 --> Router Class Initialized
INFO - 2018-10-21 17:42:01 --> Output Class Initialized
INFO - 2018-10-21 17:42:01 --> Security Class Initialized
DEBUG - 2018-10-21 17:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:42:01 --> Input Class Initialized
INFO - 2018-10-21 17:42:01 --> Language Class Initialized
INFO - 2018-10-21 17:42:01 --> Language Class Initialized
INFO - 2018-10-21 17:42:01 --> Config Class Initialized
INFO - 2018-10-21 17:42:01 --> Loader Class Initialized
INFO - 2018-10-21 17:42:01 --> Helper loaded: url_helper
INFO - 2018-10-21 17:42:01 --> Helper loaded: form_helper
INFO - 2018-10-21 17:42:01 --> Helper loaded: html_helper
INFO - 2018-10-21 17:42:01 --> Controller Class Initialized
ERROR - 2018-10-21 17:42:01 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:42:03 --> Config Class Initialized
INFO - 2018-10-21 17:42:03 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:42:03 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:42:03 --> Utf8 Class Initialized
INFO - 2018-10-21 17:42:03 --> URI Class Initialized
DEBUG - 2018-10-21 17:42:04 --> No URI present. Default controller set.
INFO - 2018-10-21 17:42:04 --> Router Class Initialized
INFO - 2018-10-21 17:42:04 --> Output Class Initialized
INFO - 2018-10-21 17:42:04 --> Security Class Initialized
DEBUG - 2018-10-21 17:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:42:04 --> Input Class Initialized
INFO - 2018-10-21 17:42:04 --> Language Class Initialized
INFO - 2018-10-21 17:42:04 --> Language Class Initialized
INFO - 2018-10-21 17:42:04 --> Config Class Initialized
INFO - 2018-10-21 17:42:04 --> Loader Class Initialized
INFO - 2018-10-21 17:42:04 --> Helper loaded: url_helper
INFO - 2018-10-21 17:42:04 --> Helper loaded: form_helper
INFO - 2018-10-21 17:42:04 --> Helper loaded: html_helper
INFO - 2018-10-21 17:42:04 --> Controller Class Initialized
DEBUG - 2018-10-21 17:42:04 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:42:04 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:42:04 --> Final output sent to browser
DEBUG - 2018-10-21 17:42:04 --> Total execution time: 0.4748
INFO - 2018-10-21 17:42:38 --> Config Class Initialized
INFO - 2018-10-21 17:42:38 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:42:38 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:42:38 --> Utf8 Class Initialized
INFO - 2018-10-21 17:42:38 --> URI Class Initialized
DEBUG - 2018-10-21 17:42:38 --> No URI present. Default controller set.
INFO - 2018-10-21 17:42:38 --> Router Class Initialized
INFO - 2018-10-21 17:42:38 --> Output Class Initialized
INFO - 2018-10-21 17:42:38 --> Security Class Initialized
DEBUG - 2018-10-21 17:42:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:42:38 --> Input Class Initialized
INFO - 2018-10-21 17:42:38 --> Language Class Initialized
INFO - 2018-10-21 17:42:38 --> Language Class Initialized
INFO - 2018-10-21 17:42:38 --> Config Class Initialized
INFO - 2018-10-21 17:42:38 --> Loader Class Initialized
INFO - 2018-10-21 17:42:38 --> Helper loaded: url_helper
INFO - 2018-10-21 17:42:39 --> Helper loaded: form_helper
INFO - 2018-10-21 17:42:39 --> Helper loaded: html_helper
INFO - 2018-10-21 17:42:39 --> Controller Class Initialized
DEBUG - 2018-10-21 17:42:39 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:42:39 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:42:39 --> Final output sent to browser
DEBUG - 2018-10-21 17:42:39 --> Total execution time: 0.3746
INFO - 2018-10-21 17:42:40 --> Config Class Initialized
INFO - 2018-10-21 17:42:40 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:42:40 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:42:40 --> Utf8 Class Initialized
INFO - 2018-10-21 17:42:40 --> URI Class Initialized
INFO - 2018-10-21 17:42:40 --> Router Class Initialized
INFO - 2018-10-21 17:42:40 --> Output Class Initialized
INFO - 2018-10-21 17:42:40 --> Security Class Initialized
DEBUG - 2018-10-21 17:42:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:42:40 --> Input Class Initialized
INFO - 2018-10-21 17:42:40 --> Language Class Initialized
INFO - 2018-10-21 17:42:40 --> Language Class Initialized
INFO - 2018-10-21 17:42:40 --> Config Class Initialized
INFO - 2018-10-21 17:42:40 --> Loader Class Initialized
INFO - 2018-10-21 17:42:40 --> Helper loaded: url_helper
INFO - 2018-10-21 17:42:40 --> Helper loaded: form_helper
INFO - 2018-10-21 17:42:40 --> Helper loaded: html_helper
INFO - 2018-10-21 17:42:40 --> Controller Class Initialized
ERROR - 2018-10-21 17:42:40 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:42:55 --> Config Class Initialized
INFO - 2018-10-21 17:42:55 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:42:55 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:42:55 --> Utf8 Class Initialized
INFO - 2018-10-21 17:42:55 --> URI Class Initialized
DEBUG - 2018-10-21 17:42:55 --> No URI present. Default controller set.
INFO - 2018-10-21 17:42:55 --> Router Class Initialized
INFO - 2018-10-21 17:42:55 --> Output Class Initialized
INFO - 2018-10-21 17:42:55 --> Security Class Initialized
DEBUG - 2018-10-21 17:42:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:42:55 --> Input Class Initialized
INFO - 2018-10-21 17:42:55 --> Language Class Initialized
INFO - 2018-10-21 17:42:55 --> Language Class Initialized
INFO - 2018-10-21 17:42:55 --> Config Class Initialized
INFO - 2018-10-21 17:42:55 --> Loader Class Initialized
INFO - 2018-10-21 17:42:55 --> Helper loaded: url_helper
INFO - 2018-10-21 17:42:55 --> Helper loaded: form_helper
INFO - 2018-10-21 17:42:55 --> Helper loaded: html_helper
INFO - 2018-10-21 17:42:55 --> Controller Class Initialized
DEBUG - 2018-10-21 17:42:55 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:42:55 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:42:55 --> Final output sent to browser
DEBUG - 2018-10-21 17:42:55 --> Total execution time: 0.4001
INFO - 2018-10-21 17:42:57 --> Config Class Initialized
INFO - 2018-10-21 17:42:57 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:42:57 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:42:57 --> Utf8 Class Initialized
INFO - 2018-10-21 17:42:57 --> URI Class Initialized
INFO - 2018-10-21 17:42:57 --> Router Class Initialized
INFO - 2018-10-21 17:42:57 --> Output Class Initialized
INFO - 2018-10-21 17:42:57 --> Security Class Initialized
DEBUG - 2018-10-21 17:42:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:42:57 --> Input Class Initialized
INFO - 2018-10-21 17:42:57 --> Language Class Initialized
INFO - 2018-10-21 17:42:57 --> Language Class Initialized
INFO - 2018-10-21 17:42:57 --> Config Class Initialized
INFO - 2018-10-21 17:42:57 --> Loader Class Initialized
INFO - 2018-10-21 17:42:57 --> Helper loaded: url_helper
INFO - 2018-10-21 17:42:57 --> Helper loaded: form_helper
INFO - 2018-10-21 17:42:57 --> Helper loaded: html_helper
INFO - 2018-10-21 17:42:57 --> Controller Class Initialized
ERROR - 2018-10-21 17:42:57 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:43:46 --> Config Class Initialized
INFO - 2018-10-21 17:43:46 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:43:46 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:43:46 --> Utf8 Class Initialized
INFO - 2018-10-21 17:43:46 --> URI Class Initialized
DEBUG - 2018-10-21 17:43:46 --> No URI present. Default controller set.
INFO - 2018-10-21 17:43:46 --> Router Class Initialized
INFO - 2018-10-21 17:43:46 --> Output Class Initialized
INFO - 2018-10-21 17:43:46 --> Security Class Initialized
DEBUG - 2018-10-21 17:43:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:43:46 --> Input Class Initialized
INFO - 2018-10-21 17:43:46 --> Language Class Initialized
INFO - 2018-10-21 17:43:46 --> Language Class Initialized
INFO - 2018-10-21 17:43:46 --> Config Class Initialized
INFO - 2018-10-21 17:43:46 --> Loader Class Initialized
INFO - 2018-10-21 17:43:46 --> Helper loaded: url_helper
INFO - 2018-10-21 17:43:46 --> Helper loaded: form_helper
INFO - 2018-10-21 17:43:46 --> Helper loaded: html_helper
INFO - 2018-10-21 17:43:46 --> Controller Class Initialized
DEBUG - 2018-10-21 17:43:46 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:43:46 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:43:46 --> Final output sent to browser
DEBUG - 2018-10-21 17:43:46 --> Total execution time: 0.6833
INFO - 2018-10-21 17:44:25 --> Config Class Initialized
INFO - 2018-10-21 17:44:25 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:44:25 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:44:25 --> Utf8 Class Initialized
INFO - 2018-10-21 17:44:25 --> URI Class Initialized
DEBUG - 2018-10-21 17:44:25 --> No URI present. Default controller set.
INFO - 2018-10-21 17:44:25 --> Router Class Initialized
INFO - 2018-10-21 17:44:26 --> Output Class Initialized
INFO - 2018-10-21 17:44:26 --> Security Class Initialized
DEBUG - 2018-10-21 17:44:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:44:26 --> Input Class Initialized
INFO - 2018-10-21 17:44:26 --> Language Class Initialized
INFO - 2018-10-21 17:44:26 --> Language Class Initialized
INFO - 2018-10-21 17:44:26 --> Config Class Initialized
INFO - 2018-10-21 17:44:26 --> Loader Class Initialized
INFO - 2018-10-21 17:44:26 --> Helper loaded: url_helper
INFO - 2018-10-21 17:44:26 --> Helper loaded: form_helper
INFO - 2018-10-21 17:44:26 --> Helper loaded: html_helper
INFO - 2018-10-21 17:44:26 --> Controller Class Initialized
DEBUG - 2018-10-21 17:44:26 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:44:26 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:44:26 --> Final output sent to browser
DEBUG - 2018-10-21 17:44:26 --> Total execution time: 0.3650
INFO - 2018-10-21 17:44:43 --> Config Class Initialized
INFO - 2018-10-21 17:44:43 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:44:43 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:44:43 --> Utf8 Class Initialized
INFO - 2018-10-21 17:44:43 --> URI Class Initialized
INFO - 2018-10-21 17:44:43 --> Router Class Initialized
INFO - 2018-10-21 17:44:43 --> Output Class Initialized
INFO - 2018-10-21 17:44:43 --> Security Class Initialized
DEBUG - 2018-10-21 17:44:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:44:44 --> Input Class Initialized
INFO - 2018-10-21 17:44:44 --> Language Class Initialized
INFO - 2018-10-21 17:44:44 --> Language Class Initialized
INFO - 2018-10-21 17:44:44 --> Config Class Initialized
INFO - 2018-10-21 17:44:44 --> Loader Class Initialized
INFO - 2018-10-21 17:44:44 --> Helper loaded: url_helper
INFO - 2018-10-21 17:44:44 --> Helper loaded: form_helper
INFO - 2018-10-21 17:44:44 --> Helper loaded: html_helper
INFO - 2018-10-21 17:44:44 --> Controller Class Initialized
ERROR - 2018-10-21 17:44:44 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:44:46 --> Config Class Initialized
INFO - 2018-10-21 17:44:46 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:44:46 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:44:46 --> Utf8 Class Initialized
INFO - 2018-10-21 17:44:46 --> URI Class Initialized
DEBUG - 2018-10-21 17:44:46 --> No URI present. Default controller set.
INFO - 2018-10-21 17:44:46 --> Router Class Initialized
INFO - 2018-10-21 17:44:46 --> Output Class Initialized
INFO - 2018-10-21 17:44:46 --> Security Class Initialized
DEBUG - 2018-10-21 17:44:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:44:46 --> Input Class Initialized
INFO - 2018-10-21 17:44:46 --> Language Class Initialized
INFO - 2018-10-21 17:44:46 --> Language Class Initialized
INFO - 2018-10-21 17:44:47 --> Config Class Initialized
INFO - 2018-10-21 17:44:47 --> Loader Class Initialized
INFO - 2018-10-21 17:44:47 --> Helper loaded: url_helper
INFO - 2018-10-21 17:44:47 --> Helper loaded: form_helper
INFO - 2018-10-21 17:44:47 --> Helper loaded: html_helper
INFO - 2018-10-21 17:44:47 --> Controller Class Initialized
DEBUG - 2018-10-21 17:44:47 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:44:47 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:44:47 --> Final output sent to browser
DEBUG - 2018-10-21 17:44:47 --> Total execution time: 0.4686
INFO - 2018-10-21 17:44:51 --> Config Class Initialized
INFO - 2018-10-21 17:44:51 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:44:51 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:44:51 --> Utf8 Class Initialized
INFO - 2018-10-21 17:44:51 --> URI Class Initialized
INFO - 2018-10-21 17:44:51 --> Router Class Initialized
INFO - 2018-10-21 17:44:51 --> Output Class Initialized
INFO - 2018-10-21 17:44:51 --> Security Class Initialized
DEBUG - 2018-10-21 17:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:44:51 --> Input Class Initialized
INFO - 2018-10-21 17:44:51 --> Language Class Initialized
INFO - 2018-10-21 17:44:51 --> Language Class Initialized
INFO - 2018-10-21 17:44:51 --> Config Class Initialized
INFO - 2018-10-21 17:44:51 --> Loader Class Initialized
INFO - 2018-10-21 17:44:51 --> Helper loaded: url_helper
INFO - 2018-10-21 17:44:52 --> Helper loaded: form_helper
INFO - 2018-10-21 17:44:52 --> Helper loaded: html_helper
INFO - 2018-10-21 17:44:52 --> Controller Class Initialized
ERROR - 2018-10-21 17:44:52 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:47:32 --> Config Class Initialized
INFO - 2018-10-21 17:47:32 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:47:32 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:47:32 --> Utf8 Class Initialized
INFO - 2018-10-21 17:47:32 --> URI Class Initialized
DEBUG - 2018-10-21 17:47:32 --> No URI present. Default controller set.
INFO - 2018-10-21 17:47:32 --> Router Class Initialized
INFO - 2018-10-21 17:47:32 --> Output Class Initialized
INFO - 2018-10-21 17:47:32 --> Security Class Initialized
DEBUG - 2018-10-21 17:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:47:33 --> Input Class Initialized
INFO - 2018-10-21 17:47:33 --> Language Class Initialized
INFO - 2018-10-21 17:47:33 --> Language Class Initialized
INFO - 2018-10-21 17:47:33 --> Config Class Initialized
INFO - 2018-10-21 17:47:33 --> Loader Class Initialized
INFO - 2018-10-21 17:47:33 --> Helper loaded: url_helper
INFO - 2018-10-21 17:47:33 --> Helper loaded: form_helper
INFO - 2018-10-21 17:47:33 --> Helper loaded: html_helper
INFO - 2018-10-21 17:47:33 --> Controller Class Initialized
DEBUG - 2018-10-21 17:47:33 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:47:33 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:47:33 --> Final output sent to browser
DEBUG - 2018-10-21 17:47:33 --> Total execution time: 0.8469
INFO - 2018-10-21 17:47:54 --> Config Class Initialized
INFO - 2018-10-21 17:47:54 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:47:54 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:47:54 --> Utf8 Class Initialized
INFO - 2018-10-21 17:47:54 --> URI Class Initialized
DEBUG - 2018-10-21 17:47:54 --> No URI present. Default controller set.
INFO - 2018-10-21 17:47:54 --> Router Class Initialized
INFO - 2018-10-21 17:47:54 --> Output Class Initialized
INFO - 2018-10-21 17:47:54 --> Security Class Initialized
DEBUG - 2018-10-21 17:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:47:54 --> Input Class Initialized
INFO - 2018-10-21 17:47:54 --> Language Class Initialized
INFO - 2018-10-21 17:47:54 --> Language Class Initialized
INFO - 2018-10-21 17:47:54 --> Config Class Initialized
INFO - 2018-10-21 17:47:54 --> Loader Class Initialized
INFO - 2018-10-21 17:47:54 --> Helper loaded: url_helper
INFO - 2018-10-21 17:47:54 --> Helper loaded: form_helper
INFO - 2018-10-21 17:47:54 --> Helper loaded: html_helper
INFO - 2018-10-21 17:47:54 --> Controller Class Initialized
DEBUG - 2018-10-21 17:47:54 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:47:54 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:47:54 --> Final output sent to browser
DEBUG - 2018-10-21 17:47:54 --> Total execution time: 0.3998
INFO - 2018-10-21 17:48:56 --> Config Class Initialized
INFO - 2018-10-21 17:48:56 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:48:56 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:48:56 --> Utf8 Class Initialized
INFO - 2018-10-21 17:48:56 --> URI Class Initialized
DEBUG - 2018-10-21 17:48:56 --> No URI present. Default controller set.
INFO - 2018-10-21 17:48:56 --> Router Class Initialized
INFO - 2018-10-21 17:48:56 --> Output Class Initialized
INFO - 2018-10-21 17:48:56 --> Security Class Initialized
DEBUG - 2018-10-21 17:48:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:48:56 --> Input Class Initialized
INFO - 2018-10-21 17:48:56 --> Language Class Initialized
INFO - 2018-10-21 17:48:56 --> Language Class Initialized
INFO - 2018-10-21 17:48:56 --> Config Class Initialized
INFO - 2018-10-21 17:48:56 --> Loader Class Initialized
INFO - 2018-10-21 17:48:56 --> Helper loaded: url_helper
INFO - 2018-10-21 17:48:56 --> Helper loaded: form_helper
INFO - 2018-10-21 17:48:56 --> Helper loaded: html_helper
INFO - 2018-10-21 17:48:56 --> Controller Class Initialized
DEBUG - 2018-10-21 17:48:56 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:48:56 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:48:56 --> Final output sent to browser
DEBUG - 2018-10-21 17:48:56 --> Total execution time: 0.4100
INFO - 2018-10-21 17:51:21 --> Config Class Initialized
INFO - 2018-10-21 17:51:21 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:51:21 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:51:21 --> Utf8 Class Initialized
INFO - 2018-10-21 17:51:21 --> URI Class Initialized
DEBUG - 2018-10-21 17:51:21 --> No URI present. Default controller set.
INFO - 2018-10-21 17:51:21 --> Router Class Initialized
INFO - 2018-10-21 17:51:21 --> Output Class Initialized
INFO - 2018-10-21 17:51:21 --> Security Class Initialized
DEBUG - 2018-10-21 17:51:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:51:21 --> Input Class Initialized
INFO - 2018-10-21 17:51:21 --> Language Class Initialized
INFO - 2018-10-21 17:51:21 --> Language Class Initialized
INFO - 2018-10-21 17:51:21 --> Config Class Initialized
INFO - 2018-10-21 17:51:21 --> Loader Class Initialized
INFO - 2018-10-21 17:51:21 --> Helper loaded: url_helper
INFO - 2018-10-21 17:51:21 --> Helper loaded: form_helper
INFO - 2018-10-21 17:51:21 --> Helper loaded: html_helper
INFO - 2018-10-21 17:51:21 --> Controller Class Initialized
DEBUG - 2018-10-21 17:51:21 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:51:21 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:51:21 --> Final output sent to browser
DEBUG - 2018-10-21 17:51:21 --> Total execution time: 0.4346
INFO - 2018-10-21 17:51:23 --> Config Class Initialized
INFO - 2018-10-21 17:51:23 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:51:23 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:51:23 --> Utf8 Class Initialized
INFO - 2018-10-21 17:51:23 --> URI Class Initialized
DEBUG - 2018-10-21 17:51:23 --> No URI present. Default controller set.
INFO - 2018-10-21 17:51:23 --> Router Class Initialized
INFO - 2018-10-21 17:51:23 --> Output Class Initialized
INFO - 2018-10-21 17:51:23 --> Security Class Initialized
DEBUG - 2018-10-21 17:51:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:51:23 --> Input Class Initialized
INFO - 2018-10-21 17:51:23 --> Language Class Initialized
INFO - 2018-10-21 17:51:23 --> Language Class Initialized
INFO - 2018-10-21 17:51:23 --> Config Class Initialized
INFO - 2018-10-21 17:51:23 --> Loader Class Initialized
INFO - 2018-10-21 17:51:23 --> Helper loaded: url_helper
INFO - 2018-10-21 17:51:23 --> Helper loaded: form_helper
INFO - 2018-10-21 17:51:23 --> Helper loaded: html_helper
INFO - 2018-10-21 17:51:23 --> Controller Class Initialized
DEBUG - 2018-10-21 17:51:23 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:51:23 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:51:23 --> Final output sent to browser
DEBUG - 2018-10-21 17:51:23 --> Total execution time: 0.4087
INFO - 2018-10-21 17:51:45 --> Config Class Initialized
INFO - 2018-10-21 17:51:45 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:51:45 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:51:45 --> Utf8 Class Initialized
INFO - 2018-10-21 17:51:45 --> URI Class Initialized
INFO - 2018-10-21 17:51:45 --> Router Class Initialized
INFO - 2018-10-21 17:51:46 --> Output Class Initialized
INFO - 2018-10-21 17:51:46 --> Security Class Initialized
DEBUG - 2018-10-21 17:51:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:51:46 --> Input Class Initialized
INFO - 2018-10-21 17:51:46 --> Language Class Initialized
INFO - 2018-10-21 17:51:46 --> Language Class Initialized
INFO - 2018-10-21 17:51:46 --> Config Class Initialized
INFO - 2018-10-21 17:51:46 --> Loader Class Initialized
INFO - 2018-10-21 17:51:46 --> Helper loaded: url_helper
INFO - 2018-10-21 17:51:46 --> Helper loaded: form_helper
INFO - 2018-10-21 17:51:46 --> Helper loaded: html_helper
INFO - 2018-10-21 17:51:46 --> Controller Class Initialized
ERROR - 2018-10-21 17:51:46 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:51:48 --> Config Class Initialized
INFO - 2018-10-21 17:51:48 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:51:48 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:51:48 --> Utf8 Class Initialized
INFO - 2018-10-21 17:51:48 --> URI Class Initialized
DEBUG - 2018-10-21 17:51:48 --> No URI present. Default controller set.
INFO - 2018-10-21 17:51:48 --> Router Class Initialized
INFO - 2018-10-21 17:51:48 --> Output Class Initialized
INFO - 2018-10-21 17:51:49 --> Security Class Initialized
DEBUG - 2018-10-21 17:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:51:49 --> Input Class Initialized
INFO - 2018-10-21 17:51:49 --> Language Class Initialized
INFO - 2018-10-21 17:51:49 --> Language Class Initialized
INFO - 2018-10-21 17:51:49 --> Config Class Initialized
INFO - 2018-10-21 17:51:49 --> Loader Class Initialized
INFO - 2018-10-21 17:51:49 --> Helper loaded: url_helper
INFO - 2018-10-21 17:51:49 --> Helper loaded: form_helper
INFO - 2018-10-21 17:51:49 --> Helper loaded: html_helper
INFO - 2018-10-21 17:51:49 --> Controller Class Initialized
DEBUG - 2018-10-21 17:51:49 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:51:49 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:51:49 --> Final output sent to browser
DEBUG - 2018-10-21 17:51:49 --> Total execution time: 0.4578
INFO - 2018-10-21 17:52:02 --> Config Class Initialized
INFO - 2018-10-21 17:52:02 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:52:02 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:52:02 --> Utf8 Class Initialized
INFO - 2018-10-21 17:52:02 --> URI Class Initialized
INFO - 2018-10-21 17:52:02 --> Router Class Initialized
INFO - 2018-10-21 17:52:02 --> Output Class Initialized
INFO - 2018-10-21 17:52:02 --> Security Class Initialized
DEBUG - 2018-10-21 17:52:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:52:02 --> Input Class Initialized
INFO - 2018-10-21 17:52:02 --> Language Class Initialized
INFO - 2018-10-21 17:52:02 --> Language Class Initialized
INFO - 2018-10-21 17:52:02 --> Config Class Initialized
INFO - 2018-10-21 17:52:02 --> Loader Class Initialized
INFO - 2018-10-21 17:52:02 --> Helper loaded: url_helper
INFO - 2018-10-21 17:52:02 --> Helper loaded: form_helper
INFO - 2018-10-21 17:52:02 --> Helper loaded: html_helper
INFO - 2018-10-21 17:52:02 --> Controller Class Initialized
ERROR - 2018-10-21 17:52:02 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 17:52:06 --> Config Class Initialized
INFO - 2018-10-21 17:52:06 --> Hooks Class Initialized
DEBUG - 2018-10-21 17:52:06 --> UTF-8 Support Enabled
INFO - 2018-10-21 17:52:06 --> Utf8 Class Initialized
INFO - 2018-10-21 17:52:06 --> URI Class Initialized
DEBUG - 2018-10-21 17:52:06 --> No URI present. Default controller set.
INFO - 2018-10-21 17:52:06 --> Router Class Initialized
INFO - 2018-10-21 17:52:06 --> Output Class Initialized
INFO - 2018-10-21 17:52:06 --> Security Class Initialized
DEBUG - 2018-10-21 17:52:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 17:52:06 --> Input Class Initialized
INFO - 2018-10-21 17:52:06 --> Language Class Initialized
INFO - 2018-10-21 17:52:06 --> Language Class Initialized
INFO - 2018-10-21 17:52:06 --> Config Class Initialized
INFO - 2018-10-21 17:52:06 --> Loader Class Initialized
INFO - 2018-10-21 17:52:06 --> Helper loaded: url_helper
INFO - 2018-10-21 17:52:06 --> Helper loaded: form_helper
INFO - 2018-10-21 17:52:06 --> Helper loaded: html_helper
INFO - 2018-10-21 17:52:06 --> Controller Class Initialized
DEBUG - 2018-10-21 17:52:06 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 17:52:06 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/home.php
INFO - 2018-10-21 17:52:06 --> Final output sent to browser
DEBUG - 2018-10-21 17:52:06 --> Total execution time: 0.4822
INFO - 2018-10-21 18:05:38 --> Config Class Initialized
INFO - 2018-10-21 18:05:38 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:05:38 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:05:38 --> Utf8 Class Initialized
INFO - 2018-10-21 18:05:38 --> URI Class Initialized
DEBUG - 2018-10-21 18:05:39 --> No URI present. Default controller set.
INFO - 2018-10-21 18:05:39 --> Router Class Initialized
INFO - 2018-10-21 18:05:39 --> Output Class Initialized
INFO - 2018-10-21 18:05:39 --> Security Class Initialized
DEBUG - 2018-10-21 18:05:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:05:39 --> Input Class Initialized
INFO - 2018-10-21 18:05:39 --> Language Class Initialized
INFO - 2018-10-21 18:05:39 --> Language Class Initialized
INFO - 2018-10-21 18:05:39 --> Config Class Initialized
INFO - 2018-10-21 18:05:39 --> Loader Class Initialized
INFO - 2018-10-21 18:05:39 --> Helper loaded: url_helper
INFO - 2018-10-21 18:05:39 --> Helper loaded: form_helper
INFO - 2018-10-21 18:05:39 --> Helper loaded: html_helper
INFO - 2018-10-21 18:05:39 --> Helper loaded: email_helper
INFO - 2018-10-21 18:05:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:05:40 --> Form Validation Class Initialized
INFO - 2018-10-21 18:05:40 --> Email Class Initialized
INFO - 2018-10-21 18:05:40 --> Controller Class Initialized
DEBUG - 2018-10-21 18:05:40 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:05:40 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/sign_in.php
INFO - 2018-10-21 18:05:40 --> Final output sent to browser
DEBUG - 2018-10-21 18:05:40 --> Total execution time: 1.8073
INFO - 2018-10-21 18:06:14 --> Config Class Initialized
INFO - 2018-10-21 18:06:14 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:06:14 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:06:14 --> Utf8 Class Initialized
INFO - 2018-10-21 18:06:14 --> URI Class Initialized
DEBUG - 2018-10-21 18:06:14 --> No URI present. Default controller set.
INFO - 2018-10-21 18:06:14 --> Router Class Initialized
INFO - 2018-10-21 18:06:14 --> Output Class Initialized
INFO - 2018-10-21 18:06:14 --> Security Class Initialized
DEBUG - 2018-10-21 18:06:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:06:14 --> Input Class Initialized
INFO - 2018-10-21 18:06:14 --> Language Class Initialized
INFO - 2018-10-21 18:06:14 --> Language Class Initialized
INFO - 2018-10-21 18:06:14 --> Config Class Initialized
INFO - 2018-10-21 18:06:14 --> Loader Class Initialized
INFO - 2018-10-21 18:06:14 --> Helper loaded: url_helper
INFO - 2018-10-21 18:06:14 --> Helper loaded: form_helper
INFO - 2018-10-21 18:06:14 --> Helper loaded: html_helper
INFO - 2018-10-21 18:06:14 --> Helper loaded: email_helper
INFO - 2018-10-21 18:06:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:06:14 --> Form Validation Class Initialized
INFO - 2018-10-21 18:06:14 --> Email Class Initialized
INFO - 2018-10-21 18:06:14 --> Controller Class Initialized
DEBUG - 2018-10-21 18:06:14 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:06:14 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/sign_in.php
INFO - 2018-10-21 18:06:14 --> Final output sent to browser
DEBUG - 2018-10-21 18:06:14 --> Total execution time: 0.4649
INFO - 2018-10-21 18:06:28 --> Config Class Initialized
INFO - 2018-10-21 18:06:28 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:06:28 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:06:28 --> Utf8 Class Initialized
INFO - 2018-10-21 18:06:28 --> URI Class Initialized
INFO - 2018-10-21 18:06:28 --> Router Class Initialized
INFO - 2018-10-21 18:06:28 --> Output Class Initialized
INFO - 2018-10-21 18:06:28 --> Security Class Initialized
DEBUG - 2018-10-21 18:06:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:06:28 --> Input Class Initialized
INFO - 2018-10-21 18:06:28 --> Language Class Initialized
INFO - 2018-10-21 18:06:28 --> Language Class Initialized
INFO - 2018-10-21 18:06:28 --> Config Class Initialized
INFO - 2018-10-21 18:06:28 --> Loader Class Initialized
INFO - 2018-10-21 18:06:28 --> Helper loaded: url_helper
INFO - 2018-10-21 18:06:28 --> Helper loaded: form_helper
INFO - 2018-10-21 18:06:28 --> Helper loaded: html_helper
INFO - 2018-10-21 18:06:28 --> Helper loaded: email_helper
INFO - 2018-10-21 18:06:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:06:29 --> Form Validation Class Initialized
INFO - 2018-10-21 18:06:29 --> Email Class Initialized
INFO - 2018-10-21 18:06:29 --> Controller Class Initialized
DEBUG - 2018-10-21 18:06:29 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:06:29 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-21 18:06:29 --> Severity: 8192 --> idn_to_ascii(): INTL_IDNA_VARIANT_2003 is deprecated C:\wamp64\www\CI\system\libraries\Form_validation.php 1249
INFO - 2018-10-21 18:06:29 --> Final output sent to browser
DEBUG - 2018-10-21 18:06:29 --> Total execution time: 0.8252
INFO - 2018-10-21 18:07:01 --> Config Class Initialized
INFO - 2018-10-21 18:07:01 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:07:01 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:07:02 --> Utf8 Class Initialized
INFO - 2018-10-21 18:07:02 --> URI Class Initialized
DEBUG - 2018-10-21 18:07:02 --> No URI present. Default controller set.
INFO - 2018-10-21 18:07:02 --> Router Class Initialized
INFO - 2018-10-21 18:07:02 --> Output Class Initialized
INFO - 2018-10-21 18:07:02 --> Security Class Initialized
DEBUG - 2018-10-21 18:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:07:02 --> Input Class Initialized
INFO - 2018-10-21 18:07:02 --> Language Class Initialized
INFO - 2018-10-21 18:07:02 --> Language Class Initialized
INFO - 2018-10-21 18:07:02 --> Config Class Initialized
INFO - 2018-10-21 18:07:02 --> Loader Class Initialized
INFO - 2018-10-21 18:07:02 --> Helper loaded: url_helper
INFO - 2018-10-21 18:07:02 --> Helper loaded: form_helper
INFO - 2018-10-21 18:07:02 --> Helper loaded: html_helper
INFO - 2018-10-21 18:07:02 --> Helper loaded: email_helper
INFO - 2018-10-21 18:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:07:02 --> Form Validation Class Initialized
INFO - 2018-10-21 18:07:02 --> Email Class Initialized
INFO - 2018-10-21 18:07:02 --> Controller Class Initialized
DEBUG - 2018-10-21 18:07:02 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:07:02 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/sign_in.php
INFO - 2018-10-21 18:07:02 --> Final output sent to browser
DEBUG - 2018-10-21 18:07:02 --> Total execution time: 0.5975
INFO - 2018-10-21 18:07:04 --> Config Class Initialized
INFO - 2018-10-21 18:07:04 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:07:04 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:07:04 --> Utf8 Class Initialized
INFO - 2018-10-21 18:07:04 --> URI Class Initialized
DEBUG - 2018-10-21 18:07:04 --> No URI present. Default controller set.
INFO - 2018-10-21 18:07:04 --> Router Class Initialized
INFO - 2018-10-21 18:07:04 --> Output Class Initialized
INFO - 2018-10-21 18:07:04 --> Security Class Initialized
DEBUG - 2018-10-21 18:07:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:07:04 --> Input Class Initialized
INFO - 2018-10-21 18:07:04 --> Language Class Initialized
INFO - 2018-10-21 18:07:04 --> Language Class Initialized
INFO - 2018-10-21 18:07:04 --> Config Class Initialized
INFO - 2018-10-21 18:07:04 --> Loader Class Initialized
INFO - 2018-10-21 18:07:04 --> Helper loaded: url_helper
INFO - 2018-10-21 18:07:04 --> Helper loaded: form_helper
INFO - 2018-10-21 18:07:04 --> Helper loaded: html_helper
INFO - 2018-10-21 18:07:04 --> Helper loaded: email_helper
INFO - 2018-10-21 18:07:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:07:04 --> Form Validation Class Initialized
INFO - 2018-10-21 18:07:04 --> Email Class Initialized
INFO - 2018-10-21 18:07:04 --> Controller Class Initialized
DEBUG - 2018-10-21 18:07:04 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:07:04 --> File loaded: C:\wamp64\www\CI\application\modules/Products/views/sign_in.php
INFO - 2018-10-21 18:07:04 --> Final output sent to browser
DEBUG - 2018-10-21 18:07:04 --> Total execution time: 0.8019
INFO - 2018-10-21 18:07:11 --> Config Class Initialized
INFO - 2018-10-21 18:07:12 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:07:12 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:07:12 --> Utf8 Class Initialized
INFO - 2018-10-21 18:07:12 --> URI Class Initialized
INFO - 2018-10-21 18:07:12 --> Router Class Initialized
INFO - 2018-10-21 18:07:12 --> Output Class Initialized
INFO - 2018-10-21 18:07:12 --> Security Class Initialized
DEBUG - 2018-10-21 18:07:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:07:12 --> Input Class Initialized
INFO - 2018-10-21 18:07:12 --> Language Class Initialized
INFO - 2018-10-21 18:07:12 --> Language Class Initialized
INFO - 2018-10-21 18:07:12 --> Config Class Initialized
INFO - 2018-10-21 18:07:12 --> Loader Class Initialized
INFO - 2018-10-21 18:07:12 --> Helper loaded: url_helper
INFO - 2018-10-21 18:07:12 --> Helper loaded: form_helper
INFO - 2018-10-21 18:07:12 --> Helper loaded: html_helper
INFO - 2018-10-21 18:07:12 --> Helper loaded: email_helper
INFO - 2018-10-21 18:07:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:07:12 --> Form Validation Class Initialized
INFO - 2018-10-21 18:07:12 --> Email Class Initialized
INFO - 2018-10-21 18:07:12 --> Controller Class Initialized
DEBUG - 2018-10-21 18:07:12 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:07:12 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-21 18:07:12 --> Severity: 8192 --> idn_to_ascii(): INTL_IDNA_VARIANT_2003 is deprecated C:\wamp64\www\CI\system\libraries\Form_validation.php 1249
DEBUG - 2018-10-21 18:07:12 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:07:12 --> Final output sent to browser
DEBUG - 2018-10-21 18:07:12 --> Total execution time: 0.6824
INFO - 2018-10-21 18:10:56 --> Config Class Initialized
INFO - 2018-10-21 18:10:56 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:10:56 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:10:56 --> Utf8 Class Initialized
INFO - 2018-10-21 18:10:56 --> URI Class Initialized
INFO - 2018-10-21 18:10:56 --> Router Class Initialized
INFO - 2018-10-21 18:10:56 --> Output Class Initialized
INFO - 2018-10-21 18:10:56 --> Security Class Initialized
DEBUG - 2018-10-21 18:10:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:10:56 --> Input Class Initialized
INFO - 2018-10-21 18:10:56 --> Language Class Initialized
INFO - 2018-10-21 18:10:56 --> Language Class Initialized
INFO - 2018-10-21 18:10:57 --> Config Class Initialized
INFO - 2018-10-21 18:10:57 --> Loader Class Initialized
INFO - 2018-10-21 18:10:57 --> Helper loaded: url_helper
INFO - 2018-10-21 18:10:57 --> Helper loaded: form_helper
INFO - 2018-10-21 18:10:57 --> Helper loaded: html_helper
INFO - 2018-10-21 18:10:57 --> Helper loaded: email_helper
INFO - 2018-10-21 18:10:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:10:57 --> Form Validation Class Initialized
INFO - 2018-10-21 18:10:57 --> Email Class Initialized
INFO - 2018-10-21 18:10:57 --> Controller Class Initialized
DEBUG - 2018-10-21 18:10:57 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:10:57 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-21 18:10:57 --> Severity: 8192 --> idn_to_ascii(): INTL_IDNA_VARIANT_2003 is deprecated C:\wamp64\www\CI\system\libraries\Form_validation.php 1249
ERROR - 2018-10-21 18:10:57 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\wamp64\www\CI\application\modules\Products\views\home.php 32
ERROR - 2018-10-21 18:10:57 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of ParseError given, called in C:\wamp64\www\CI\system\core\Common.php on line 658 and defined in C:\wamp64\www\CI\system\core\Exceptions.php:190
Stack trace:
#0 C:\wamp64\www\CI\system\core\Common.php(658): CI_Exceptions->show_exception(Object(ParseError))
#1 [internal function]: _exception_handler(Object(ParseError))
#2 {main}
  thrown C:\wamp64\www\CI\system\core\Exceptions.php 190
INFO - 2018-10-21 18:11:34 --> Config Class Initialized
INFO - 2018-10-21 18:11:34 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:11:34 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:11:34 --> Utf8 Class Initialized
INFO - 2018-10-21 18:11:34 --> URI Class Initialized
INFO - 2018-10-21 18:11:34 --> Router Class Initialized
INFO - 2018-10-21 18:11:34 --> Output Class Initialized
INFO - 2018-10-21 18:11:34 --> Security Class Initialized
DEBUG - 2018-10-21 18:11:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:11:34 --> Input Class Initialized
INFO - 2018-10-21 18:11:34 --> Language Class Initialized
INFO - 2018-10-21 18:11:34 --> Language Class Initialized
INFO - 2018-10-21 18:11:34 --> Config Class Initialized
INFO - 2018-10-21 18:11:34 --> Loader Class Initialized
INFO - 2018-10-21 18:11:34 --> Helper loaded: url_helper
INFO - 2018-10-21 18:11:34 --> Helper loaded: form_helper
INFO - 2018-10-21 18:11:34 --> Helper loaded: html_helper
INFO - 2018-10-21 18:11:34 --> Helper loaded: email_helper
INFO - 2018-10-21 18:11:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:11:34 --> Form Validation Class Initialized
INFO - 2018-10-21 18:11:34 --> Email Class Initialized
INFO - 2018-10-21 18:11:34 --> Controller Class Initialized
DEBUG - 2018-10-21 18:11:34 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:11:34 --> Final output sent to browser
DEBUG - 2018-10-21 18:11:34 --> Total execution time: 0.4933
INFO - 2018-10-21 18:11:39 --> Config Class Initialized
INFO - 2018-10-21 18:11:39 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:11:39 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:11:39 --> Utf8 Class Initialized
INFO - 2018-10-21 18:11:39 --> URI Class Initialized
INFO - 2018-10-21 18:11:39 --> Router Class Initialized
INFO - 2018-10-21 18:11:39 --> Output Class Initialized
INFO - 2018-10-21 18:11:39 --> Security Class Initialized
DEBUG - 2018-10-21 18:11:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:11:40 --> Input Class Initialized
INFO - 2018-10-21 18:11:40 --> Language Class Initialized
INFO - 2018-10-21 18:11:40 --> Language Class Initialized
INFO - 2018-10-21 18:11:40 --> Config Class Initialized
INFO - 2018-10-21 18:11:40 --> Loader Class Initialized
INFO - 2018-10-21 18:11:40 --> Helper loaded: url_helper
INFO - 2018-10-21 18:11:40 --> Helper loaded: form_helper
INFO - 2018-10-21 18:11:40 --> Helper loaded: html_helper
INFO - 2018-10-21 18:11:40 --> Helper loaded: email_helper
INFO - 2018-10-21 18:11:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:11:40 --> Form Validation Class Initialized
INFO - 2018-10-21 18:11:40 --> Email Class Initialized
INFO - 2018-10-21 18:11:40 --> Controller Class Initialized
DEBUG - 2018-10-21 18:11:40 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:11:40 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:11:40 --> Final output sent to browser
DEBUG - 2018-10-21 18:11:40 --> Total execution time: 0.5667
INFO - 2018-10-21 18:11:49 --> Config Class Initialized
INFO - 2018-10-21 18:11:49 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:11:49 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:11:49 --> Utf8 Class Initialized
INFO - 2018-10-21 18:11:49 --> URI Class Initialized
INFO - 2018-10-21 18:11:49 --> Router Class Initialized
INFO - 2018-10-21 18:11:49 --> Output Class Initialized
INFO - 2018-10-21 18:11:49 --> Security Class Initialized
DEBUG - 2018-10-21 18:11:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:11:49 --> Input Class Initialized
INFO - 2018-10-21 18:11:49 --> Language Class Initialized
INFO - 2018-10-21 18:11:49 --> Language Class Initialized
INFO - 2018-10-21 18:11:49 --> Config Class Initialized
INFO - 2018-10-21 18:11:49 --> Loader Class Initialized
INFO - 2018-10-21 18:11:49 --> Helper loaded: url_helper
INFO - 2018-10-21 18:11:49 --> Helper loaded: form_helper
INFO - 2018-10-21 18:11:49 --> Helper loaded: html_helper
INFO - 2018-10-21 18:11:49 --> Helper loaded: email_helper
INFO - 2018-10-21 18:11:49 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:11:49 --> Form Validation Class Initialized
INFO - 2018-10-21 18:11:49 --> Email Class Initialized
INFO - 2018-10-21 18:11:50 --> Controller Class Initialized
DEBUG - 2018-10-21 18:11:50 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:11:50 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-21 18:11:50 --> Severity: 8192 --> idn_to_ascii(): INTL_IDNA_VARIANT_2003 is deprecated C:\wamp64\www\CI\system\libraries\Form_validation.php 1249
ERROR - 2018-10-21 18:11:50 --> Severity: error --> Exception: syntax error, unexpected '}', expecting ',' or ';' C:\wamp64\www\CI\application\modules\Products\views\home.php 32
ERROR - 2018-10-21 18:11:50 --> Severity: Error --> Uncaught TypeError: Argument 1 passed to CI_Exceptions::show_exception() must be an instance of Exception, instance of ParseError given, called in C:\wamp64\www\CI\system\core\Common.php on line 658 and defined in C:\wamp64\www\CI\system\core\Exceptions.php:190
Stack trace:
#0 C:\wamp64\www\CI\system\core\Common.php(658): CI_Exceptions->show_exception(Object(ParseError))
#1 [internal function]: _exception_handler(Object(ParseError))
#2 {main}
  thrown C:\wamp64\www\CI\system\core\Exceptions.php 190
INFO - 2018-10-21 18:12:00 --> Config Class Initialized
INFO - 2018-10-21 18:12:00 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:12:00 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:12:00 --> Utf8 Class Initialized
INFO - 2018-10-21 18:12:00 --> URI Class Initialized
INFO - 2018-10-21 18:12:00 --> Router Class Initialized
INFO - 2018-10-21 18:12:00 --> Output Class Initialized
INFO - 2018-10-21 18:12:00 --> Security Class Initialized
DEBUG - 2018-10-21 18:12:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:12:00 --> Input Class Initialized
INFO - 2018-10-21 18:12:00 --> Language Class Initialized
INFO - 2018-10-21 18:12:00 --> Language Class Initialized
INFO - 2018-10-21 18:12:00 --> Config Class Initialized
INFO - 2018-10-21 18:12:00 --> Loader Class Initialized
INFO - 2018-10-21 18:12:00 --> Helper loaded: url_helper
INFO - 2018-10-21 18:12:00 --> Helper loaded: form_helper
INFO - 2018-10-21 18:12:00 --> Helper loaded: html_helper
INFO - 2018-10-21 18:12:00 --> Helper loaded: email_helper
INFO - 2018-10-21 18:12:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:12:00 --> Form Validation Class Initialized
INFO - 2018-10-21 18:12:00 --> Email Class Initialized
INFO - 2018-10-21 18:12:00 --> Controller Class Initialized
DEBUG - 2018-10-21 18:12:00 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:12:00 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-21 18:12:00 --> Severity: 8192 --> idn_to_ascii(): INTL_IDNA_VARIANT_2003 is deprecated C:\wamp64\www\CI\system\libraries\Form_validation.php 1249
DEBUG - 2018-10-21 18:12:01 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:12:01 --> Final output sent to browser
DEBUG - 2018-10-21 18:12:01 --> Total execution time: 0.5355
INFO - 2018-10-21 18:13:06 --> Config Class Initialized
INFO - 2018-10-21 18:13:06 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:13:06 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:13:06 --> Utf8 Class Initialized
INFO - 2018-10-21 18:13:06 --> URI Class Initialized
INFO - 2018-10-21 18:13:06 --> Router Class Initialized
INFO - 2018-10-21 18:13:06 --> Output Class Initialized
INFO - 2018-10-21 18:13:06 --> Security Class Initialized
DEBUG - 2018-10-21 18:13:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:13:06 --> Input Class Initialized
INFO - 2018-10-21 18:13:06 --> Language Class Initialized
INFO - 2018-10-21 18:13:06 --> Language Class Initialized
INFO - 2018-10-21 18:13:06 --> Config Class Initialized
INFO - 2018-10-21 18:13:06 --> Loader Class Initialized
INFO - 2018-10-21 18:13:06 --> Helper loaded: url_helper
INFO - 2018-10-21 18:13:06 --> Helper loaded: form_helper
INFO - 2018-10-21 18:13:06 --> Helper loaded: html_helper
INFO - 2018-10-21 18:13:06 --> Helper loaded: email_helper
INFO - 2018-10-21 18:13:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:13:07 --> Form Validation Class Initialized
INFO - 2018-10-21 18:13:07 --> Email Class Initialized
INFO - 2018-10-21 18:13:07 --> Controller Class Initialized
DEBUG - 2018-10-21 18:13:07 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:13:07 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-21 18:13:07 --> Severity: 8192 --> idn_to_ascii(): INTL_IDNA_VARIANT_2003 is deprecated C:\wamp64\www\CI\system\libraries\Form_validation.php 1249
DEBUG - 2018-10-21 18:13:07 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:13:07 --> Final output sent to browser
DEBUG - 2018-10-21 18:13:07 --> Total execution time: 0.5502
INFO - 2018-10-21 18:13:09 --> Config Class Initialized
INFO - 2018-10-21 18:13:09 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:13:09 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:13:09 --> Utf8 Class Initialized
INFO - 2018-10-21 18:13:09 --> URI Class Initialized
INFO - 2018-10-21 18:13:09 --> Router Class Initialized
INFO - 2018-10-21 18:13:09 --> Output Class Initialized
INFO - 2018-10-21 18:13:09 --> Security Class Initialized
DEBUG - 2018-10-21 18:13:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:13:09 --> Input Class Initialized
INFO - 2018-10-21 18:13:09 --> Language Class Initialized
INFO - 2018-10-21 18:13:09 --> Language Class Initialized
INFO - 2018-10-21 18:13:09 --> Config Class Initialized
INFO - 2018-10-21 18:13:09 --> Loader Class Initialized
INFO - 2018-10-21 18:13:09 --> Helper loaded: url_helper
INFO - 2018-10-21 18:13:09 --> Helper loaded: form_helper
INFO - 2018-10-21 18:13:09 --> Helper loaded: html_helper
INFO - 2018-10-21 18:13:09 --> Helper loaded: email_helper
INFO - 2018-10-21 18:13:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:13:09 --> Form Validation Class Initialized
INFO - 2018-10-21 18:13:09 --> Email Class Initialized
INFO - 2018-10-21 18:13:09 --> Controller Class Initialized
DEBUG - 2018-10-21 18:13:09 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:13:09 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-21 18:13:09 --> Severity: 8192 --> idn_to_ascii(): INTL_IDNA_VARIANT_2003 is deprecated C:\wamp64\www\CI\system\libraries\Form_validation.php 1249
DEBUG - 2018-10-21 18:13:09 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:13:09 --> Final output sent to browser
DEBUG - 2018-10-21 18:13:09 --> Total execution time: 0.5295
INFO - 2018-10-21 18:13:39 --> Config Class Initialized
INFO - 2018-10-21 18:13:40 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:13:40 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:13:40 --> Utf8 Class Initialized
INFO - 2018-10-21 18:13:40 --> URI Class Initialized
INFO - 2018-10-21 18:13:40 --> Router Class Initialized
INFO - 2018-10-21 18:13:40 --> Output Class Initialized
INFO - 2018-10-21 18:13:40 --> Security Class Initialized
DEBUG - 2018-10-21 18:13:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:13:40 --> Input Class Initialized
INFO - 2018-10-21 18:13:40 --> Language Class Initialized
INFO - 2018-10-21 18:13:40 --> Language Class Initialized
INFO - 2018-10-21 18:13:40 --> Config Class Initialized
INFO - 2018-10-21 18:13:40 --> Loader Class Initialized
INFO - 2018-10-21 18:13:40 --> Helper loaded: url_helper
INFO - 2018-10-21 18:13:40 --> Helper loaded: form_helper
INFO - 2018-10-21 18:13:40 --> Helper loaded: html_helper
INFO - 2018-10-21 18:13:40 --> Helper loaded: email_helper
INFO - 2018-10-21 18:13:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:13:40 --> Form Validation Class Initialized
INFO - 2018-10-21 18:13:40 --> Email Class Initialized
INFO - 2018-10-21 18:13:40 --> Controller Class Initialized
DEBUG - 2018-10-21 18:13:40 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:13:40 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-21 18:13:40 --> Severity: 8192 --> idn_to_ascii(): INTL_IDNA_VARIANT_2003 is deprecated C:\wamp64\www\CI\system\libraries\Form_validation.php 1249
DEBUG - 2018-10-21 18:13:40 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:13:40 --> Final output sent to browser
DEBUG - 2018-10-21 18:13:40 --> Total execution time: 0.6499
INFO - 2018-10-21 18:13:45 --> Config Class Initialized
INFO - 2018-10-21 18:13:45 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:13:45 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:13:45 --> Utf8 Class Initialized
INFO - 2018-10-21 18:13:45 --> URI Class Initialized
INFO - 2018-10-21 18:13:45 --> Router Class Initialized
INFO - 2018-10-21 18:13:45 --> Output Class Initialized
INFO - 2018-10-21 18:13:45 --> Security Class Initialized
DEBUG - 2018-10-21 18:13:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:13:45 --> Input Class Initialized
INFO - 2018-10-21 18:13:45 --> Language Class Initialized
INFO - 2018-10-21 18:13:45 --> Language Class Initialized
INFO - 2018-10-21 18:13:45 --> Config Class Initialized
INFO - 2018-10-21 18:13:45 --> Loader Class Initialized
INFO - 2018-10-21 18:13:45 --> Helper loaded: url_helper
INFO - 2018-10-21 18:13:45 --> Helper loaded: form_helper
INFO - 2018-10-21 18:13:45 --> Helper loaded: html_helper
INFO - 2018-10-21 18:13:45 --> Helper loaded: email_helper
INFO - 2018-10-21 18:13:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:13:45 --> Form Validation Class Initialized
INFO - 2018-10-21 18:13:45 --> Email Class Initialized
INFO - 2018-10-21 18:13:45 --> Controller Class Initialized
DEBUG - 2018-10-21 18:13:45 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:13:45 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:13:45 --> Final output sent to browser
DEBUG - 2018-10-21 18:13:45 --> Total execution time: 0.5155
INFO - 2018-10-21 18:13:51 --> Config Class Initialized
INFO - 2018-10-21 18:13:51 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:13:51 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:13:51 --> Utf8 Class Initialized
INFO - 2018-10-21 18:13:51 --> URI Class Initialized
INFO - 2018-10-21 18:13:51 --> Router Class Initialized
INFO - 2018-10-21 18:13:51 --> Output Class Initialized
INFO - 2018-10-21 18:13:51 --> Security Class Initialized
DEBUG - 2018-10-21 18:13:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:13:51 --> Input Class Initialized
INFO - 2018-10-21 18:13:52 --> Language Class Initialized
INFO - 2018-10-21 18:13:52 --> Language Class Initialized
INFO - 2018-10-21 18:13:52 --> Config Class Initialized
INFO - 2018-10-21 18:13:52 --> Loader Class Initialized
INFO - 2018-10-21 18:13:52 --> Helper loaded: url_helper
INFO - 2018-10-21 18:13:52 --> Helper loaded: form_helper
INFO - 2018-10-21 18:13:52 --> Helper loaded: html_helper
INFO - 2018-10-21 18:13:52 --> Helper loaded: email_helper
INFO - 2018-10-21 18:13:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:13:52 --> Form Validation Class Initialized
INFO - 2018-10-21 18:13:52 --> Email Class Initialized
INFO - 2018-10-21 18:13:52 --> Controller Class Initialized
DEBUG - 2018-10-21 18:13:52 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:13:52 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:13:52 --> Final output sent to browser
DEBUG - 2018-10-21 18:13:52 --> Total execution time: 0.8473
INFO - 2018-10-21 18:13:55 --> Config Class Initialized
INFO - 2018-10-21 18:13:55 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:13:55 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:13:55 --> Utf8 Class Initialized
INFO - 2018-10-21 18:13:55 --> URI Class Initialized
INFO - 2018-10-21 18:13:55 --> Router Class Initialized
INFO - 2018-10-21 18:13:55 --> Output Class Initialized
INFO - 2018-10-21 18:13:55 --> Security Class Initialized
DEBUG - 2018-10-21 18:13:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:13:55 --> Input Class Initialized
INFO - 2018-10-21 18:13:55 --> Language Class Initialized
INFO - 2018-10-21 18:13:55 --> Language Class Initialized
INFO - 2018-10-21 18:13:55 --> Config Class Initialized
INFO - 2018-10-21 18:13:55 --> Loader Class Initialized
INFO - 2018-10-21 18:13:55 --> Helper loaded: url_helper
INFO - 2018-10-21 18:13:55 --> Helper loaded: form_helper
INFO - 2018-10-21 18:13:55 --> Helper loaded: html_helper
INFO - 2018-10-21 18:13:55 --> Helper loaded: email_helper
INFO - 2018-10-21 18:13:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:13:55 --> Form Validation Class Initialized
INFO - 2018-10-21 18:13:55 --> Email Class Initialized
INFO - 2018-10-21 18:13:55 --> Controller Class Initialized
DEBUG - 2018-10-21 18:13:55 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:13:55 --> Config Class Initialized
INFO - 2018-10-21 18:13:55 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:13:55 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:13:56 --> Utf8 Class Initialized
INFO - 2018-10-21 18:13:56 --> URI Class Initialized
INFO - 2018-10-21 18:13:56 --> Router Class Initialized
INFO - 2018-10-21 18:13:56 --> Output Class Initialized
INFO - 2018-10-21 18:13:56 --> Security Class Initialized
DEBUG - 2018-10-21 18:13:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:13:56 --> Input Class Initialized
INFO - 2018-10-21 18:13:56 --> Language Class Initialized
INFO - 2018-10-21 18:13:56 --> Language Class Initialized
INFO - 2018-10-21 18:13:56 --> Config Class Initialized
INFO - 2018-10-21 18:13:56 --> Loader Class Initialized
INFO - 2018-10-21 18:13:56 --> Helper loaded: url_helper
INFO - 2018-10-21 18:13:56 --> Helper loaded: form_helper
INFO - 2018-10-21 18:13:56 --> Helper loaded: html_helper
INFO - 2018-10-21 18:13:56 --> Helper loaded: email_helper
INFO - 2018-10-21 18:13:56 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:13:56 --> Form Validation Class Initialized
INFO - 2018-10-21 18:13:56 --> Email Class Initialized
INFO - 2018-10-21 18:13:56 --> Controller Class Initialized
DEBUG - 2018-10-21 18:13:56 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:13:56 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:13:56 --> Final output sent to browser
DEBUG - 2018-10-21 18:13:56 --> Total execution time: 0.5329
INFO - 2018-10-21 18:14:07 --> Config Class Initialized
INFO - 2018-10-21 18:14:07 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:14:07 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:14:07 --> Utf8 Class Initialized
INFO - 2018-10-21 18:14:07 --> URI Class Initialized
INFO - 2018-10-21 18:14:07 --> Router Class Initialized
INFO - 2018-10-21 18:14:07 --> Output Class Initialized
INFO - 2018-10-21 18:14:07 --> Security Class Initialized
DEBUG - 2018-10-21 18:14:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:14:07 --> Input Class Initialized
INFO - 2018-10-21 18:14:07 --> Language Class Initialized
INFO - 2018-10-21 18:14:07 --> Language Class Initialized
INFO - 2018-10-21 18:14:07 --> Config Class Initialized
INFO - 2018-10-21 18:14:07 --> Loader Class Initialized
INFO - 2018-10-21 18:14:07 --> Helper loaded: url_helper
INFO - 2018-10-21 18:14:07 --> Helper loaded: form_helper
INFO - 2018-10-21 18:14:07 --> Helper loaded: html_helper
INFO - 2018-10-21 18:14:07 --> Helper loaded: email_helper
INFO - 2018-10-21 18:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:14:08 --> Form Validation Class Initialized
INFO - 2018-10-21 18:14:08 --> Email Class Initialized
INFO - 2018-10-21 18:14:08 --> Controller Class Initialized
DEBUG - 2018-10-21 18:14:08 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:14:08 --> Config Class Initialized
INFO - 2018-10-21 18:14:08 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:14:08 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:14:08 --> Utf8 Class Initialized
INFO - 2018-10-21 18:14:08 --> URI Class Initialized
INFO - 2018-10-21 18:14:08 --> Router Class Initialized
INFO - 2018-10-21 18:14:08 --> Output Class Initialized
INFO - 2018-10-21 18:14:08 --> Security Class Initialized
DEBUG - 2018-10-21 18:14:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:14:08 --> Input Class Initialized
INFO - 2018-10-21 18:14:08 --> Language Class Initialized
INFO - 2018-10-21 18:14:08 --> Language Class Initialized
INFO - 2018-10-21 18:14:08 --> Config Class Initialized
INFO - 2018-10-21 18:14:08 --> Loader Class Initialized
INFO - 2018-10-21 18:14:08 --> Helper loaded: url_helper
INFO - 2018-10-21 18:14:08 --> Helper loaded: form_helper
INFO - 2018-10-21 18:14:08 --> Helper loaded: html_helper
INFO - 2018-10-21 18:14:08 --> Helper loaded: email_helper
INFO - 2018-10-21 18:14:08 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:14:08 --> Form Validation Class Initialized
INFO - 2018-10-21 18:14:08 --> Email Class Initialized
INFO - 2018-10-21 18:14:08 --> Controller Class Initialized
DEBUG - 2018-10-21 18:14:08 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:14:08 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:14:08 --> Final output sent to browser
DEBUG - 2018-10-21 18:14:08 --> Total execution time: 0.5244
INFO - 2018-10-21 18:14:15 --> Config Class Initialized
INFO - 2018-10-21 18:14:15 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:14:15 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:14:15 --> Utf8 Class Initialized
INFO - 2018-10-21 18:14:15 --> URI Class Initialized
INFO - 2018-10-21 18:14:15 --> Router Class Initialized
INFO - 2018-10-21 18:14:15 --> Output Class Initialized
INFO - 2018-10-21 18:14:15 --> Security Class Initialized
DEBUG - 2018-10-21 18:14:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:14:15 --> Input Class Initialized
INFO - 2018-10-21 18:14:15 --> Language Class Initialized
INFO - 2018-10-21 18:14:15 --> Language Class Initialized
INFO - 2018-10-21 18:14:15 --> Config Class Initialized
INFO - 2018-10-21 18:14:15 --> Loader Class Initialized
INFO - 2018-10-21 18:14:15 --> Helper loaded: url_helper
INFO - 2018-10-21 18:14:15 --> Helper loaded: form_helper
INFO - 2018-10-21 18:14:15 --> Helper loaded: html_helper
INFO - 2018-10-21 18:14:15 --> Helper loaded: email_helper
INFO - 2018-10-21 18:14:15 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:14:15 --> Form Validation Class Initialized
INFO - 2018-10-21 18:14:15 --> Email Class Initialized
INFO - 2018-10-21 18:14:15 --> Controller Class Initialized
DEBUG - 2018-10-21 18:14:16 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:14:16 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-21 18:14:16 --> Severity: 8192 --> idn_to_ascii(): INTL_IDNA_VARIANT_2003 is deprecated C:\wamp64\www\CI\system\libraries\Form_validation.php 1249
DEBUG - 2018-10-21 18:14:16 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:14:16 --> Final output sent to browser
DEBUG - 2018-10-21 18:14:16 --> Total execution time: 0.7156
INFO - 2018-10-21 18:15:16 --> Config Class Initialized
INFO - 2018-10-21 18:15:16 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:15:16 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:15:16 --> Utf8 Class Initialized
INFO - 2018-10-21 18:15:16 --> URI Class Initialized
INFO - 2018-10-21 18:15:16 --> Router Class Initialized
INFO - 2018-10-21 18:15:16 --> Output Class Initialized
INFO - 2018-10-21 18:15:16 --> Security Class Initialized
DEBUG - 2018-10-21 18:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:15:16 --> Input Class Initialized
INFO - 2018-10-21 18:15:16 --> Language Class Initialized
INFO - 2018-10-21 18:15:16 --> Language Class Initialized
INFO - 2018-10-21 18:15:16 --> Config Class Initialized
INFO - 2018-10-21 18:15:16 --> Loader Class Initialized
INFO - 2018-10-21 18:15:16 --> Helper loaded: url_helper
INFO - 2018-10-21 18:15:16 --> Helper loaded: form_helper
INFO - 2018-10-21 18:15:16 --> Helper loaded: html_helper
INFO - 2018-10-21 18:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:15:16 --> Form Validation Class Initialized
INFO - 2018-10-21 18:15:16 --> Email Class Initialized
INFO - 2018-10-21 18:15:16 --> Controller Class Initialized
DEBUG - 2018-10-21 18:15:16 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:15:17 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-21 18:15:17 --> Severity: 8192 --> idn_to_ascii(): INTL_IDNA_VARIANT_2003 is deprecated C:\wamp64\www\CI\system\libraries\Form_validation.php 1249
DEBUG - 2018-10-21 18:15:17 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:15:17 --> Final output sent to browser
DEBUG - 2018-10-21 18:15:17 --> Total execution time: 0.5497
INFO - 2018-10-21 18:15:27 --> Config Class Initialized
INFO - 2018-10-21 18:15:27 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:15:27 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:15:27 --> Utf8 Class Initialized
INFO - 2018-10-21 18:15:27 --> URI Class Initialized
INFO - 2018-10-21 18:15:27 --> Router Class Initialized
INFO - 2018-10-21 18:15:27 --> Output Class Initialized
INFO - 2018-10-21 18:15:27 --> Security Class Initialized
DEBUG - 2018-10-21 18:15:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:15:27 --> Input Class Initialized
INFO - 2018-10-21 18:15:27 --> Language Class Initialized
INFO - 2018-10-21 18:15:27 --> Language Class Initialized
INFO - 2018-10-21 18:15:27 --> Config Class Initialized
INFO - 2018-10-21 18:15:27 --> Loader Class Initialized
INFO - 2018-10-21 18:15:27 --> Helper loaded: url_helper
INFO - 2018-10-21 18:15:27 --> Helper loaded: form_helper
INFO - 2018-10-21 18:15:27 --> Helper loaded: html_helper
INFO - 2018-10-21 18:15:27 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:15:27 --> Form Validation Class Initialized
INFO - 2018-10-21 18:15:28 --> Controller Class Initialized
DEBUG - 2018-10-21 18:15:28 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:15:28 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-21 18:15:28 --> Severity: 8192 --> idn_to_ascii(): INTL_IDNA_VARIANT_2003 is deprecated C:\wamp64\www\CI\system\libraries\Form_validation.php 1249
DEBUG - 2018-10-21 18:15:28 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:15:28 --> Final output sent to browser
DEBUG - 2018-10-21 18:15:28 --> Total execution time: 0.4919
INFO - 2018-10-21 18:15:36 --> Config Class Initialized
INFO - 2018-10-21 18:15:36 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:15:36 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:15:36 --> Utf8 Class Initialized
INFO - 2018-10-21 18:15:36 --> URI Class Initialized
INFO - 2018-10-21 18:15:36 --> Router Class Initialized
INFO - 2018-10-21 18:15:36 --> Output Class Initialized
INFO - 2018-10-21 18:15:36 --> Security Class Initialized
DEBUG - 2018-10-21 18:15:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:15:37 --> Input Class Initialized
INFO - 2018-10-21 18:15:37 --> Language Class Initialized
INFO - 2018-10-21 18:15:37 --> Language Class Initialized
INFO - 2018-10-21 18:15:37 --> Config Class Initialized
INFO - 2018-10-21 18:15:37 --> Loader Class Initialized
INFO - 2018-10-21 18:15:37 --> Helper loaded: url_helper
INFO - 2018-10-21 18:15:37 --> Helper loaded: form_helper
INFO - 2018-10-21 18:15:37 --> Helper loaded: html_helper
INFO - 2018-10-21 18:15:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:15:37 --> Form Validation Class Initialized
INFO - 2018-10-21 18:15:37 --> Controller Class Initialized
DEBUG - 2018-10-21 18:15:37 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:15:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2018-10-21 18:15:37 --> Severity: 8192 --> idn_to_ascii(): INTL_IDNA_VARIANT_2003 is deprecated C:\wamp64\www\CI\system\libraries\Form_validation.php 1249
DEBUG - 2018-10-21 18:15:37 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:15:37 --> Final output sent to browser
DEBUG - 2018-10-21 18:15:37 --> Total execution time: 0.7313
INFO - 2018-10-21 18:17:35 --> Config Class Initialized
INFO - 2018-10-21 18:17:35 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:17:35 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:17:35 --> Utf8 Class Initialized
INFO - 2018-10-21 18:17:35 --> URI Class Initialized
INFO - 2018-10-21 18:17:35 --> Router Class Initialized
INFO - 2018-10-21 18:17:35 --> Output Class Initialized
INFO - 2018-10-21 18:17:35 --> Security Class Initialized
DEBUG - 2018-10-21 18:17:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:17:35 --> Input Class Initialized
INFO - 2018-10-21 18:17:35 --> Language Class Initialized
INFO - 2018-10-21 18:17:35 --> Language Class Initialized
INFO - 2018-10-21 18:17:35 --> Config Class Initialized
INFO - 2018-10-21 18:17:35 --> Loader Class Initialized
INFO - 2018-10-21 18:17:35 --> Helper loaded: url_helper
INFO - 2018-10-21 18:17:35 --> Helper loaded: form_helper
INFO - 2018-10-21 18:17:35 --> Helper loaded: html_helper
INFO - 2018-10-21 18:17:36 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:17:36 --> Form Validation Class Initialized
INFO - 2018-10-21 18:17:36 --> Controller Class Initialized
DEBUG - 2018-10-21 18:17:36 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:17:36 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:17:36 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:17:36 --> Final output sent to browser
DEBUG - 2018-10-21 18:17:36 --> Total execution time: 0.6175
INFO - 2018-10-21 18:18:08 --> Config Class Initialized
INFO - 2018-10-21 18:18:08 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:18:08 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:18:08 --> Utf8 Class Initialized
INFO - 2018-10-21 18:18:08 --> URI Class Initialized
INFO - 2018-10-21 18:18:08 --> Router Class Initialized
INFO - 2018-10-21 18:18:08 --> Output Class Initialized
INFO - 2018-10-21 18:18:08 --> Security Class Initialized
DEBUG - 2018-10-21 18:18:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:18:08 --> Input Class Initialized
INFO - 2018-10-21 18:18:08 --> Language Class Initialized
INFO - 2018-10-21 18:18:08 --> Language Class Initialized
INFO - 2018-10-21 18:18:08 --> Config Class Initialized
INFO - 2018-10-21 18:18:08 --> Loader Class Initialized
INFO - 2018-10-21 18:18:08 --> Helper loaded: url_helper
INFO - 2018-10-21 18:18:08 --> Helper loaded: form_helper
INFO - 2018-10-21 18:18:08 --> Helper loaded: html_helper
INFO - 2018-10-21 18:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:18:09 --> Form Validation Class Initialized
INFO - 2018-10-21 18:18:09 --> Controller Class Initialized
DEBUG - 2018-10-21 18:18:09 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:18:09 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:18:09 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:18:09 --> Final output sent to browser
DEBUG - 2018-10-21 18:18:09 --> Total execution time: 0.8271
INFO - 2018-10-21 18:18:17 --> Config Class Initialized
INFO - 2018-10-21 18:18:17 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:18:17 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:18:17 --> Utf8 Class Initialized
INFO - 2018-10-21 18:18:17 --> URI Class Initialized
INFO - 2018-10-21 18:18:17 --> Router Class Initialized
INFO - 2018-10-21 18:18:17 --> Output Class Initialized
INFO - 2018-10-21 18:18:17 --> Security Class Initialized
DEBUG - 2018-10-21 18:18:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:18:17 --> Input Class Initialized
INFO - 2018-10-21 18:18:17 --> Language Class Initialized
INFO - 2018-10-21 18:18:17 --> Language Class Initialized
INFO - 2018-10-21 18:18:17 --> Config Class Initialized
INFO - 2018-10-21 18:18:17 --> Loader Class Initialized
INFO - 2018-10-21 18:18:17 --> Helper loaded: url_helper
INFO - 2018-10-21 18:18:17 --> Helper loaded: form_helper
INFO - 2018-10-21 18:18:17 --> Helper loaded: html_helper
INFO - 2018-10-21 18:18:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:18:17 --> Form Validation Class Initialized
INFO - 2018-10-21 18:18:17 --> Controller Class Initialized
DEBUG - 2018-10-21 18:18:17 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:18:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:18:17 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:18:17 --> Final output sent to browser
DEBUG - 2018-10-21 18:18:17 --> Total execution time: 0.5523
INFO - 2018-10-21 18:19:24 --> Config Class Initialized
INFO - 2018-10-21 18:19:24 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:19:24 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:19:24 --> Utf8 Class Initialized
INFO - 2018-10-21 18:19:24 --> URI Class Initialized
INFO - 2018-10-21 18:19:24 --> Router Class Initialized
INFO - 2018-10-21 18:19:24 --> Output Class Initialized
INFO - 2018-10-21 18:19:24 --> Security Class Initialized
DEBUG - 2018-10-21 18:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:19:24 --> Input Class Initialized
INFO - 2018-10-21 18:19:24 --> Language Class Initialized
INFO - 2018-10-21 18:19:24 --> Language Class Initialized
INFO - 2018-10-21 18:19:24 --> Config Class Initialized
INFO - 2018-10-21 18:19:24 --> Loader Class Initialized
INFO - 2018-10-21 18:19:24 --> Helper loaded: url_helper
INFO - 2018-10-21 18:19:24 --> Helper loaded: form_helper
INFO - 2018-10-21 18:19:24 --> Helper loaded: html_helper
INFO - 2018-10-21 18:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:19:24 --> Form Validation Class Initialized
INFO - 2018-10-21 18:19:24 --> Controller Class Initialized
DEBUG - 2018-10-21 18:19:24 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:19:24 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:19:24 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:19:24 --> Final output sent to browser
DEBUG - 2018-10-21 18:19:24 --> Total execution time: 0.7782
INFO - 2018-10-21 18:19:29 --> Config Class Initialized
INFO - 2018-10-21 18:19:29 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:19:29 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:19:29 --> Utf8 Class Initialized
INFO - 2018-10-21 18:19:29 --> URI Class Initialized
INFO - 2018-10-21 18:19:29 --> Router Class Initialized
INFO - 2018-10-21 18:19:29 --> Output Class Initialized
INFO - 2018-10-21 18:19:29 --> Security Class Initialized
DEBUG - 2018-10-21 18:19:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:19:29 --> Input Class Initialized
INFO - 2018-10-21 18:19:29 --> Language Class Initialized
INFO - 2018-10-21 18:19:29 --> Language Class Initialized
INFO - 2018-10-21 18:19:29 --> Config Class Initialized
INFO - 2018-10-21 18:19:29 --> Loader Class Initialized
INFO - 2018-10-21 18:19:29 --> Helper loaded: url_helper
INFO - 2018-10-21 18:19:29 --> Helper loaded: form_helper
INFO - 2018-10-21 18:19:29 --> Helper loaded: html_helper
INFO - 2018-10-21 18:19:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:19:29 --> Form Validation Class Initialized
INFO - 2018-10-21 18:19:29 --> Controller Class Initialized
DEBUG - 2018-10-21 18:19:29 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:19:29 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:19:29 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:19:29 --> Final output sent to browser
DEBUG - 2018-10-21 18:19:29 --> Total execution time: 0.4782
INFO - 2018-10-21 18:20:32 --> Config Class Initialized
INFO - 2018-10-21 18:20:32 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:20:32 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:20:32 --> Utf8 Class Initialized
INFO - 2018-10-21 18:20:32 --> URI Class Initialized
INFO - 2018-10-21 18:20:32 --> Router Class Initialized
INFO - 2018-10-21 18:20:32 --> Output Class Initialized
INFO - 2018-10-21 18:20:32 --> Security Class Initialized
DEBUG - 2018-10-21 18:20:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:20:32 --> Input Class Initialized
INFO - 2018-10-21 18:20:32 --> Language Class Initialized
INFO - 2018-10-21 18:20:32 --> Language Class Initialized
INFO - 2018-10-21 18:20:32 --> Config Class Initialized
INFO - 2018-10-21 18:20:32 --> Loader Class Initialized
INFO - 2018-10-21 18:20:32 --> Helper loaded: url_helper
INFO - 2018-10-21 18:20:32 --> Helper loaded: form_helper
INFO - 2018-10-21 18:20:32 --> Helper loaded: html_helper
INFO - 2018-10-21 18:20:32 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:20:32 --> Form Validation Class Initialized
INFO - 2018-10-21 18:20:32 --> Controller Class Initialized
DEBUG - 2018-10-21 18:20:32 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:20:32 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:20:32 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:20:32 --> Final output sent to browser
DEBUG - 2018-10-21 18:20:32 --> Total execution time: 0.5602
INFO - 2018-10-21 18:21:19 --> Config Class Initialized
INFO - 2018-10-21 18:21:19 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:21:19 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:21:19 --> Utf8 Class Initialized
INFO - 2018-10-21 18:21:19 --> URI Class Initialized
INFO - 2018-10-21 18:21:19 --> Router Class Initialized
INFO - 2018-10-21 18:21:19 --> Output Class Initialized
INFO - 2018-10-21 18:21:19 --> Security Class Initialized
DEBUG - 2018-10-21 18:21:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:21:19 --> Input Class Initialized
INFO - 2018-10-21 18:21:19 --> Language Class Initialized
INFO - 2018-10-21 18:21:19 --> Language Class Initialized
INFO - 2018-10-21 18:21:19 --> Config Class Initialized
INFO - 2018-10-21 18:21:20 --> Loader Class Initialized
INFO - 2018-10-21 18:21:20 --> Helper loaded: url_helper
INFO - 2018-10-21 18:21:20 --> Helper loaded: form_helper
INFO - 2018-10-21 18:21:20 --> Helper loaded: html_helper
INFO - 2018-10-21 18:21:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:21:20 --> Form Validation Class Initialized
INFO - 2018-10-21 18:21:20 --> Controller Class Initialized
DEBUG - 2018-10-21 18:21:20 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:21:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:21:20 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:21:20 --> Final output sent to browser
DEBUG - 2018-10-21 18:21:20 --> Total execution time: 0.6417
INFO - 2018-10-21 18:21:51 --> Config Class Initialized
INFO - 2018-10-21 18:21:51 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:21:51 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:21:51 --> Utf8 Class Initialized
INFO - 2018-10-21 18:21:51 --> URI Class Initialized
INFO - 2018-10-21 18:21:51 --> Router Class Initialized
INFO - 2018-10-21 18:21:51 --> Output Class Initialized
INFO - 2018-10-21 18:21:51 --> Security Class Initialized
DEBUG - 2018-10-21 18:21:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:21:51 --> Input Class Initialized
INFO - 2018-10-21 18:21:51 --> Language Class Initialized
INFO - 2018-10-21 18:21:51 --> Language Class Initialized
INFO - 2018-10-21 18:21:51 --> Config Class Initialized
INFO - 2018-10-21 18:21:51 --> Loader Class Initialized
INFO - 2018-10-21 18:21:51 --> Helper loaded: url_helper
INFO - 2018-10-21 18:21:51 --> Helper loaded: form_helper
INFO - 2018-10-21 18:21:51 --> Helper loaded: html_helper
INFO - 2018-10-21 18:21:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:21:52 --> Form Validation Class Initialized
INFO - 2018-10-21 18:21:52 --> Controller Class Initialized
ERROR - 2018-10-21 18:21:52 --> 404 Page Not Found: ../modules/products/controllers/Products/display_result
INFO - 2018-10-21 18:24:07 --> Config Class Initialized
INFO - 2018-10-21 18:24:07 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:24:07 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:24:07 --> Utf8 Class Initialized
INFO - 2018-10-21 18:24:07 --> URI Class Initialized
INFO - 2018-10-21 18:24:07 --> Router Class Initialized
INFO - 2018-10-21 18:24:07 --> Output Class Initialized
INFO - 2018-10-21 18:24:07 --> Security Class Initialized
DEBUG - 2018-10-21 18:24:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:24:07 --> Input Class Initialized
INFO - 2018-10-21 18:24:07 --> Language Class Initialized
INFO - 2018-10-21 18:24:07 --> Language Class Initialized
INFO - 2018-10-21 18:24:07 --> Config Class Initialized
INFO - 2018-10-21 18:24:07 --> Loader Class Initialized
INFO - 2018-10-21 18:24:07 --> Helper loaded: url_helper
INFO - 2018-10-21 18:24:07 --> Helper loaded: form_helper
INFO - 2018-10-21 18:24:07 --> Helper loaded: html_helper
INFO - 2018-10-21 18:24:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:24:07 --> Form Validation Class Initialized
INFO - 2018-10-21 18:24:07 --> Controller Class Initialized
DEBUG - 2018-10-21 18:24:07 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:24:07 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:24:07 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:24:07 --> Final output sent to browser
DEBUG - 2018-10-21 18:24:07 --> Total execution time: 0.7199
INFO - 2018-10-21 18:24:16 --> Config Class Initialized
INFO - 2018-10-21 18:24:16 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:24:16 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:24:17 --> Utf8 Class Initialized
INFO - 2018-10-21 18:24:17 --> URI Class Initialized
INFO - 2018-10-21 18:24:17 --> Router Class Initialized
INFO - 2018-10-21 18:24:17 --> Output Class Initialized
INFO - 2018-10-21 18:24:17 --> Security Class Initialized
DEBUG - 2018-10-21 18:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:24:17 --> Input Class Initialized
INFO - 2018-10-21 18:24:17 --> Language Class Initialized
INFO - 2018-10-21 18:24:17 --> Language Class Initialized
INFO - 2018-10-21 18:24:17 --> Config Class Initialized
INFO - 2018-10-21 18:24:17 --> Loader Class Initialized
INFO - 2018-10-21 18:24:17 --> Helper loaded: url_helper
INFO - 2018-10-21 18:24:17 --> Helper loaded: form_helper
INFO - 2018-10-21 18:24:17 --> Helper loaded: html_helper
INFO - 2018-10-21 18:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:24:17 --> Form Validation Class Initialized
INFO - 2018-10-21 18:24:17 --> Controller Class Initialized
DEBUG - 2018-10-21 18:24:17 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:24:17 --> Config Class Initialized
INFO - 2018-10-21 18:24:17 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:24:17 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:24:17 --> Utf8 Class Initialized
INFO - 2018-10-21 18:24:17 --> URI Class Initialized
INFO - 2018-10-21 18:24:17 --> Router Class Initialized
INFO - 2018-10-21 18:24:17 --> Output Class Initialized
INFO - 2018-10-21 18:24:17 --> Security Class Initialized
DEBUG - 2018-10-21 18:24:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:24:17 --> Input Class Initialized
INFO - 2018-10-21 18:24:17 --> Language Class Initialized
INFO - 2018-10-21 18:24:17 --> Language Class Initialized
INFO - 2018-10-21 18:24:17 --> Config Class Initialized
INFO - 2018-10-21 18:24:17 --> Loader Class Initialized
INFO - 2018-10-21 18:24:17 --> Helper loaded: url_helper
INFO - 2018-10-21 18:24:17 --> Helper loaded: form_helper
INFO - 2018-10-21 18:24:17 --> Helper loaded: html_helper
INFO - 2018-10-21 18:24:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:24:17 --> Form Validation Class Initialized
INFO - 2018-10-21 18:24:17 --> Controller Class Initialized
DEBUG - 2018-10-21 18:24:18 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:24:18 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:24:18 --> Final output sent to browser
DEBUG - 2018-10-21 18:24:18 --> Total execution time: 0.4902
INFO - 2018-10-21 18:26:42 --> Config Class Initialized
INFO - 2018-10-21 18:26:42 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:26:42 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:26:42 --> Utf8 Class Initialized
INFO - 2018-10-21 18:26:42 --> URI Class Initialized
INFO - 2018-10-21 18:26:42 --> Router Class Initialized
INFO - 2018-10-21 18:26:42 --> Output Class Initialized
INFO - 2018-10-21 18:26:42 --> Security Class Initialized
DEBUG - 2018-10-21 18:26:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:26:42 --> Input Class Initialized
INFO - 2018-10-21 18:26:42 --> Language Class Initialized
INFO - 2018-10-21 18:26:42 --> Language Class Initialized
INFO - 2018-10-21 18:26:42 --> Config Class Initialized
INFO - 2018-10-21 18:26:42 --> Loader Class Initialized
INFO - 2018-10-21 18:26:42 --> Helper loaded: url_helper
INFO - 2018-10-21 18:26:42 --> Helper loaded: form_helper
INFO - 2018-10-21 18:26:42 --> Helper loaded: html_helper
INFO - 2018-10-21 18:26:42 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:26:42 --> Form Validation Class Initialized
INFO - 2018-10-21 18:26:43 --> Controller Class Initialized
DEBUG - 2018-10-21 18:26:43 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:26:43 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:26:43 --> Final output sent to browser
DEBUG - 2018-10-21 18:26:43 --> Total execution time: 1.0034
INFO - 2018-10-21 18:26:53 --> Config Class Initialized
INFO - 2018-10-21 18:26:53 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:26:53 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:26:53 --> Utf8 Class Initialized
INFO - 2018-10-21 18:26:53 --> URI Class Initialized
INFO - 2018-10-21 18:26:53 --> Router Class Initialized
INFO - 2018-10-21 18:26:54 --> Output Class Initialized
INFO - 2018-10-21 18:26:54 --> Security Class Initialized
DEBUG - 2018-10-21 18:26:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:26:54 --> Input Class Initialized
INFO - 2018-10-21 18:26:54 --> Language Class Initialized
INFO - 2018-10-21 18:26:54 --> Language Class Initialized
INFO - 2018-10-21 18:26:54 --> Config Class Initialized
INFO - 2018-10-21 18:26:54 --> Loader Class Initialized
INFO - 2018-10-21 18:26:54 --> Helper loaded: url_helper
INFO - 2018-10-21 18:26:54 --> Helper loaded: form_helper
INFO - 2018-10-21 18:26:54 --> Helper loaded: html_helper
INFO - 2018-10-21 18:26:54 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:26:54 --> Form Validation Class Initialized
INFO - 2018-10-21 18:26:54 --> Controller Class Initialized
DEBUG - 2018-10-21 18:26:54 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:26:54 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:26:54 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:26:54 --> Final output sent to browser
DEBUG - 2018-10-21 18:26:54 --> Total execution time: 0.6747
INFO - 2018-10-21 18:28:04 --> Config Class Initialized
INFO - 2018-10-21 18:28:04 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:28:04 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:28:04 --> Utf8 Class Initialized
INFO - 2018-10-21 18:28:04 --> URI Class Initialized
INFO - 2018-10-21 18:28:04 --> Router Class Initialized
INFO - 2018-10-21 18:28:04 --> Output Class Initialized
INFO - 2018-10-21 18:28:04 --> Security Class Initialized
DEBUG - 2018-10-21 18:28:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:28:04 --> Input Class Initialized
INFO - 2018-10-21 18:28:04 --> Language Class Initialized
INFO - 2018-10-21 18:28:04 --> Language Class Initialized
INFO - 2018-10-21 18:28:04 --> Config Class Initialized
INFO - 2018-10-21 18:28:04 --> Loader Class Initialized
INFO - 2018-10-21 18:28:04 --> Helper loaded: url_helper
INFO - 2018-10-21 18:28:04 --> Helper loaded: form_helper
INFO - 2018-10-21 18:28:04 --> Helper loaded: html_helper
INFO - 2018-10-21 18:28:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:28:04 --> Form Validation Class Initialized
INFO - 2018-10-21 18:28:04 --> Email Class Initialized
INFO - 2018-10-21 18:28:04 --> Controller Class Initialized
DEBUG - 2018-10-21 18:28:04 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:28:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:28:04 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:28:04 --> Final output sent to browser
DEBUG - 2018-10-21 18:28:04 --> Total execution time: 0.5000
INFO - 2018-10-21 18:28:17 --> Config Class Initialized
INFO - 2018-10-21 18:28:17 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:28:17 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:28:17 --> Utf8 Class Initialized
INFO - 2018-10-21 18:28:17 --> URI Class Initialized
INFO - 2018-10-21 18:28:17 --> Router Class Initialized
INFO - 2018-10-21 18:28:17 --> Output Class Initialized
INFO - 2018-10-21 18:28:17 --> Security Class Initialized
DEBUG - 2018-10-21 18:28:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:28:17 --> Input Class Initialized
INFO - 2018-10-21 18:28:17 --> Language Class Initialized
INFO - 2018-10-21 18:28:17 --> Language Class Initialized
INFO - 2018-10-21 18:28:17 --> Config Class Initialized
INFO - 2018-10-21 18:28:17 --> Loader Class Initialized
INFO - 2018-10-21 18:28:17 --> Helper loaded: url_helper
INFO - 2018-10-21 18:28:17 --> Helper loaded: form_helper
INFO - 2018-10-21 18:28:17 --> Helper loaded: html_helper
INFO - 2018-10-21 18:28:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:28:17 --> Form Validation Class Initialized
INFO - 2018-10-21 18:28:17 --> Email Class Initialized
INFO - 2018-10-21 18:28:17 --> Controller Class Initialized
DEBUG - 2018-10-21 18:28:17 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:28:17 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:28:17 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:28:17 --> Final output sent to browser
DEBUG - 2018-10-21 18:28:17 --> Total execution time: 0.5222
INFO - 2018-10-21 18:28:20 --> Config Class Initialized
INFO - 2018-10-21 18:28:20 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:28:20 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:28:20 --> Utf8 Class Initialized
INFO - 2018-10-21 18:28:20 --> URI Class Initialized
INFO - 2018-10-21 18:28:20 --> Router Class Initialized
INFO - 2018-10-21 18:28:20 --> Output Class Initialized
INFO - 2018-10-21 18:28:20 --> Security Class Initialized
DEBUG - 2018-10-21 18:28:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:28:20 --> Input Class Initialized
INFO - 2018-10-21 18:28:20 --> Language Class Initialized
INFO - 2018-10-21 18:28:20 --> Language Class Initialized
INFO - 2018-10-21 18:28:20 --> Config Class Initialized
INFO - 2018-10-21 18:28:20 --> Loader Class Initialized
INFO - 2018-10-21 18:28:20 --> Helper loaded: url_helper
INFO - 2018-10-21 18:28:20 --> Helper loaded: form_helper
INFO - 2018-10-21 18:28:20 --> Helper loaded: html_helper
INFO - 2018-10-21 18:28:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:28:20 --> Form Validation Class Initialized
INFO - 2018-10-21 18:28:20 --> Email Class Initialized
INFO - 2018-10-21 18:28:20 --> Controller Class Initialized
DEBUG - 2018-10-21 18:28:20 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:28:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:28:20 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:28:20 --> Final output sent to browser
DEBUG - 2018-10-21 18:28:20 --> Total execution time: 0.5708
INFO - 2018-10-21 18:28:26 --> Config Class Initialized
INFO - 2018-10-21 18:28:26 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:28:26 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:28:26 --> Utf8 Class Initialized
INFO - 2018-10-21 18:28:26 --> URI Class Initialized
INFO - 2018-10-21 18:28:26 --> Router Class Initialized
INFO - 2018-10-21 18:28:26 --> Output Class Initialized
INFO - 2018-10-21 18:28:26 --> Security Class Initialized
DEBUG - 2018-10-21 18:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:28:26 --> Input Class Initialized
INFO - 2018-10-21 18:28:26 --> Language Class Initialized
INFO - 2018-10-21 18:28:26 --> Language Class Initialized
INFO - 2018-10-21 18:28:26 --> Config Class Initialized
INFO - 2018-10-21 18:28:26 --> Loader Class Initialized
INFO - 2018-10-21 18:28:26 --> Helper loaded: url_helper
INFO - 2018-10-21 18:28:26 --> Helper loaded: form_helper
INFO - 2018-10-21 18:28:26 --> Helper loaded: html_helper
INFO - 2018-10-21 18:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:28:26 --> Form Validation Class Initialized
INFO - 2018-10-21 18:28:26 --> Email Class Initialized
INFO - 2018-10-21 18:28:26 --> Controller Class Initialized
DEBUG - 2018-10-21 18:28:26 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:28:26 --> Config Class Initialized
INFO - 2018-10-21 18:28:26 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:28:26 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:28:26 --> Utf8 Class Initialized
INFO - 2018-10-21 18:28:26 --> URI Class Initialized
INFO - 2018-10-21 18:28:26 --> Router Class Initialized
INFO - 2018-10-21 18:28:26 --> Output Class Initialized
INFO - 2018-10-21 18:28:26 --> Security Class Initialized
DEBUG - 2018-10-21 18:28:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:28:26 --> Input Class Initialized
INFO - 2018-10-21 18:28:26 --> Language Class Initialized
INFO - 2018-10-21 18:28:26 --> Language Class Initialized
INFO - 2018-10-21 18:28:26 --> Config Class Initialized
INFO - 2018-10-21 18:28:26 --> Loader Class Initialized
INFO - 2018-10-21 18:28:26 --> Helper loaded: url_helper
INFO - 2018-10-21 18:28:26 --> Helper loaded: form_helper
INFO - 2018-10-21 18:28:26 --> Helper loaded: html_helper
INFO - 2018-10-21 18:28:26 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:28:26 --> Form Validation Class Initialized
INFO - 2018-10-21 18:28:27 --> Email Class Initialized
INFO - 2018-10-21 18:28:27 --> Controller Class Initialized
DEBUG - 2018-10-21 18:28:27 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:28:27 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:28:27 --> Final output sent to browser
DEBUG - 2018-10-21 18:28:27 --> Total execution time: 0.5280
INFO - 2018-10-21 18:28:41 --> Config Class Initialized
INFO - 2018-10-21 18:28:41 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:28:41 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:28:41 --> Utf8 Class Initialized
INFO - 2018-10-21 18:28:41 --> URI Class Initialized
INFO - 2018-10-21 18:28:41 --> Router Class Initialized
INFO - 2018-10-21 18:28:41 --> Output Class Initialized
INFO - 2018-10-21 18:28:41 --> Security Class Initialized
DEBUG - 2018-10-21 18:28:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:28:41 --> Input Class Initialized
INFO - 2018-10-21 18:28:41 --> Language Class Initialized
INFO - 2018-10-21 18:28:41 --> Language Class Initialized
INFO - 2018-10-21 18:28:41 --> Config Class Initialized
INFO - 2018-10-21 18:28:41 --> Loader Class Initialized
INFO - 2018-10-21 18:28:41 --> Helper loaded: url_helper
INFO - 2018-10-21 18:28:41 --> Helper loaded: form_helper
INFO - 2018-10-21 18:28:41 --> Helper loaded: html_helper
INFO - 2018-10-21 18:28:41 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:28:41 --> Form Validation Class Initialized
INFO - 2018-10-21 18:28:41 --> Email Class Initialized
INFO - 2018-10-21 18:28:41 --> Controller Class Initialized
DEBUG - 2018-10-21 18:28:41 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:28:41 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:28:41 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:28:41 --> Final output sent to browser
DEBUG - 2018-10-21 18:28:41 --> Total execution time: 0.6260
INFO - 2018-10-21 18:28:44 --> Config Class Initialized
INFO - 2018-10-21 18:28:44 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:28:44 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:28:44 --> Utf8 Class Initialized
INFO - 2018-10-21 18:28:44 --> URI Class Initialized
INFO - 2018-10-21 18:28:44 --> Router Class Initialized
INFO - 2018-10-21 18:28:44 --> Output Class Initialized
INFO - 2018-10-21 18:28:44 --> Security Class Initialized
DEBUG - 2018-10-21 18:28:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:28:44 --> Input Class Initialized
INFO - 2018-10-21 18:28:44 --> Language Class Initialized
INFO - 2018-10-21 18:28:44 --> Language Class Initialized
INFO - 2018-10-21 18:28:44 --> Config Class Initialized
INFO - 2018-10-21 18:28:44 --> Loader Class Initialized
INFO - 2018-10-21 18:28:44 --> Helper loaded: url_helper
INFO - 2018-10-21 18:28:44 --> Helper loaded: form_helper
INFO - 2018-10-21 18:28:44 --> Helper loaded: html_helper
INFO - 2018-10-21 18:28:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:28:44 --> Form Validation Class Initialized
INFO - 2018-10-21 18:28:44 --> Email Class Initialized
INFO - 2018-10-21 18:28:44 --> Controller Class Initialized
DEBUG - 2018-10-21 18:28:44 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:28:44 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:28:44 --> Final output sent to browser
DEBUG - 2018-10-21 18:28:44 --> Total execution time: 0.5949
INFO - 2018-10-21 18:28:46 --> Config Class Initialized
INFO - 2018-10-21 18:28:46 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:28:46 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:28:46 --> Utf8 Class Initialized
INFO - 2018-10-21 18:28:46 --> URI Class Initialized
INFO - 2018-10-21 18:28:46 --> Router Class Initialized
INFO - 2018-10-21 18:28:46 --> Output Class Initialized
INFO - 2018-10-21 18:28:46 --> Security Class Initialized
DEBUG - 2018-10-21 18:28:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:28:46 --> Input Class Initialized
INFO - 2018-10-21 18:28:46 --> Language Class Initialized
INFO - 2018-10-21 18:28:46 --> Language Class Initialized
INFO - 2018-10-21 18:28:46 --> Config Class Initialized
INFO - 2018-10-21 18:28:46 --> Loader Class Initialized
INFO - 2018-10-21 18:28:46 --> Helper loaded: url_helper
INFO - 2018-10-21 18:28:46 --> Helper loaded: form_helper
INFO - 2018-10-21 18:28:46 --> Helper loaded: html_helper
INFO - 2018-10-21 18:28:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:28:46 --> Form Validation Class Initialized
INFO - 2018-10-21 18:28:46 --> Email Class Initialized
INFO - 2018-10-21 18:28:46 --> Controller Class Initialized
DEBUG - 2018-10-21 18:28:47 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:28:47 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:28:47 --> Final output sent to browser
DEBUG - 2018-10-21 18:28:47 --> Total execution time: 0.5964
INFO - 2018-10-21 18:28:48 --> Config Class Initialized
INFO - 2018-10-21 18:28:48 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:28:48 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:28:48 --> Utf8 Class Initialized
INFO - 2018-10-21 18:28:48 --> URI Class Initialized
INFO - 2018-10-21 18:28:48 --> Router Class Initialized
INFO - 2018-10-21 18:28:48 --> Output Class Initialized
INFO - 2018-10-21 18:28:48 --> Security Class Initialized
DEBUG - 2018-10-21 18:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:28:48 --> Input Class Initialized
INFO - 2018-10-21 18:28:48 --> Language Class Initialized
INFO - 2018-10-21 18:28:48 --> Language Class Initialized
INFO - 2018-10-21 18:28:48 --> Config Class Initialized
INFO - 2018-10-21 18:28:48 --> Loader Class Initialized
INFO - 2018-10-21 18:28:48 --> Helper loaded: url_helper
INFO - 2018-10-21 18:28:48 --> Helper loaded: form_helper
INFO - 2018-10-21 18:28:48 --> Helper loaded: html_helper
INFO - 2018-10-21 18:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:28:49 --> Form Validation Class Initialized
INFO - 2018-10-21 18:28:49 --> Email Class Initialized
INFO - 2018-10-21 18:28:49 --> Controller Class Initialized
DEBUG - 2018-10-21 18:28:49 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:28:49 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:28:49 --> Final output sent to browser
DEBUG - 2018-10-21 18:28:49 --> Total execution time: 0.6140
INFO - 2018-10-21 18:28:53 --> Config Class Initialized
INFO - 2018-10-21 18:28:53 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:28:53 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:28:53 --> Utf8 Class Initialized
INFO - 2018-10-21 18:28:53 --> URI Class Initialized
INFO - 2018-10-21 18:28:53 --> Router Class Initialized
INFO - 2018-10-21 18:28:53 --> Output Class Initialized
INFO - 2018-10-21 18:28:53 --> Security Class Initialized
DEBUG - 2018-10-21 18:28:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:28:53 --> Input Class Initialized
INFO - 2018-10-21 18:28:53 --> Language Class Initialized
INFO - 2018-10-21 18:28:53 --> Language Class Initialized
INFO - 2018-10-21 18:28:53 --> Config Class Initialized
INFO - 2018-10-21 18:28:53 --> Loader Class Initialized
INFO - 2018-10-21 18:28:53 --> Helper loaded: url_helper
INFO - 2018-10-21 18:28:53 --> Helper loaded: form_helper
INFO - 2018-10-21 18:28:53 --> Helper loaded: html_helper
INFO - 2018-10-21 18:28:53 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:28:53 --> Form Validation Class Initialized
INFO - 2018-10-21 18:28:53 --> Email Class Initialized
INFO - 2018-10-21 18:28:53 --> Controller Class Initialized
DEBUG - 2018-10-21 18:28:53 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:28:53 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:28:53 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:28:53 --> Final output sent to browser
DEBUG - 2018-10-21 18:28:53 --> Total execution time: 0.5347
INFO - 2018-10-21 18:28:57 --> Config Class Initialized
INFO - 2018-10-21 18:28:57 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:28:57 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:28:57 --> Utf8 Class Initialized
INFO - 2018-10-21 18:28:57 --> URI Class Initialized
INFO - 2018-10-21 18:28:57 --> Router Class Initialized
INFO - 2018-10-21 18:28:57 --> Output Class Initialized
INFO - 2018-10-21 18:28:57 --> Security Class Initialized
DEBUG - 2018-10-21 18:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:28:57 --> Input Class Initialized
INFO - 2018-10-21 18:28:57 --> Language Class Initialized
INFO - 2018-10-21 18:28:57 --> Language Class Initialized
INFO - 2018-10-21 18:28:57 --> Config Class Initialized
INFO - 2018-10-21 18:28:57 --> Loader Class Initialized
INFO - 2018-10-21 18:28:57 --> Helper loaded: url_helper
INFO - 2018-10-21 18:28:57 --> Helper loaded: form_helper
INFO - 2018-10-21 18:28:57 --> Helper loaded: html_helper
INFO - 2018-10-21 18:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:28:57 --> Form Validation Class Initialized
INFO - 2018-10-21 18:28:57 --> Email Class Initialized
INFO - 2018-10-21 18:28:57 --> Controller Class Initialized
DEBUG - 2018-10-21 18:28:57 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:28:57 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:28:57 --> Final output sent to browser
DEBUG - 2018-10-21 18:28:57 --> Total execution time: 0.5248
INFO - 2018-10-21 18:29:27 --> Config Class Initialized
INFO - 2018-10-21 18:29:27 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:29:27 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:29:27 --> Utf8 Class Initialized
INFO - 2018-10-21 18:29:27 --> URI Class Initialized
INFO - 2018-10-21 18:29:27 --> Router Class Initialized
INFO - 2018-10-21 18:29:27 --> Output Class Initialized
INFO - 2018-10-21 18:29:27 --> Security Class Initialized
DEBUG - 2018-10-21 18:29:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:29:27 --> Input Class Initialized
INFO - 2018-10-21 18:29:27 --> Language Class Initialized
ERROR - 2018-10-21 18:29:27 --> Severity: Compile Error --> Cannot use isset() on the result of an expression (you can use "null !== expression" instead) C:\wamp64\www\CI\application\modules\Products\controllers\Products.php 7
INFO - 2018-10-21 18:30:13 --> Config Class Initialized
INFO - 2018-10-21 18:30:13 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:30:13 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:30:13 --> Utf8 Class Initialized
INFO - 2018-10-21 18:30:13 --> URI Class Initialized
INFO - 2018-10-21 18:30:13 --> Router Class Initialized
INFO - 2018-10-21 18:30:13 --> Output Class Initialized
INFO - 2018-10-21 18:30:13 --> Security Class Initialized
DEBUG - 2018-10-21 18:30:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:30:13 --> Input Class Initialized
INFO - 2018-10-21 18:30:13 --> Language Class Initialized
INFO - 2018-10-21 18:30:13 --> Language Class Initialized
INFO - 2018-10-21 18:30:13 --> Config Class Initialized
INFO - 2018-10-21 18:30:13 --> Loader Class Initialized
INFO - 2018-10-21 18:30:13 --> Helper loaded: url_helper
INFO - 2018-10-21 18:30:13 --> Helper loaded: form_helper
INFO - 2018-10-21 18:30:13 --> Helper loaded: html_helper
INFO - 2018-10-21 18:30:13 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:30:13 --> Form Validation Class Initialized
INFO - 2018-10-21 18:30:13 --> Email Class Initialized
INFO - 2018-10-21 18:30:13 --> Controller Class Initialized
DEBUG - 2018-10-21 18:30:13 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:30:13 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:30:13 --> Final output sent to browser
DEBUG - 2018-10-21 18:30:13 --> Total execution time: 0.4690
INFO - 2018-10-21 18:30:29 --> Config Class Initialized
INFO - 2018-10-21 18:30:29 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:30:29 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:30:29 --> Utf8 Class Initialized
INFO - 2018-10-21 18:30:29 --> URI Class Initialized
INFO - 2018-10-21 18:30:29 --> Router Class Initialized
INFO - 2018-10-21 18:30:29 --> Output Class Initialized
INFO - 2018-10-21 18:30:29 --> Security Class Initialized
DEBUG - 2018-10-21 18:30:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:30:29 --> Input Class Initialized
INFO - 2018-10-21 18:30:29 --> Language Class Initialized
INFO - 2018-10-21 18:30:29 --> Language Class Initialized
INFO - 2018-10-21 18:30:29 --> Config Class Initialized
INFO - 2018-10-21 18:30:29 --> Loader Class Initialized
INFO - 2018-10-21 18:30:29 --> Helper loaded: url_helper
INFO - 2018-10-21 18:30:29 --> Helper loaded: form_helper
INFO - 2018-10-21 18:30:29 --> Helper loaded: html_helper
INFO - 2018-10-21 18:30:29 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:30:29 --> Form Validation Class Initialized
INFO - 2018-10-21 18:30:29 --> Email Class Initialized
INFO - 2018-10-21 18:30:29 --> Controller Class Initialized
DEBUG - 2018-10-21 18:30:29 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:30:46 --> Config Class Initialized
INFO - 2018-10-21 18:30:46 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:30:46 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:30:46 --> Utf8 Class Initialized
INFO - 2018-10-21 18:30:46 --> URI Class Initialized
INFO - 2018-10-21 18:30:46 --> Router Class Initialized
INFO - 2018-10-21 18:30:46 --> Output Class Initialized
INFO - 2018-10-21 18:30:46 --> Security Class Initialized
DEBUG - 2018-10-21 18:30:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:30:46 --> Input Class Initialized
INFO - 2018-10-21 18:30:46 --> Language Class Initialized
INFO - 2018-10-21 18:30:46 --> Language Class Initialized
INFO - 2018-10-21 18:30:46 --> Config Class Initialized
INFO - 2018-10-21 18:30:46 --> Loader Class Initialized
INFO - 2018-10-21 18:30:46 --> Helper loaded: url_helper
INFO - 2018-10-21 18:30:46 --> Helper loaded: form_helper
INFO - 2018-10-21 18:30:46 --> Helper loaded: html_helper
INFO - 2018-10-21 18:30:46 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:30:46 --> Form Validation Class Initialized
INFO - 2018-10-21 18:30:46 --> Email Class Initialized
INFO - 2018-10-21 18:30:46 --> Controller Class Initialized
DEBUG - 2018-10-21 18:30:46 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:30:46 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:30:46 --> Final output sent to browser
DEBUG - 2018-10-21 18:30:46 --> Total execution time: 0.5160
INFO - 2018-10-21 18:30:51 --> Config Class Initialized
INFO - 2018-10-21 18:30:51 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:30:51 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:30:51 --> Utf8 Class Initialized
INFO - 2018-10-21 18:30:51 --> URI Class Initialized
INFO - 2018-10-21 18:30:51 --> Router Class Initialized
INFO - 2018-10-21 18:30:51 --> Output Class Initialized
INFO - 2018-10-21 18:30:51 --> Security Class Initialized
DEBUG - 2018-10-21 18:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:30:51 --> Input Class Initialized
INFO - 2018-10-21 18:30:51 --> Language Class Initialized
INFO - 2018-10-21 18:30:51 --> Language Class Initialized
INFO - 2018-10-21 18:30:51 --> Config Class Initialized
INFO - 2018-10-21 18:30:51 --> Loader Class Initialized
INFO - 2018-10-21 18:30:51 --> Helper loaded: url_helper
INFO - 2018-10-21 18:30:51 --> Helper loaded: form_helper
INFO - 2018-10-21 18:30:51 --> Helper loaded: html_helper
INFO - 2018-10-21 18:30:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:30:51 --> Form Validation Class Initialized
INFO - 2018-10-21 18:30:51 --> Email Class Initialized
INFO - 2018-10-21 18:30:52 --> Controller Class Initialized
DEBUG - 2018-10-21 18:30:52 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:30:52 --> Config Class Initialized
INFO - 2018-10-21 18:30:52 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:30:52 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:30:52 --> Utf8 Class Initialized
INFO - 2018-10-21 18:30:52 --> URI Class Initialized
INFO - 2018-10-21 18:30:52 --> Router Class Initialized
INFO - 2018-10-21 18:30:52 --> Output Class Initialized
INFO - 2018-10-21 18:30:52 --> Security Class Initialized
DEBUG - 2018-10-21 18:30:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:30:52 --> Input Class Initialized
INFO - 2018-10-21 18:30:52 --> Language Class Initialized
INFO - 2018-10-21 18:30:52 --> Language Class Initialized
INFO - 2018-10-21 18:30:52 --> Config Class Initialized
INFO - 2018-10-21 18:30:52 --> Loader Class Initialized
INFO - 2018-10-21 18:30:52 --> Helper loaded: url_helper
INFO - 2018-10-21 18:30:52 --> Helper loaded: form_helper
INFO - 2018-10-21 18:30:52 --> Helper loaded: html_helper
INFO - 2018-10-21 18:30:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:30:52 --> Form Validation Class Initialized
INFO - 2018-10-21 18:30:52 --> Email Class Initialized
INFO - 2018-10-21 18:30:52 --> Controller Class Initialized
DEBUG - 2018-10-21 18:30:52 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:30:52 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:30:52 --> Final output sent to browser
DEBUG - 2018-10-21 18:30:52 --> Total execution time: 0.5586
INFO - 2018-10-21 18:31:03 --> Config Class Initialized
INFO - 2018-10-21 18:31:04 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:31:04 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:31:04 --> Utf8 Class Initialized
INFO - 2018-10-21 18:31:04 --> URI Class Initialized
INFO - 2018-10-21 18:31:04 --> Router Class Initialized
INFO - 2018-10-21 18:31:04 --> Output Class Initialized
INFO - 2018-10-21 18:31:04 --> Security Class Initialized
DEBUG - 2018-10-21 18:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:31:04 --> Input Class Initialized
INFO - 2018-10-21 18:31:04 --> Language Class Initialized
INFO - 2018-10-21 18:31:04 --> Language Class Initialized
INFO - 2018-10-21 18:31:04 --> Config Class Initialized
INFO - 2018-10-21 18:31:04 --> Loader Class Initialized
INFO - 2018-10-21 18:31:04 --> Helper loaded: url_helper
INFO - 2018-10-21 18:31:04 --> Helper loaded: form_helper
INFO - 2018-10-21 18:31:04 --> Helper loaded: html_helper
INFO - 2018-10-21 18:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:31:04 --> Form Validation Class Initialized
INFO - 2018-10-21 18:31:04 --> Email Class Initialized
INFO - 2018-10-21 18:31:04 --> Controller Class Initialized
DEBUG - 2018-10-21 18:31:04 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:31:04 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:31:04 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:31:04 --> Final output sent to browser
DEBUG - 2018-10-21 18:31:04 --> Total execution time: 0.5541
INFO - 2018-10-21 18:31:07 --> Config Class Initialized
INFO - 2018-10-21 18:31:07 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:31:07 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:31:07 --> Utf8 Class Initialized
INFO - 2018-10-21 18:31:07 --> URI Class Initialized
INFO - 2018-10-21 18:31:07 --> Router Class Initialized
INFO - 2018-10-21 18:31:07 --> Output Class Initialized
INFO - 2018-10-21 18:31:07 --> Security Class Initialized
DEBUG - 2018-10-21 18:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:31:07 --> Input Class Initialized
INFO - 2018-10-21 18:31:07 --> Language Class Initialized
INFO - 2018-10-21 18:31:07 --> Language Class Initialized
INFO - 2018-10-21 18:31:07 --> Config Class Initialized
INFO - 2018-10-21 18:31:07 --> Loader Class Initialized
INFO - 2018-10-21 18:31:07 --> Helper loaded: url_helper
INFO - 2018-10-21 18:31:07 --> Helper loaded: form_helper
INFO - 2018-10-21 18:31:07 --> Helper loaded: html_helper
INFO - 2018-10-21 18:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:31:07 --> Form Validation Class Initialized
INFO - 2018-10-21 18:31:07 --> Email Class Initialized
INFO - 2018-10-21 18:31:07 --> Controller Class Initialized
DEBUG - 2018-10-21 18:31:07 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:31:07 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:31:07 --> Final output sent to browser
DEBUG - 2018-10-21 18:31:07 --> Total execution time: 0.5316
INFO - 2018-10-21 18:31:33 --> Config Class Initialized
INFO - 2018-10-21 18:31:33 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:31:33 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:31:33 --> Utf8 Class Initialized
INFO - 2018-10-21 18:31:33 --> URI Class Initialized
INFO - 2018-10-21 18:31:33 --> Router Class Initialized
INFO - 2018-10-21 18:31:33 --> Output Class Initialized
INFO - 2018-10-21 18:31:33 --> Security Class Initialized
DEBUG - 2018-10-21 18:31:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:31:33 --> Input Class Initialized
INFO - 2018-10-21 18:31:33 --> Language Class Initialized
INFO - 2018-10-21 18:31:33 --> Language Class Initialized
INFO - 2018-10-21 18:31:33 --> Config Class Initialized
INFO - 2018-10-21 18:31:33 --> Loader Class Initialized
INFO - 2018-10-21 18:31:33 --> Helper loaded: url_helper
INFO - 2018-10-21 18:31:33 --> Helper loaded: form_helper
INFO - 2018-10-21 18:31:33 --> Helper loaded: html_helper
INFO - 2018-10-21 18:31:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:31:33 --> Form Validation Class Initialized
INFO - 2018-10-21 18:31:33 --> Email Class Initialized
INFO - 2018-10-21 18:31:33 --> Controller Class Initialized
DEBUG - 2018-10-21 18:31:33 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:31:33 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:31:33 --> Final output sent to browser
DEBUG - 2018-10-21 18:31:33 --> Total execution time: 0.5605
INFO - 2018-10-21 18:31:37 --> Config Class Initialized
INFO - 2018-10-21 18:31:37 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:31:37 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:31:37 --> Utf8 Class Initialized
INFO - 2018-10-21 18:31:37 --> URI Class Initialized
INFO - 2018-10-21 18:31:37 --> Router Class Initialized
INFO - 2018-10-21 18:31:37 --> Output Class Initialized
INFO - 2018-10-21 18:31:37 --> Security Class Initialized
DEBUG - 2018-10-21 18:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:31:37 --> Input Class Initialized
INFO - 2018-10-21 18:31:37 --> Language Class Initialized
INFO - 2018-10-21 18:31:37 --> Language Class Initialized
INFO - 2018-10-21 18:31:37 --> Config Class Initialized
INFO - 2018-10-21 18:31:37 --> Loader Class Initialized
INFO - 2018-10-21 18:31:37 --> Helper loaded: url_helper
INFO - 2018-10-21 18:31:37 --> Helper loaded: form_helper
INFO - 2018-10-21 18:31:37 --> Helper loaded: html_helper
INFO - 2018-10-21 18:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:31:37 --> Form Validation Class Initialized
INFO - 2018-10-21 18:31:37 --> Email Class Initialized
INFO - 2018-10-21 18:31:37 --> Controller Class Initialized
DEBUG - 2018-10-21 18:31:37 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:31:37 --> Config Class Initialized
INFO - 2018-10-21 18:31:37 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:31:37 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:31:37 --> Utf8 Class Initialized
INFO - 2018-10-21 18:31:37 --> URI Class Initialized
INFO - 2018-10-21 18:31:37 --> Router Class Initialized
INFO - 2018-10-21 18:31:37 --> Output Class Initialized
INFO - 2018-10-21 18:31:37 --> Security Class Initialized
DEBUG - 2018-10-21 18:31:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:31:37 --> Input Class Initialized
INFO - 2018-10-21 18:31:37 --> Language Class Initialized
INFO - 2018-10-21 18:31:37 --> Language Class Initialized
INFO - 2018-10-21 18:31:37 --> Config Class Initialized
INFO - 2018-10-21 18:31:37 --> Loader Class Initialized
INFO - 2018-10-21 18:31:37 --> Helper loaded: url_helper
INFO - 2018-10-21 18:31:37 --> Helper loaded: form_helper
INFO - 2018-10-21 18:31:37 --> Helper loaded: html_helper
INFO - 2018-10-21 18:31:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:31:37 --> Form Validation Class Initialized
INFO - 2018-10-21 18:31:38 --> Email Class Initialized
INFO - 2018-10-21 18:31:38 --> Controller Class Initialized
DEBUG - 2018-10-21 18:31:38 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:31:38 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:31:38 --> Final output sent to browser
DEBUG - 2018-10-21 18:31:38 --> Total execution time: 0.5629
INFO - 2018-10-21 18:44:59 --> Config Class Initialized
INFO - 2018-10-21 18:44:59 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:44:59 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:44:59 --> Utf8 Class Initialized
INFO - 2018-10-21 18:44:59 --> URI Class Initialized
INFO - 2018-10-21 18:44:59 --> Router Class Initialized
INFO - 2018-10-21 18:44:59 --> Output Class Initialized
INFO - 2018-10-21 18:44:59 --> Security Class Initialized
DEBUG - 2018-10-21 18:44:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:44:59 --> Input Class Initialized
INFO - 2018-10-21 18:44:59 --> Language Class Initialized
INFO - 2018-10-21 18:44:59 --> Language Class Initialized
INFO - 2018-10-21 18:44:59 --> Config Class Initialized
INFO - 2018-10-21 18:44:59 --> Loader Class Initialized
INFO - 2018-10-21 18:44:59 --> Helper loaded: url_helper
INFO - 2018-10-21 18:44:59 --> Helper loaded: form_helper
INFO - 2018-10-21 18:44:59 --> Helper loaded: html_helper
INFO - 2018-10-21 18:45:00 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:45:00 --> Form Validation Class Initialized
INFO - 2018-10-21 18:45:00 --> Email Class Initialized
INFO - 2018-10-21 18:45:00 --> Controller Class Initialized
DEBUG - 2018-10-21 18:45:00 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:45:00 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:45:00 --> Final output sent to browser
DEBUG - 2018-10-21 18:45:00 --> Total execution time: 0.5524
INFO - 2018-10-21 18:45:10 --> Config Class Initialized
INFO - 2018-10-21 18:45:10 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:45:10 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:45:10 --> Utf8 Class Initialized
INFO - 2018-10-21 18:45:10 --> URI Class Initialized
INFO - 2018-10-21 18:45:10 --> Router Class Initialized
INFO - 2018-10-21 18:45:10 --> Output Class Initialized
INFO - 2018-10-21 18:45:10 --> Security Class Initialized
DEBUG - 2018-10-21 18:45:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:45:10 --> Input Class Initialized
INFO - 2018-10-21 18:45:10 --> Language Class Initialized
INFO - 2018-10-21 18:45:10 --> Language Class Initialized
INFO - 2018-10-21 18:45:10 --> Config Class Initialized
INFO - 2018-10-21 18:45:10 --> Loader Class Initialized
INFO - 2018-10-21 18:45:10 --> Helper loaded: url_helper
INFO - 2018-10-21 18:45:10 --> Helper loaded: form_helper
INFO - 2018-10-21 18:45:10 --> Helper loaded: html_helper
INFO - 2018-10-21 18:45:10 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:45:10 --> Form Validation Class Initialized
INFO - 2018-10-21 18:45:10 --> Email Class Initialized
INFO - 2018-10-21 18:45:10 --> Controller Class Initialized
DEBUG - 2018-10-21 18:45:10 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:45:10 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:45:10 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:45:10 --> Final output sent to browser
DEBUG - 2018-10-21 18:45:10 --> Total execution time: 0.5781
INFO - 2018-10-21 18:45:39 --> Config Class Initialized
INFO - 2018-10-21 18:45:39 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:45:39 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:45:39 --> Utf8 Class Initialized
INFO - 2018-10-21 18:45:39 --> URI Class Initialized
INFO - 2018-10-21 18:45:39 --> Router Class Initialized
INFO - 2018-10-21 18:45:39 --> Output Class Initialized
INFO - 2018-10-21 18:45:39 --> Security Class Initialized
DEBUG - 2018-10-21 18:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:45:39 --> Input Class Initialized
INFO - 2018-10-21 18:45:39 --> Language Class Initialized
INFO - 2018-10-21 18:45:39 --> Language Class Initialized
INFO - 2018-10-21 18:45:39 --> Config Class Initialized
INFO - 2018-10-21 18:45:39 --> Loader Class Initialized
INFO - 2018-10-21 18:45:39 --> Helper loaded: url_helper
INFO - 2018-10-21 18:45:39 --> Helper loaded: form_helper
INFO - 2018-10-21 18:45:39 --> Helper loaded: html_helper
INFO - 2018-10-21 18:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:45:39 --> Form Validation Class Initialized
INFO - 2018-10-21 18:45:39 --> Email Class Initialized
INFO - 2018-10-21 18:45:39 --> Controller Class Initialized
DEBUG - 2018-10-21 18:45:40 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:45:40 --> Language file loaded: language/english/email_lang.php
INFO - 2018-10-21 18:45:50 --> Config Class Initialized
INFO - 2018-10-21 18:45:51 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:45:51 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:45:51 --> Utf8 Class Initialized
INFO - 2018-10-21 18:45:51 --> URI Class Initialized
INFO - 2018-10-21 18:45:51 --> Router Class Initialized
INFO - 2018-10-21 18:45:51 --> Output Class Initialized
INFO - 2018-10-21 18:45:51 --> Security Class Initialized
DEBUG - 2018-10-21 18:45:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:45:51 --> Input Class Initialized
INFO - 2018-10-21 18:45:51 --> Language Class Initialized
INFO - 2018-10-21 18:45:51 --> Language Class Initialized
INFO - 2018-10-21 18:45:51 --> Config Class Initialized
INFO - 2018-10-21 18:45:51 --> Loader Class Initialized
INFO - 2018-10-21 18:45:51 --> Helper loaded: url_helper
INFO - 2018-10-21 18:45:51 --> Helper loaded: form_helper
INFO - 2018-10-21 18:45:51 --> Helper loaded: html_helper
INFO - 2018-10-21 18:45:51 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:45:51 --> Form Validation Class Initialized
INFO - 2018-10-21 18:45:51 --> Email Class Initialized
INFO - 2018-10-21 18:45:51 --> Controller Class Initialized
DEBUG - 2018-10-21 18:45:51 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:45:51 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:45:51 --> Final output sent to browser
DEBUG - 2018-10-21 18:45:51 --> Total execution time: 0.5488
INFO - 2018-10-21 18:47:40 --> Config Class Initialized
INFO - 2018-10-21 18:47:40 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:47:40 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:47:40 --> Utf8 Class Initialized
INFO - 2018-10-21 18:47:40 --> URI Class Initialized
INFO - 2018-10-21 18:47:40 --> Router Class Initialized
INFO - 2018-10-21 18:47:40 --> Output Class Initialized
INFO - 2018-10-21 18:47:40 --> Security Class Initialized
DEBUG - 2018-10-21 18:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:47:40 --> Input Class Initialized
INFO - 2018-10-21 18:47:40 --> Language Class Initialized
INFO - 2018-10-21 18:47:40 --> Language Class Initialized
INFO - 2018-10-21 18:47:40 --> Config Class Initialized
INFO - 2018-10-21 18:47:40 --> Loader Class Initialized
INFO - 2018-10-21 18:47:40 --> Helper loaded: url_helper
INFO - 2018-10-21 18:47:40 --> Helper loaded: form_helper
INFO - 2018-10-21 18:47:40 --> Helper loaded: html_helper
INFO - 2018-10-21 18:47:40 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:47:40 --> Form Validation Class Initialized
INFO - 2018-10-21 18:47:40 --> Email Class Initialized
INFO - 2018-10-21 18:47:41 --> Controller Class Initialized
DEBUG - 2018-10-21 18:47:41 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:47:41 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:47:41 --> Final output sent to browser
DEBUG - 2018-10-21 18:47:41 --> Total execution time: 0.5702
INFO - 2018-10-21 18:47:44 --> Config Class Initialized
INFO - 2018-10-21 18:47:44 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:47:44 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:47:44 --> Utf8 Class Initialized
INFO - 2018-10-21 18:47:44 --> URI Class Initialized
INFO - 2018-10-21 18:47:44 --> Router Class Initialized
INFO - 2018-10-21 18:47:44 --> Output Class Initialized
INFO - 2018-10-21 18:47:44 --> Security Class Initialized
DEBUG - 2018-10-21 18:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:47:44 --> Input Class Initialized
INFO - 2018-10-21 18:47:44 --> Language Class Initialized
INFO - 2018-10-21 18:47:44 --> Language Class Initialized
INFO - 2018-10-21 18:47:44 --> Config Class Initialized
INFO - 2018-10-21 18:47:44 --> Loader Class Initialized
INFO - 2018-10-21 18:47:44 --> Helper loaded: url_helper
INFO - 2018-10-21 18:47:44 --> Helper loaded: form_helper
INFO - 2018-10-21 18:47:44 --> Helper loaded: html_helper
INFO - 2018-10-21 18:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:47:44 --> Form Validation Class Initialized
INFO - 2018-10-21 18:47:44 --> Email Class Initialized
INFO - 2018-10-21 18:47:45 --> Controller Class Initialized
DEBUG - 2018-10-21 18:47:45 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:47:45 --> Config Class Initialized
INFO - 2018-10-21 18:47:45 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:47:45 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:47:45 --> Utf8 Class Initialized
INFO - 2018-10-21 18:47:45 --> URI Class Initialized
INFO - 2018-10-21 18:47:45 --> Router Class Initialized
INFO - 2018-10-21 18:47:45 --> Output Class Initialized
INFO - 2018-10-21 18:47:45 --> Security Class Initialized
DEBUG - 2018-10-21 18:47:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:47:45 --> Input Class Initialized
INFO - 2018-10-21 18:47:45 --> Language Class Initialized
INFO - 2018-10-21 18:47:45 --> Language Class Initialized
INFO - 2018-10-21 18:47:45 --> Config Class Initialized
INFO - 2018-10-21 18:47:45 --> Loader Class Initialized
INFO - 2018-10-21 18:47:45 --> Helper loaded: url_helper
INFO - 2018-10-21 18:47:45 --> Helper loaded: form_helper
INFO - 2018-10-21 18:47:45 --> Helper loaded: html_helper
INFO - 2018-10-21 18:47:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:47:45 --> Form Validation Class Initialized
INFO - 2018-10-21 18:47:45 --> Email Class Initialized
INFO - 2018-10-21 18:47:45 --> Controller Class Initialized
DEBUG - 2018-10-21 18:47:45 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:47:45 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:47:45 --> Final output sent to browser
DEBUG - 2018-10-21 18:47:45 --> Total execution time: 0.5517
INFO - 2018-10-21 18:47:54 --> Config Class Initialized
INFO - 2018-10-21 18:47:54 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:47:54 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:47:54 --> Utf8 Class Initialized
INFO - 2018-10-21 18:47:54 --> URI Class Initialized
INFO - 2018-10-21 18:47:54 --> Router Class Initialized
INFO - 2018-10-21 18:47:54 --> Output Class Initialized
INFO - 2018-10-21 18:47:54 --> Security Class Initialized
DEBUG - 2018-10-21 18:47:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:47:54 --> Input Class Initialized
INFO - 2018-10-21 18:47:54 --> Language Class Initialized
INFO - 2018-10-21 18:47:54 --> Language Class Initialized
INFO - 2018-10-21 18:47:54 --> Config Class Initialized
INFO - 2018-10-21 18:47:54 --> Loader Class Initialized
INFO - 2018-10-21 18:47:54 --> Helper loaded: url_helper
INFO - 2018-10-21 18:47:55 --> Helper loaded: form_helper
INFO - 2018-10-21 18:47:55 --> Helper loaded: html_helper
INFO - 2018-10-21 18:47:55 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:47:55 --> Form Validation Class Initialized
INFO - 2018-10-21 18:47:55 --> Email Class Initialized
INFO - 2018-10-21 18:47:55 --> Controller Class Initialized
DEBUG - 2018-10-21 18:47:55 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:47:55 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:47:55 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:47:55 --> Final output sent to browser
DEBUG - 2018-10-21 18:47:55 --> Total execution time: 0.6044
INFO - 2018-10-21 18:48:12 --> Config Class Initialized
INFO - 2018-10-21 18:48:12 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:48:12 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:48:12 --> Utf8 Class Initialized
INFO - 2018-10-21 18:48:12 --> URI Class Initialized
INFO - 2018-10-21 18:48:12 --> Router Class Initialized
INFO - 2018-10-21 18:48:12 --> Output Class Initialized
INFO - 2018-10-21 18:48:12 --> Security Class Initialized
DEBUG - 2018-10-21 18:48:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:48:12 --> Input Class Initialized
INFO - 2018-10-21 18:48:12 --> Language Class Initialized
INFO - 2018-10-21 18:48:12 --> Language Class Initialized
INFO - 2018-10-21 18:48:12 --> Config Class Initialized
INFO - 2018-10-21 18:48:12 --> Loader Class Initialized
INFO - 2018-10-21 18:48:12 --> Helper loaded: url_helper
INFO - 2018-10-21 18:48:12 --> Helper loaded: form_helper
INFO - 2018-10-21 18:48:12 --> Helper loaded: html_helper
INFO - 2018-10-21 18:48:12 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:48:12 --> Form Validation Class Initialized
INFO - 2018-10-21 18:48:12 --> Email Class Initialized
INFO - 2018-10-21 18:48:12 --> Controller Class Initialized
DEBUG - 2018-10-21 18:48:12 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:48:13 --> Language file loaded: language/english/email_lang.php
INFO - 2018-10-21 18:48:23 --> Config Class Initialized
INFO - 2018-10-21 18:48:23 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:48:23 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:48:23 --> Utf8 Class Initialized
INFO - 2018-10-21 18:48:23 --> URI Class Initialized
INFO - 2018-10-21 18:48:23 --> Router Class Initialized
INFO - 2018-10-21 18:48:23 --> Output Class Initialized
INFO - 2018-10-21 18:48:23 --> Security Class Initialized
DEBUG - 2018-10-21 18:48:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:48:23 --> Input Class Initialized
INFO - 2018-10-21 18:48:23 --> Language Class Initialized
INFO - 2018-10-21 18:48:23 --> Language Class Initialized
INFO - 2018-10-21 18:48:23 --> Config Class Initialized
INFO - 2018-10-21 18:48:23 --> Loader Class Initialized
INFO - 2018-10-21 18:48:23 --> Helper loaded: url_helper
INFO - 2018-10-21 18:48:23 --> Helper loaded: form_helper
INFO - 2018-10-21 18:48:23 --> Helper loaded: html_helper
INFO - 2018-10-21 18:48:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:48:23 --> Form Validation Class Initialized
INFO - 2018-10-21 18:48:23 --> Email Class Initialized
INFO - 2018-10-21 18:48:23 --> Controller Class Initialized
DEBUG - 2018-10-21 18:48:23 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:48:23 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:48:23 --> Final output sent to browser
DEBUG - 2018-10-21 18:48:23 --> Total execution time: 0.5749
INFO - 2018-10-21 18:48:42 --> Config Class Initialized
INFO - 2018-10-21 18:48:42 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:48:42 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:48:42 --> Utf8 Class Initialized
INFO - 2018-10-21 18:48:42 --> URI Class Initialized
INFO - 2018-10-21 18:48:42 --> Router Class Initialized
INFO - 2018-10-21 18:48:42 --> Output Class Initialized
INFO - 2018-10-21 18:48:42 --> Security Class Initialized
DEBUG - 2018-10-21 18:48:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:48:42 --> Input Class Initialized
INFO - 2018-10-21 18:48:43 --> Language Class Initialized
INFO - 2018-10-21 18:48:43 --> Language Class Initialized
INFO - 2018-10-21 18:48:43 --> Config Class Initialized
INFO - 2018-10-21 18:48:43 --> Loader Class Initialized
INFO - 2018-10-21 18:48:43 --> Helper loaded: url_helper
INFO - 2018-10-21 18:48:43 --> Helper loaded: form_helper
INFO - 2018-10-21 18:48:43 --> Helper loaded: html_helper
INFO - 2018-10-21 18:48:43 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:48:43 --> Form Validation Class Initialized
INFO - 2018-10-21 18:48:43 --> Email Class Initialized
INFO - 2018-10-21 18:48:43 --> Controller Class Initialized
DEBUG - 2018-10-21 18:48:43 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:48:43 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:48:43 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:48:43 --> Final output sent to browser
DEBUG - 2018-10-21 18:48:43 --> Total execution time: 0.6985
INFO - 2018-10-21 18:49:04 --> Config Class Initialized
INFO - 2018-10-21 18:49:04 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:49:04 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:49:04 --> Utf8 Class Initialized
INFO - 2018-10-21 18:49:04 --> URI Class Initialized
INFO - 2018-10-21 18:49:04 --> Router Class Initialized
INFO - 2018-10-21 18:49:04 --> Output Class Initialized
INFO - 2018-10-21 18:49:04 --> Security Class Initialized
DEBUG - 2018-10-21 18:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:49:04 --> Input Class Initialized
INFO - 2018-10-21 18:49:04 --> Language Class Initialized
INFO - 2018-10-21 18:49:04 --> Language Class Initialized
INFO - 2018-10-21 18:49:04 --> Config Class Initialized
INFO - 2018-10-21 18:49:04 --> Loader Class Initialized
INFO - 2018-10-21 18:49:04 --> Helper loaded: url_helper
INFO - 2018-10-21 18:49:04 --> Helper loaded: form_helper
INFO - 2018-10-21 18:49:04 --> Helper loaded: html_helper
INFO - 2018-10-21 18:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:49:04 --> Form Validation Class Initialized
INFO - 2018-10-21 18:49:04 --> Email Class Initialized
INFO - 2018-10-21 18:49:05 --> Controller Class Initialized
DEBUG - 2018-10-21 18:49:05 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:49:23 --> Config Class Initialized
INFO - 2018-10-21 18:49:23 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:49:23 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:49:23 --> Utf8 Class Initialized
INFO - 2018-10-21 18:49:23 --> URI Class Initialized
INFO - 2018-10-21 18:49:23 --> Router Class Initialized
INFO - 2018-10-21 18:49:23 --> Output Class Initialized
INFO - 2018-10-21 18:49:23 --> Security Class Initialized
DEBUG - 2018-10-21 18:49:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:49:23 --> Input Class Initialized
INFO - 2018-10-21 18:49:23 --> Language Class Initialized
INFO - 2018-10-21 18:49:23 --> Language Class Initialized
INFO - 2018-10-21 18:49:23 --> Config Class Initialized
INFO - 2018-10-21 18:49:23 --> Loader Class Initialized
INFO - 2018-10-21 18:49:23 --> Helper loaded: url_helper
INFO - 2018-10-21 18:49:23 --> Helper loaded: form_helper
INFO - 2018-10-21 18:49:23 --> Helper loaded: html_helper
INFO - 2018-10-21 18:49:23 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:49:23 --> Form Validation Class Initialized
INFO - 2018-10-21 18:49:23 --> Email Class Initialized
INFO - 2018-10-21 18:49:23 --> Controller Class Initialized
DEBUG - 2018-10-21 18:49:23 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:49:52 --> Config Class Initialized
INFO - 2018-10-21 18:49:52 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:49:52 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:49:52 --> Utf8 Class Initialized
INFO - 2018-10-21 18:49:52 --> URI Class Initialized
INFO - 2018-10-21 18:49:52 --> Router Class Initialized
INFO - 2018-10-21 18:49:52 --> Output Class Initialized
INFO - 2018-10-21 18:49:52 --> Security Class Initialized
DEBUG - 2018-10-21 18:49:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:49:52 --> Input Class Initialized
INFO - 2018-10-21 18:49:52 --> Language Class Initialized
INFO - 2018-10-21 18:49:52 --> Language Class Initialized
INFO - 2018-10-21 18:49:52 --> Config Class Initialized
INFO - 2018-10-21 18:49:52 --> Loader Class Initialized
INFO - 2018-10-21 18:49:52 --> Helper loaded: url_helper
INFO - 2018-10-21 18:49:52 --> Helper loaded: form_helper
INFO - 2018-10-21 18:49:52 --> Helper loaded: html_helper
INFO - 2018-10-21 18:49:52 --> Helper loaded: email_helper
INFO - 2018-10-21 18:49:52 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:49:52 --> Form Validation Class Initialized
INFO - 2018-10-21 18:49:52 --> Email Class Initialized
INFO - 2018-10-21 18:49:52 --> Controller Class Initialized
DEBUG - 2018-10-21 18:49:52 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:50:25 --> Config Class Initialized
INFO - 2018-10-21 18:50:25 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:50:25 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:50:25 --> Utf8 Class Initialized
INFO - 2018-10-21 18:50:25 --> URI Class Initialized
INFO - 2018-10-21 18:50:25 --> Router Class Initialized
INFO - 2018-10-21 18:50:25 --> Output Class Initialized
INFO - 2018-10-21 18:50:25 --> Security Class Initialized
DEBUG - 2018-10-21 18:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:50:25 --> Input Class Initialized
INFO - 2018-10-21 18:50:25 --> Language Class Initialized
INFO - 2018-10-21 18:50:25 --> Language Class Initialized
INFO - 2018-10-21 18:50:25 --> Config Class Initialized
INFO - 2018-10-21 18:50:25 --> Loader Class Initialized
INFO - 2018-10-21 18:50:25 --> Helper loaded: url_helper
INFO - 2018-10-21 18:50:25 --> Helper loaded: form_helper
INFO - 2018-10-21 18:50:25 --> Helper loaded: html_helper
INFO - 2018-10-21 18:50:25 --> Helper loaded: email_helper
INFO - 2018-10-21 18:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:50:25 --> Form Validation Class Initialized
INFO - 2018-10-21 18:50:25 --> Email Class Initialized
INFO - 2018-10-21 18:50:25 --> Controller Class Initialized
DEBUG - 2018-10-21 18:50:25 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:50:26 --> Language file loaded: language/english/email_lang.php
INFO - 2018-10-21 18:50:37 --> Config Class Initialized
INFO - 2018-10-21 18:50:37 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:50:37 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:50:37 --> Utf8 Class Initialized
INFO - 2018-10-21 18:50:37 --> URI Class Initialized
INFO - 2018-10-21 18:50:37 --> Router Class Initialized
INFO - 2018-10-21 18:50:37 --> Output Class Initialized
INFO - 2018-10-21 18:50:37 --> Security Class Initialized
DEBUG - 2018-10-21 18:50:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:50:37 --> Input Class Initialized
INFO - 2018-10-21 18:50:37 --> Language Class Initialized
INFO - 2018-10-21 18:50:37 --> Language Class Initialized
INFO - 2018-10-21 18:50:37 --> Config Class Initialized
INFO - 2018-10-21 18:50:37 --> Loader Class Initialized
INFO - 2018-10-21 18:50:37 --> Helper loaded: url_helper
INFO - 2018-10-21 18:50:37 --> Helper loaded: form_helper
INFO - 2018-10-21 18:50:37 --> Helper loaded: html_helper
INFO - 2018-10-21 18:50:37 --> Helper loaded: email_helper
INFO - 2018-10-21 18:50:37 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:50:37 --> Form Validation Class Initialized
INFO - 2018-10-21 18:50:37 --> Email Class Initialized
INFO - 2018-10-21 18:50:37 --> Controller Class Initialized
DEBUG - 2018-10-21 18:50:37 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:50:37 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:50:37 --> Final output sent to browser
DEBUG - 2018-10-21 18:50:37 --> Total execution time: 0.6466
INFO - 2018-10-21 18:51:16 --> Config Class Initialized
INFO - 2018-10-21 18:51:16 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:51:16 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:51:16 --> Utf8 Class Initialized
INFO - 2018-10-21 18:51:16 --> URI Class Initialized
INFO - 2018-10-21 18:51:16 --> Router Class Initialized
INFO - 2018-10-21 18:51:16 --> Output Class Initialized
INFO - 2018-10-21 18:51:16 --> Security Class Initialized
DEBUG - 2018-10-21 18:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:51:16 --> Input Class Initialized
INFO - 2018-10-21 18:51:16 --> Language Class Initialized
INFO - 2018-10-21 18:51:17 --> Language Class Initialized
INFO - 2018-10-21 18:51:17 --> Config Class Initialized
INFO - 2018-10-21 18:51:17 --> Loader Class Initialized
INFO - 2018-10-21 18:51:17 --> Helper loaded: url_helper
INFO - 2018-10-21 18:51:17 --> Helper loaded: form_helper
INFO - 2018-10-21 18:51:17 --> Helper loaded: html_helper
INFO - 2018-10-21 18:51:17 --> Helper loaded: email_helper
INFO - 2018-10-21 18:51:17 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:51:17 --> Form Validation Class Initialized
INFO - 2018-10-21 18:51:17 --> Email Class Initialized
INFO - 2018-10-21 18:51:17 --> Controller Class Initialized
DEBUG - 2018-10-21 18:51:17 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:51:17 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:51:17 --> Final output sent to browser
DEBUG - 2018-10-21 18:51:17 --> Total execution time: 0.6126
INFO - 2018-10-21 18:51:20 --> Config Class Initialized
INFO - 2018-10-21 18:51:20 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:51:20 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:51:20 --> Utf8 Class Initialized
INFO - 2018-10-21 18:51:20 --> URI Class Initialized
INFO - 2018-10-21 18:51:20 --> Router Class Initialized
INFO - 2018-10-21 18:51:20 --> Output Class Initialized
INFO - 2018-10-21 18:51:20 --> Security Class Initialized
DEBUG - 2018-10-21 18:51:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:51:20 --> Input Class Initialized
INFO - 2018-10-21 18:51:20 --> Language Class Initialized
INFO - 2018-10-21 18:51:20 --> Language Class Initialized
INFO - 2018-10-21 18:51:20 --> Config Class Initialized
INFO - 2018-10-21 18:51:20 --> Loader Class Initialized
INFO - 2018-10-21 18:51:20 --> Helper loaded: url_helper
INFO - 2018-10-21 18:51:20 --> Helper loaded: form_helper
INFO - 2018-10-21 18:51:20 --> Helper loaded: html_helper
INFO - 2018-10-21 18:51:20 --> Helper loaded: email_helper
INFO - 2018-10-21 18:51:20 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:51:20 --> Form Validation Class Initialized
INFO - 2018-10-21 18:51:20 --> Email Class Initialized
INFO - 2018-10-21 18:51:20 --> Controller Class Initialized
DEBUG - 2018-10-21 18:51:20 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:51:20 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:51:20 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:51:20 --> Final output sent to browser
DEBUG - 2018-10-21 18:51:20 --> Total execution time: 0.5896
INFO - 2018-10-21 18:51:32 --> Config Class Initialized
INFO - 2018-10-21 18:51:32 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:51:32 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:51:32 --> Utf8 Class Initialized
INFO - 2018-10-21 18:51:32 --> URI Class Initialized
INFO - 2018-10-21 18:51:32 --> Router Class Initialized
INFO - 2018-10-21 18:51:32 --> Output Class Initialized
INFO - 2018-10-21 18:51:32 --> Security Class Initialized
DEBUG - 2018-10-21 18:51:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:51:32 --> Input Class Initialized
INFO - 2018-10-21 18:51:33 --> Language Class Initialized
INFO - 2018-10-21 18:51:33 --> Language Class Initialized
INFO - 2018-10-21 18:51:33 --> Config Class Initialized
INFO - 2018-10-21 18:51:33 --> Loader Class Initialized
INFO - 2018-10-21 18:51:33 --> Helper loaded: url_helper
INFO - 2018-10-21 18:51:33 --> Helper loaded: form_helper
INFO - 2018-10-21 18:51:33 --> Helper loaded: html_helper
INFO - 2018-10-21 18:51:33 --> Helper loaded: email_helper
INFO - 2018-10-21 18:51:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:51:33 --> Form Validation Class Initialized
INFO - 2018-10-21 18:51:33 --> Email Class Initialized
INFO - 2018-10-21 18:51:33 --> Controller Class Initialized
DEBUG - 2018-10-21 18:51:33 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:51:33 --> Language file loaded: language/english/email_lang.php
INFO - 2018-10-21 18:52:44 --> Config Class Initialized
INFO - 2018-10-21 18:52:44 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:52:44 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:52:44 --> Utf8 Class Initialized
INFO - 2018-10-21 18:52:44 --> URI Class Initialized
INFO - 2018-10-21 18:52:44 --> Router Class Initialized
INFO - 2018-10-21 18:52:44 --> Output Class Initialized
INFO - 2018-10-21 18:52:44 --> Security Class Initialized
DEBUG - 2018-10-21 18:52:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:52:45 --> Input Class Initialized
INFO - 2018-10-21 18:52:45 --> Language Class Initialized
INFO - 2018-10-21 18:52:45 --> Language Class Initialized
INFO - 2018-10-21 18:52:45 --> Config Class Initialized
INFO - 2018-10-21 18:52:45 --> Loader Class Initialized
INFO - 2018-10-21 18:52:45 --> Helper loaded: url_helper
INFO - 2018-10-21 18:52:45 --> Helper loaded: form_helper
INFO - 2018-10-21 18:52:45 --> Helper loaded: html_helper
INFO - 2018-10-21 18:52:45 --> Helper loaded: email_helper
INFO - 2018-10-21 18:52:45 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:52:45 --> Form Validation Class Initialized
INFO - 2018-10-21 18:52:45 --> Email Class Initialized
INFO - 2018-10-21 18:52:45 --> Controller Class Initialized
DEBUG - 2018-10-21 18:52:45 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:53:07 --> Config Class Initialized
INFO - 2018-10-21 18:53:07 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:53:07 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:53:07 --> Utf8 Class Initialized
INFO - 2018-10-21 18:53:07 --> URI Class Initialized
INFO - 2018-10-21 18:53:07 --> Router Class Initialized
INFO - 2018-10-21 18:53:07 --> Output Class Initialized
INFO - 2018-10-21 18:53:07 --> Security Class Initialized
DEBUG - 2018-10-21 18:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:53:07 --> Input Class Initialized
INFO - 2018-10-21 18:53:07 --> Language Class Initialized
INFO - 2018-10-21 18:53:07 --> Language Class Initialized
INFO - 2018-10-21 18:53:07 --> Config Class Initialized
INFO - 2018-10-21 18:53:07 --> Loader Class Initialized
INFO - 2018-10-21 18:53:07 --> Helper loaded: url_helper
INFO - 2018-10-21 18:53:07 --> Helper loaded: form_helper
INFO - 2018-10-21 18:53:07 --> Helper loaded: html_helper
INFO - 2018-10-21 18:53:07 --> Helper loaded: email_helper
INFO - 2018-10-21 18:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:53:07 --> Form Validation Class Initialized
INFO - 2018-10-21 18:53:07 --> Email Class Initialized
INFO - 2018-10-21 18:53:07 --> Controller Class Initialized
DEBUG - 2018-10-21 18:53:07 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:54:14 --> Config Class Initialized
INFO - 2018-10-21 18:54:14 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:54:14 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:54:14 --> Utf8 Class Initialized
INFO - 2018-10-21 18:54:14 --> URI Class Initialized
INFO - 2018-10-21 18:54:14 --> Router Class Initialized
INFO - 2018-10-21 18:54:14 --> Output Class Initialized
INFO - 2018-10-21 18:54:14 --> Security Class Initialized
DEBUG - 2018-10-21 18:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:54:14 --> Input Class Initialized
INFO - 2018-10-21 18:54:14 --> Language Class Initialized
INFO - 2018-10-21 18:54:14 --> Language Class Initialized
INFO - 2018-10-21 18:54:14 --> Config Class Initialized
INFO - 2018-10-21 18:54:14 --> Loader Class Initialized
INFO - 2018-10-21 18:54:14 --> Helper loaded: url_helper
INFO - 2018-10-21 18:54:14 --> Helper loaded: form_helper
INFO - 2018-10-21 18:54:14 --> Helper loaded: html_helper
INFO - 2018-10-21 18:54:14 --> Helper loaded: email_helper
INFO - 2018-10-21 18:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:54:14 --> Form Validation Class Initialized
INFO - 2018-10-21 18:54:14 --> Email Class Initialized
INFO - 2018-10-21 18:54:14 --> Controller Class Initialized
DEBUG - 2018-10-21 18:54:14 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:54:38 --> Config Class Initialized
INFO - 2018-10-21 18:54:38 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:54:38 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:54:38 --> Utf8 Class Initialized
INFO - 2018-10-21 18:54:38 --> URI Class Initialized
INFO - 2018-10-21 18:54:38 --> Router Class Initialized
INFO - 2018-10-21 18:54:38 --> Output Class Initialized
INFO - 2018-10-21 18:54:38 --> Security Class Initialized
DEBUG - 2018-10-21 18:54:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:54:38 --> Input Class Initialized
INFO - 2018-10-21 18:54:38 --> Language Class Initialized
INFO - 2018-10-21 18:54:38 --> Language Class Initialized
INFO - 2018-10-21 18:54:38 --> Config Class Initialized
INFO - 2018-10-21 18:54:38 --> Loader Class Initialized
INFO - 2018-10-21 18:54:38 --> Helper loaded: url_helper
INFO - 2018-10-21 18:54:38 --> Helper loaded: form_helper
INFO - 2018-10-21 18:54:38 --> Helper loaded: html_helper
INFO - 2018-10-21 18:54:38 --> Helper loaded: email_helper
INFO - 2018-10-21 18:54:38 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:54:38 --> Form Validation Class Initialized
INFO - 2018-10-21 18:54:38 --> Email Class Initialized
INFO - 2018-10-21 18:54:38 --> Controller Class Initialized
DEBUG - 2018-10-21 18:54:38 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:55:11 --> Config Class Initialized
INFO - 2018-10-21 18:55:11 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:55:11 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:55:11 --> Utf8 Class Initialized
INFO - 2018-10-21 18:55:11 --> URI Class Initialized
INFO - 2018-10-21 18:55:11 --> Router Class Initialized
INFO - 2018-10-21 18:55:11 --> Output Class Initialized
INFO - 2018-10-21 18:55:11 --> Security Class Initialized
DEBUG - 2018-10-21 18:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:55:11 --> Input Class Initialized
INFO - 2018-10-21 18:55:11 --> Language Class Initialized
INFO - 2018-10-21 18:55:11 --> Language Class Initialized
INFO - 2018-10-21 18:55:11 --> Config Class Initialized
INFO - 2018-10-21 18:55:11 --> Loader Class Initialized
INFO - 2018-10-21 18:55:11 --> Helper loaded: url_helper
INFO - 2018-10-21 18:55:11 --> Helper loaded: form_helper
INFO - 2018-10-21 18:55:11 --> Helper loaded: html_helper
INFO - 2018-10-21 18:55:11 --> Helper loaded: email_helper
INFO - 2018-10-21 18:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:55:11 --> Form Validation Class Initialized
INFO - 2018-10-21 18:55:11 --> Email Class Initialized
INFO - 2018-10-21 18:55:12 --> Controller Class Initialized
DEBUG - 2018-10-21 18:55:12 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:55:12 --> Language file loaded: language/english/email_lang.php
INFO - 2018-10-21 18:55:33 --> Config Class Initialized
INFO - 2018-10-21 18:55:33 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:55:33 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:55:33 --> Utf8 Class Initialized
INFO - 2018-10-21 18:55:33 --> URI Class Initialized
INFO - 2018-10-21 18:55:33 --> Router Class Initialized
INFO - 2018-10-21 18:55:33 --> Output Class Initialized
INFO - 2018-10-21 18:55:33 --> Security Class Initialized
DEBUG - 2018-10-21 18:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:55:33 --> Input Class Initialized
INFO - 2018-10-21 18:55:33 --> Language Class Initialized
INFO - 2018-10-21 18:55:33 --> Language Class Initialized
INFO - 2018-10-21 18:55:33 --> Config Class Initialized
INFO - 2018-10-21 18:55:33 --> Loader Class Initialized
INFO - 2018-10-21 18:55:33 --> Helper loaded: url_helper
INFO - 2018-10-21 18:55:33 --> Helper loaded: form_helper
INFO - 2018-10-21 18:55:33 --> Helper loaded: html_helper
INFO - 2018-10-21 18:55:33 --> Helper loaded: email_helper
INFO - 2018-10-21 18:55:33 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:55:33 --> Form Validation Class Initialized
INFO - 2018-10-21 18:55:33 --> Email Class Initialized
INFO - 2018-10-21 18:55:33 --> Controller Class Initialized
DEBUG - 2018-10-21 18:55:33 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:55:35 --> Language file loaded: language/english/email_lang.php
INFO - 2018-10-21 18:56:00 --> Config Class Initialized
INFO - 2018-10-21 18:56:01 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:56:01 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:56:01 --> Utf8 Class Initialized
INFO - 2018-10-21 18:56:01 --> URI Class Initialized
INFO - 2018-10-21 18:56:01 --> Router Class Initialized
INFO - 2018-10-21 18:56:01 --> Output Class Initialized
INFO - 2018-10-21 18:56:01 --> Security Class Initialized
DEBUG - 2018-10-21 18:56:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:56:01 --> Input Class Initialized
INFO - 2018-10-21 18:56:01 --> Language Class Initialized
INFO - 2018-10-21 18:56:01 --> Language Class Initialized
INFO - 2018-10-21 18:56:01 --> Config Class Initialized
INFO - 2018-10-21 18:56:01 --> Loader Class Initialized
INFO - 2018-10-21 18:56:01 --> Helper loaded: url_helper
INFO - 2018-10-21 18:56:01 --> Helper loaded: form_helper
INFO - 2018-10-21 18:56:01 --> Helper loaded: html_helper
INFO - 2018-10-21 18:56:01 --> Helper loaded: email_helper
INFO - 2018-10-21 18:56:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:56:01 --> Form Validation Class Initialized
INFO - 2018-10-21 18:56:01 --> Email Class Initialized
INFO - 2018-10-21 18:56:01 --> Controller Class Initialized
DEBUG - 2018-10-21 18:56:01 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:56:02 --> Language file loaded: language/english/email_lang.php
INFO - 2018-10-21 18:56:27 --> Config Class Initialized
INFO - 2018-10-21 18:56:27 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:56:27 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:56:27 --> Utf8 Class Initialized
INFO - 2018-10-21 18:56:27 --> URI Class Initialized
INFO - 2018-10-21 18:56:27 --> Router Class Initialized
INFO - 2018-10-21 18:56:27 --> Output Class Initialized
INFO - 2018-10-21 18:56:27 --> Security Class Initialized
DEBUG - 2018-10-21 18:56:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:56:27 --> Input Class Initialized
INFO - 2018-10-21 18:56:27 --> Language Class Initialized
INFO - 2018-10-21 18:56:27 --> Language Class Initialized
INFO - 2018-10-21 18:56:27 --> Config Class Initialized
INFO - 2018-10-21 18:56:27 --> Loader Class Initialized
INFO - 2018-10-21 18:56:27 --> Helper loaded: url_helper
INFO - 2018-10-21 18:56:27 --> Helper loaded: form_helper
INFO - 2018-10-21 18:56:27 --> Helper loaded: html_helper
INFO - 2018-10-21 18:56:27 --> Helper loaded: email_helper
INFO - 2018-10-21 18:56:28 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:56:28 --> Form Validation Class Initialized
INFO - 2018-10-21 18:56:28 --> Email Class Initialized
INFO - 2018-10-21 18:56:28 --> Controller Class Initialized
DEBUG - 2018-10-21 18:56:28 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:56:28 --> Language file loaded: language/english/email_lang.php
INFO - 2018-10-21 18:56:34 --> Config Class Initialized
INFO - 2018-10-21 18:56:34 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:56:34 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:56:34 --> Utf8 Class Initialized
INFO - 2018-10-21 18:56:34 --> URI Class Initialized
INFO - 2018-10-21 18:56:34 --> Router Class Initialized
INFO - 2018-10-21 18:56:34 --> Output Class Initialized
INFO - 2018-10-21 18:56:34 --> Security Class Initialized
DEBUG - 2018-10-21 18:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:56:34 --> Input Class Initialized
INFO - 2018-10-21 18:56:34 --> Language Class Initialized
INFO - 2018-10-21 18:56:34 --> Language Class Initialized
INFO - 2018-10-21 18:56:34 --> Config Class Initialized
INFO - 2018-10-21 18:56:34 --> Loader Class Initialized
INFO - 2018-10-21 18:56:34 --> Helper loaded: url_helper
INFO - 2018-10-21 18:56:34 --> Helper loaded: form_helper
INFO - 2018-10-21 18:56:34 --> Helper loaded: html_helper
INFO - 2018-10-21 18:56:34 --> Helper loaded: email_helper
INFO - 2018-10-21 18:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:56:34 --> Form Validation Class Initialized
INFO - 2018-10-21 18:56:34 --> Email Class Initialized
INFO - 2018-10-21 18:56:34 --> Controller Class Initialized
DEBUG - 2018-10-21 18:56:34 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:56:34 --> Config Class Initialized
INFO - 2018-10-21 18:56:34 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:56:34 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:56:34 --> Utf8 Class Initialized
INFO - 2018-10-21 18:56:34 --> URI Class Initialized
INFO - 2018-10-21 18:56:34 --> Router Class Initialized
INFO - 2018-10-21 18:56:34 --> Output Class Initialized
INFO - 2018-10-21 18:56:34 --> Security Class Initialized
DEBUG - 2018-10-21 18:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:56:34 --> Input Class Initialized
INFO - 2018-10-21 18:56:34 --> Language Class Initialized
INFO - 2018-10-21 18:56:34 --> Language Class Initialized
INFO - 2018-10-21 18:56:34 --> Config Class Initialized
INFO - 2018-10-21 18:56:35 --> Loader Class Initialized
INFO - 2018-10-21 18:56:35 --> Helper loaded: url_helper
INFO - 2018-10-21 18:56:35 --> Helper loaded: form_helper
INFO - 2018-10-21 18:56:35 --> Helper loaded: html_helper
INFO - 2018-10-21 18:56:35 --> Helper loaded: email_helper
INFO - 2018-10-21 18:56:35 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:56:35 --> Form Validation Class Initialized
INFO - 2018-10-21 18:56:35 --> Email Class Initialized
INFO - 2018-10-21 18:56:35 --> Controller Class Initialized
DEBUG - 2018-10-21 18:56:35 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:56:35 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:56:35 --> Final output sent to browser
DEBUG - 2018-10-21 18:56:35 --> Total execution time: 0.5910
INFO - 2018-10-21 18:58:01 --> Config Class Initialized
INFO - 2018-10-21 18:58:01 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:58:01 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:58:01 --> Utf8 Class Initialized
INFO - 2018-10-21 18:58:01 --> URI Class Initialized
INFO - 2018-10-21 18:58:01 --> Router Class Initialized
INFO - 2018-10-21 18:58:01 --> Output Class Initialized
INFO - 2018-10-21 18:58:01 --> Security Class Initialized
DEBUG - 2018-10-21 18:58:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:58:01 --> Input Class Initialized
INFO - 2018-10-21 18:58:01 --> Language Class Initialized
INFO - 2018-10-21 18:58:01 --> Language Class Initialized
INFO - 2018-10-21 18:58:01 --> Config Class Initialized
INFO - 2018-10-21 18:58:01 --> Loader Class Initialized
INFO - 2018-10-21 18:58:01 --> Helper loaded: url_helper
INFO - 2018-10-21 18:58:01 --> Helper loaded: form_helper
INFO - 2018-10-21 18:58:01 --> Helper loaded: html_helper
INFO - 2018-10-21 18:58:01 --> Helper loaded: email_helper
INFO - 2018-10-21 18:58:01 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:58:01 --> Form Validation Class Initialized
INFO - 2018-10-21 18:58:01 --> Email Class Initialized
INFO - 2018-10-21 18:58:01 --> Controller Class Initialized
DEBUG - 2018-10-21 18:58:01 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:58:01 --> Language file loaded: language/english/form_validation_lang.php
DEBUG - 2018-10-21 18:58:01 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/home.php
INFO - 2018-10-21 18:58:01 --> Final output sent to browser
DEBUG - 2018-10-21 18:58:01 --> Total execution time: 0.6932
INFO - 2018-10-21 18:58:18 --> Config Class Initialized
INFO - 2018-10-21 18:58:18 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:58:18 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:58:18 --> Utf8 Class Initialized
INFO - 2018-10-21 18:58:18 --> URI Class Initialized
INFO - 2018-10-21 18:58:18 --> Router Class Initialized
INFO - 2018-10-21 18:58:18 --> Output Class Initialized
INFO - 2018-10-21 18:58:18 --> Security Class Initialized
DEBUG - 2018-10-21 18:58:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:58:18 --> Input Class Initialized
INFO - 2018-10-21 18:58:18 --> Language Class Initialized
INFO - 2018-10-21 18:58:18 --> Language Class Initialized
INFO - 2018-10-21 18:58:18 --> Config Class Initialized
INFO - 2018-10-21 18:58:18 --> Loader Class Initialized
INFO - 2018-10-21 18:58:18 --> Helper loaded: url_helper
INFO - 2018-10-21 18:58:18 --> Helper loaded: form_helper
INFO - 2018-10-21 18:58:19 --> Helper loaded: html_helper
INFO - 2018-10-21 18:58:19 --> Helper loaded: email_helper
INFO - 2018-10-21 18:58:19 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:58:19 --> Form Validation Class Initialized
INFO - 2018-10-21 18:58:19 --> Email Class Initialized
INFO - 2018-10-21 18:58:19 --> Controller Class Initialized
DEBUG - 2018-10-21 18:58:19 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:58:19 --> Language file loaded: language/english/email_lang.php
INFO - 2018-10-21 18:58:23 --> Config Class Initialized
INFO - 2018-10-21 18:58:23 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:58:23 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:58:23 --> Utf8 Class Initialized
INFO - 2018-10-21 18:58:23 --> URI Class Initialized
INFO - 2018-10-21 18:58:23 --> Router Class Initialized
INFO - 2018-10-21 18:58:23 --> Output Class Initialized
INFO - 2018-10-21 18:58:23 --> Security Class Initialized
DEBUG - 2018-10-21 18:58:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:58:23 --> Input Class Initialized
INFO - 2018-10-21 18:58:23 --> Language Class Initialized
INFO - 2018-10-21 18:58:23 --> Language Class Initialized
INFO - 2018-10-21 18:58:23 --> Config Class Initialized
INFO - 2018-10-21 18:58:23 --> Loader Class Initialized
INFO - 2018-10-21 18:58:23 --> Helper loaded: url_helper
INFO - 2018-10-21 18:58:24 --> Helper loaded: form_helper
INFO - 2018-10-21 18:58:24 --> Helper loaded: html_helper
INFO - 2018-10-21 18:58:24 --> Helper loaded: email_helper
INFO - 2018-10-21 18:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:58:24 --> Form Validation Class Initialized
INFO - 2018-10-21 18:58:24 --> Email Class Initialized
INFO - 2018-10-21 18:58:24 --> Controller Class Initialized
DEBUG - 2018-10-21 18:58:24 --> Products MX_Controller Initialized
INFO - 2018-10-21 18:58:24 --> Config Class Initialized
INFO - 2018-10-21 18:58:24 --> Hooks Class Initialized
DEBUG - 2018-10-21 18:58:24 --> UTF-8 Support Enabled
INFO - 2018-10-21 18:58:24 --> Utf8 Class Initialized
INFO - 2018-10-21 18:58:24 --> URI Class Initialized
INFO - 2018-10-21 18:58:24 --> Router Class Initialized
INFO - 2018-10-21 18:58:24 --> Output Class Initialized
INFO - 2018-10-21 18:58:24 --> Security Class Initialized
DEBUG - 2018-10-21 18:58:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2018-10-21 18:58:24 --> Input Class Initialized
INFO - 2018-10-21 18:58:24 --> Language Class Initialized
INFO - 2018-10-21 18:58:24 --> Language Class Initialized
INFO - 2018-10-21 18:58:24 --> Config Class Initialized
INFO - 2018-10-21 18:58:24 --> Loader Class Initialized
INFO - 2018-10-21 18:58:24 --> Helper loaded: url_helper
INFO - 2018-10-21 18:58:24 --> Helper loaded: form_helper
INFO - 2018-10-21 18:58:24 --> Helper loaded: html_helper
INFO - 2018-10-21 18:58:24 --> Helper loaded: email_helper
INFO - 2018-10-21 18:58:24 --> Session: Class initialized using 'files' driver.
INFO - 2018-10-21 18:58:24 --> Form Validation Class Initialized
INFO - 2018-10-21 18:58:24 --> Email Class Initialized
INFO - 2018-10-21 18:58:24 --> Controller Class Initialized
DEBUG - 2018-10-21 18:58:24 --> Products MX_Controller Initialized
DEBUG - 2018-10-21 18:58:24 --> File loaded: C:\wamp64\www\CI\application\modules/products/views/sign_in.php
INFO - 2018-10-21 18:58:24 --> Final output sent to browser
DEBUG - 2018-10-21 18:58:24 --> Total execution time: 0.5934
