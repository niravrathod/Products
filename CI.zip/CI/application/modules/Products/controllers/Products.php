<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Products extends MX_Controller {
	public function index()
	{
		$this->load->view('sign_in');
	}

	function home()
	{
		$submit = $this->input->post('submit',TRUE);
		if ($submit == "Submit") {
			$this->form_validation->set_rules('email', 'Email', 'trim|required');
			$this->form_validation->set_rules('pwd', 'Password', 'trim|required|min_length[6]|max_length[15]');
			if ($this->form_validation->run() == false) {
				echo validation_errors();
			}
			else
			{
				$email = $this->input->post('email',TRUE);
				$this->session->set_userdata('email',$email);
				$this->load->view('home');
			}
		}
		else
		{
			redirect('products');
		}
	}

	function display_result()
	{
		$email = $this->input->post('email',TRUE);
		if (isset($email)) {
			// echo $email; die();
			// $asd = FCPATH."\\uploads\\invoice.pdf";
			// echo $asd;die();
			$this->email->initialize();
		    $this->email->from('shopbuzz@gmx.co.uk');
		    $this->email->to($email); 
		    $this->email->subject('PDF File');
    		$this->email->message('Please Download This PDF File For More Info!');
    		$this->email->attach(FCPATH."\\uploads\\invoice.pdf");
    		if ($this->email->send()) {
			$flash_msg = "PDF sent to your email!";
		    $value = '<div class="alert alert-success" role="alert">'.$flash_msg.'</div>';
		    $this->session->set_flashdata('pdf',$value);
		    redirect('products/home','refresh');
			     
			} else {
			   $flash_msg = "Failed to send PDF, please try again!";
			   $value = '<div class="alert alert-danger" role="alert">'.$flash_msg.'</div>';
			   $this->session->set_flashdata('pdf',$value);
			   redirect('products','refresh');
			}

		}
		else
		{
			redirect('products');
		}

	}
}
