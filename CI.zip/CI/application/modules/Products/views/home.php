<!DOCTYPE html>
<html>
<head>
	<title>Products</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js"></script>
</head>
<body>
<?php
$pdf = $this->session->flashdata('pdf');
if(isset($pdf)){
	echo $pdf;
}

?>
<div class="col-md-12 text-center">
<form action="<?= base_url()?>products/display_result" method="POST" id="form" autocomplete='off'>
	<br>
	<div class="form-group">
	  <label for="cname">Email:</label>
		<input type="text" name="email" id="email" value="<?= $this->session->userdata('email')?>" readonly>
		<span>Please Check Your Spam If You Don't Find An Email.</span>

	</div>
	<!-- input:
	company_name
	point_of_user

	checkbox:
	easeprocure => no of users , total price , plan(dropbox)
	logbids => no of users , total price , plan(dropbox)
	vorkflow => no of users , total price , plan(dropbox) -->
	<div class="form-group">
	  <label for="cname">Company Name:</label>
	  <input type="text" class="form-control-inline" id="cname" name="cname">
	</div>
	<div class="form-group">
	  <label for="pou">Point Of User:</label>
	  <input type="text" class="form-control-inline" id="pou" name="pou">
	</div>

	<div class="form-check-inline">
      <label class="form-check-label" for="easeprocure">
        <input type="checkbox" class="form-check-input myCheckBox" id="easeprocure" name="easeprocure" value="easeprocure">Easeprocure
      </label>
    </div>
    	<div class="form-group" style="display: none" id="easeprocure_nou">
		  <label for="easeprocure_nou">No Of Users:</label>
		  <input type="number" min="1" max="100" class="form-control-inline" id="easeprocure_nou_input" name="easeprocure_nou">
		</div>
		<div class="form-group" style="display: none" id="easeprocure_price">
		  <label for="easeprocure_price">Total Price:</label>
		  <input type="text" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" class="form-control-inline" name="easeprocure_price" id="easeprocure_price_input">
		</div>
		   <div class="form-group" style="display: none" id="easeprocure_plan">
			  <select id="easeprocure_plan_input">
			      <option value="1">1/yr</option>
			      <option value="2">2/yr</option>
			      <option value="3">3/yr</option>
			      <option value="4">4/yr</option>
			  </select>
			</div>
		  
    <div class="form-check-inline">
      <label class="form-check-label" for="logbids">
        <input type="checkbox" class="form-check-input myCheckBox" id="logbids" name="logbids" value="logbids">Logbids
      </label>
    </div>

    <div class="form-group" style="display: none" id="logbids_nou">
	  <label for="logbids_nou">No Of Users:</label>
	  <input type="number" min="1" max="100" class="form-control-inline" id="logbids_nou_input" name="logbids_nou">
	</div>
	<div class="form-group" style="display: none" id="logbids_price">
	  <label for="logbids_price">Total Price:</label>
	  <input type="text" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" class="form-control-inline" name="logbids_price" id="logbids_price_input">
	</div>
	   <div class="form-group" style="display: none" id="logbids_plan">
		  <select id="logbids_plan_input">
		      <option value="1">1/yr</option>
		      <option value="2">2/yr</option>
		      <option value="3">3/yr</option>
		      <option value="4">4/yr</option>
		  </select>
		</div>



    <div class="form-check-inline">
      <label class="form-check-label" for="vorkflow">
        <input type="checkbox" class="form-check-input myCheckBox" id="vorkflow" name="vorkflow" value="vorkflow">Vorkflow
      </label>
    </div>

    <div class="form-group" style="display: none" id="vorkflow_nou">
	  <label for="vorkflow_nou">No Of Users:</label>
	  <input type="number" min="1" max="100" class="form-control-inline" id="vorkflow_nou_input" name="vorkflow_nou">
	</div>
	<div class="form-group" style="display: none" id="vorkflow_price">
	  <label for="vorkflow_price">Total Price:</label>
	  <input type="text" onkeyup="if (/\D/g.test(this.value)) this.value = this.value.replace(/\D/g,'')" class="form-control-inline" name="vorkflow_price" id="vorkflow_price_input">
	</div>
	   <div class="form-group" style="display: none" id="vorkflow_plan">
		  <select id="vorkflow_plan_input">
		      <option value="1">1/yr</option>
		      <option value="2">2/yr</option>
		      <option value="3">3/yr</option>
		      <option value="4">4/yr</option>
		  </select>
		</div>



    <button type="submit" class="btn btn-primary">Submit</button>


	
</form>
</div>


<script type="text/javascript">

	$(document).ready(function(){
    	$('input[id="cname"]').prop('required',true);
    	$('input[id="pou"]').prop('required',true);

    	$('#cname').keydown(function(e){
		 if (e.shiftKey || e.ctrlKey || e.altKey) {
              e.preventDefault();
          } else {
              var key = e.keyCode;
              if (!((key == 8) || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90))) {
                  e.preventDefault();
              }
          }
	   });

    	$('#pou').keydown(function(e){
		 if (e.shiftKey || e.ctrlKey || e.altKey) {
              e.preventDefault();
          } else {
              var key = e.keyCode;
              if (!((key == 8) || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90))) {
                  e.preventDefault();
              }
          }
	   });

        $('#easeprocure').click(function(){
            if($(this).prop("checked") == true){
            	$('#easeprocure_nou').css({'display':'block'});
            	$('input[id="easeprocure_nou_input"]').prop('required',true);
            	$('#easeprocure_price').css({'display':'block'});
            	$('input[id="easeprocure_price_input"]').prop('required',true);
            	$('#easeprocure_plan').css({'display':'block'});
            	$('select[id="easeprocure_plan_input"]').prop('required',true);
				  $('#easeprocure_price').keyup(function(e){
					  if (/\D/g.test(this.value))
					  {
					    // Filter non-digits from input value.
					    this.value = this.value.replace(/\D/g, '');
					  }
				   });
                // alert("Checkbox is checked.");
            }
            else if($(this).prop("checked") == false){
            	$('#easeprocure_nou').css({'display':'none'});
            	$('#easeprocure_price').css({'display':'none'});
            	$('#easeprocure_plan').css({'display':'none'});
            }
        });

        $('#logbids').click(function(){
            if($(this).prop("checked") == true){
            	$('#logbids_nou').css({'display':'block'});
            	$('input[id="logbids_nou_input"]').prop('required',true);
            	$('#logbids_price').css({'display':'block'});
            	$('input[id="logbids_price_input"]').prop('required',true);
            	$('#logbids_plan').css({'display':'block'});
            	$('select[id="logbids_plan_input"]').prop('required',true);
				  $('#logbids_price').keyup(function(e){
					  if (/\D/g.test(this.value))
					  {
					    // Filter non-digits from input value.
					    this.value = this.value.replace(/\D/g, '');
					  }
				   });
                // alert("Checkbox is checked.");
            }
            else if($(this).prop("checked") == false){
            	$('#logbids_nou').css({'display':'none'});
            	$('#logbids_price').css({'display':'none'});
            	$('#logbids_plan').css({'display':'none'});
            }
        });


        $('#vorkflow').click(function(){
            if($(this).prop("checked") == true){
            	$('#vorkflow_nou').css({'display':'block'});
            	$('input[id="vorkflow_nou_input"]').prop('required',true);
            	$('#vorkflow_price').css({'display':'block'});
            	$('input[id="vorkflow_price_input"]').prop('required',true);
            	$('#vorkflow_plan').css({'display':'block'});
            	$('select[id="vorkflow_plan_input"]').prop('required',true);
				  $('#vorkflow_price').keyup(function(e){
					  if (/\D/g.test(this.value))
					  {
					    // Filter non-digits from input value.
					    this.value = this.value.replace(/\D/g, '');
					  }
				   });
                // alert("Checkbox is checked.");
            }
            else if($(this).prop("checked") == false){
            	$('#vorkflow_nou').css({'display':'none'});
            	$('#vorkflow_price').css({'display':'none'});
            	$('#vorkflow_plan').css({'display':'none'});
            }
        });
    });



    jQuery(function ($) {
    //form submit handler
    $('#form').submit(function (e) {
        //check atleat 1 checkbox is checked
        if (!$('.myCheckBox').is(':checked')) {
            //prevent the default form submit if it is not checked
            e.preventDefault();
            alert('Atleast One CheckBox Required!');
        }
    })
})
</script>
</body>
</html>